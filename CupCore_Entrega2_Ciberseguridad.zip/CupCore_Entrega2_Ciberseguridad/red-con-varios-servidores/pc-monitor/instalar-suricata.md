# Suricata en PC-MONITOR

Red de la organización con varios servidores. En el servidor del proyecto, con todo en
una sola máquina, `servidor/instalar-suricata.sh` hace las secciones 2 y 3.

## 1. Suricata y fail2ban

| Herramienta | Función | Equipo | Ante un ataque |
|---|---|---|---|
| Suricata | IDS: detección de intrusiones | PC-MONITOR (VLAN 30) | Escribe una alerta en `fast.log` y `eve.json`. No corta el tráfico. |
| fail2ban | IPS: prevención | SRV-WEB (VLAN 20) | Agrega una regla en UFW y bloquea la IP durante 30 minutos. |

Suricata funciona en modo detección, fuera del camino del tráfico: una regla con error
no deja el sitio sin servicio.

## 2. Instalación

```bash
sudo apt update
sudo apt install suricata
sudo suricata-update          # reglas públicas de Emerging Threats
```

## 3. Configuración en `/etc/suricata/suricata.yaml`

```yaml
vars:
  address-groups:
    HOME_NET: "[10.0.10.0/24,10.0.20.0/24,10.0.30.0/24]"   # AJUSTAR: redes de las VLAN 10, 20 y 30
    EXTERNAL_NET: "!$HOME_NET"

af-packet:
  - interface: eth0      # AJUSTAR: interfaz de PC-MONITOR (ip -br link)
    cluster-id: 99
    cluster-type: cluster_flow
    defrag: yes

rule-files:
  - suricata.rules
  - cupcore.rules
```

Reglas propias y prueba de la configuración, desde la carpeta del paquete:

```bash
sudo cp servidor/configuracion/suricata/cupcore.rules /var/lib/suricata/rules/
sudo suricata -T -c /etc/suricata/suricata.yaml -v
sudo systemctl enable --now suricata
sudo systemctl status suricata
```

## 4. Reglas propias

| sid | Detecta |
|---|---|
| 1000001 | Acceso externo al puerto 3306 |
| 1000002 | Barrido de puertos |
| 1000003 | Fuerza bruta contra SSH |
| 1000004 | `or 1=1` en un formulario (inyección SQL) |
| 1000005 | `union select` en la dirección (inyección SQL) |
| 1000006 | `<script` en la dirección (XSS) |
| 1000007 | Escáner automático sqlmap |

## 5. Alertas

```bash
sudo tail -f /var/log/suricata/fast.log
sudo grep CUPCORE /var/log/suricata/fast.log
sudo jq 'select(.event_type=="alert") | {hora:.timestamp, origen:.src_ip, alerta:.alert.signature}' \
    /var/log/suricata/eve.json | tail -20
```

Línea de `fast.log`: fecha y hora, número de regla, texto, clasificación, prioridad y
conexión.

```
09/12/2026-19:30:02.114  [**] [1:1000002:1] CUPCORE Barrido de puertos detectado
[**] [Classification: Attempted Information Leak] [Priority: 2]
{TCP} 190.64.12.7:51234 -> 10.0.20.10:8080
```

## 6. Prueba

Solo sobre la infraestructura del proyecto.

1. Desde otro equipo de la red: `nmap -sS 10.0.20.10`
2. En PC-MONITOR: `sudo grep "Barrido de puertos" /var/log/suricata/fast.log`
3. Captura de la alerta y salida de `sudo suricata -T` como registro.
