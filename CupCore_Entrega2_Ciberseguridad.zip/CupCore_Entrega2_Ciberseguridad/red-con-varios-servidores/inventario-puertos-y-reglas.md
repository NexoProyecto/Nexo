# Inventario de servicios, puertos y reglas del firewall

Red de la organización con varios servidores (sección 2 del documento de la entrega).

## 1. Servicios y puertos

| Servicio | Puerto | Equipo | ¿Público? | Justificación |
|---|---|---|---|---|
| HTTP | 80/tcp | SRV-WEB | Sí, con redirección | Responde con una redirección permanente a HTTPS. |
| HTTPS | 443/tcp | SRV-WEB | Sí | Acceso a CupCore. El cifrado protege las contraseñas en tránsito. |
| SSH | 22/tcp | SRV-WEB, SRV-BD, SRV-BACKUP | No | Acceso administrativo, limitado a PC-ADMIN (10.0.30.10) en la VLAN 30. |
| MariaDB | 3306/tcp | SRV-BD | No | Su único cliente es la aplicación, en SRV-WEB. |
| rsync sobre SSH | 22/tcp | SRV-BACKUP | No | Recibe el respaldo diario desde SRV-BD. |
| DNS, DHCP | 53, 67/udp | RT-01 | No | Servicios internos de la red. |

## 2. Reglas del firewall perimetral (FW-01)

Formato: `ACCIÓN | ORIGEN | DESTINO | PUERTO | JUSTIFICACIÓN`

1. `PERMITIR | Internet | SRV-WEB (10.0.20.10) | 80, 443/tcp | Publicación de la aplicación web.`
2. `DENEGAR | Internet | SRV-BD (10.0.20.20) | 3306/tcp | La base no recibe conexiones desde Internet.`
3. `PERMITIR | PC-ADMIN (10.0.30.10) | VLAN 20 (10.0.20.0/24) | 22/tcp | Administración desde un único equipo identificado.`
4. `DENEGAR | VLAN 10 (10.0.10.0/24) | VLAN 20 (10.0.20.0/24) | 22, 3306/tcp | Las PC de usuarios no llegan a los servicios internos.`
5. `DENEGAR | VLAN 40 (10.0.40.0/24) | VLAN 10, 20 y 30 | todos | Red de invitados aislada, solo con salida a Internet.`
6. `PERMITIR | SRV-WEB (10.0.20.10) | SRV-BD (10.0.20.20) | 3306/tcp | Conexión de la aplicación a la base.`
7. `PERMITIR | SRV-BD (10.0.20.20) | SRV-BACKUP (10.0.20.30) | 22/tcp | Respaldo diario de la base.`
8. `DENEGAR | cualquiera | cualquiera | todos | Denegación por omisión.`

## 3. Ocultamiento del puerto de la base de datos

| Capa | Dónde | Medida | Archivo |
|---|---|---|---|
| Perímetro | FW-01 | Sin regla que publique 3306 hacia Internet. | Regla 2 |
| Equipo | SRV-BD (UFW) | 3306 aceptado solo desde SRV-WEB. | `srv-bd/ufw-srv-bd.sh` |
| Servicio | MariaDB | `bind-address = 10.0.20.20`. | `srv-bd/ocultar-base-de-datos.sh` |

Las cuentas de la base se definen para el equipo de la aplicación
(`cupcoreapp@10.0.20.10`), no para cualquier origen (`%`).

## 4. Comprobación con Nmap

Solo sobre la infraestructura del proyecto.

```bash
# Desde una PC de la VLAN 10
nmap -sV 10.0.20.10          # 80 y 443 abiertos, 22 filtrado
nmap -p 3306 10.0.20.20      # filtered

# Desde fuera de la red
nmap -sV -Pn IP_PUBLICA      # AJUSTAR: IP pública de SRV-WEB. Solo 80 y 443
```

| Puerto | Estado esperado | Otro estado |
|---|---|---|
| 80/tcp | open | — |
| 443/tcp | open | — |
| 22/tcp | filtered | `open` desde la VLAN 10: falta la regla de PC-ADMIN |
| 3306/tcp | filtered o closed | `open`: revisar `bind-address` y UFW |
| otro | no aparece | servicio para desactivar o agregar a este inventario |

Registro del resultado: captura del escaneo y salida de `sudo ufw status verbose`.
