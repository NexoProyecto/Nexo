#!/bin/bash
# ufw-srv-web.sh - firewall de SRV-WEB (10.0.20.10)
# Uso, como root:  sudo bash ufw-srv-web.sh

set -e

IP_ADMIN="10.0.30.10"   # AJUSTAR: IP de PC-ADMIN

echo "[1/5] Politica por defecto: denegar entrada, permitir salida"
ufw --force reset
ufw default deny incoming
ufw default allow outgoing

echo "[2/5] HTTP y HTTPS"
ufw allow 80/tcp  comment 'HTTP - redirige a HTTPS'
ufw allow 443/tcp comment 'HTTPS - CupCore'

echo "[3/5] SSH solo desde PC-ADMIN, con limite de intentos"
ufw limit from "$IP_ADMIN" to any port 22 proto tcp comment 'SSH solo desde PC-ADMIN'

echo "[4/5] Puerto de MariaDB denegado"
ufw deny 3306/tcp comment 'MariaDB denegado'

echo "[5/5] Activar y mostrar el estado"
ufw --force enable
ufw status verbose
