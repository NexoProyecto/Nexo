#!/bin/bash
# instalar-fail2ban.sh - fail2ban en SRV-WEB con las carceles de CupCore
# Uso, como root desde esta carpeta:  sudo bash instalar-fail2ban.sh

set -e

AQUI="$(cd "$(dirname "$0")" && pwd)"
CONF="$AQUI/../../servidor/configuracion/fail2ban"
CARPETA_LOG="/var/log/cupcore"
IP_ADMIN="10.0.30.10"   # AJUSTAR: IP de PC-ADMIN

echo "[1/6] Instalar fail2ban"
apt-get update -qq
apt-get install -y fail2ban

echo "[2/6] Registro de accesos de CupCore"
mkdir -p "$CARPETA_LOG"
touch "$CARPETA_LOG/acceso.log"
chown www-data:adm "$CARPETA_LOG/acceso.log"
chmod 640 "$CARPETA_LOG/acceso.log"

echo "[3/6] Filtro y carceles"
cp "$CONF/cupcore-login.conf" /etc/fail2ban/filter.d/cupcore-login.conf
sed -E "s|^ignoreip *=.*|& $IP_ADMIN|" "$CONF/jail.local" > /etc/fail2ban/jail.local

echo "[4/6] Prueba del filtro"
fail2ban-regex "$CARPETA_LOG/acceso.log" /etc/fail2ban/filter.d/cupcore-login.conf || true

echo "[5/6] Activar el servicio"
systemctl enable fail2ban
systemctl restart fail2ban

echo "[6/6] Estado de las carceles"
sleep 2
fail2ban-client status
fail2ban-client status cupcore-login
