#!/bin/bash
# ocultar-base-de-datos.sh - MariaDB escucha solo en la IP interna de SRV-BD
# Uso, como root:  sudo bash ocultar-base-de-datos.sh

set -e

IP_INTERNA="10.0.20.20"   # AJUSTAR: IP de SRV-BD
ARCHIVO="/etc/mysql/mariadb.conf.d/50-server.cnf"
COPIA="/etc/mysql/mariadb.conf.d/50-server.cnf.respaldo"

echo "[1/4] Respaldo de la configuracion"
cp "$ARCHIVO" "$COPIA"

echo "[2/4] bind-address y skip-name-resolve"
sed -i "s/^bind-address.*/bind-address = $IP_INTERNA/" "$ARCHIVO"
grep -q '^skip-name-resolve' "$ARCHIVO" || echo 'skip-name-resolve' >> "$ARCHIVO"

echo "[3/4] Reiniciar MariaDB"
systemctl restart mariadb

echo "[4/4] Puerto 3306"
ss -tlnp | grep 3306 || echo 'MariaDB no escucha en ningun puerto TCP'
