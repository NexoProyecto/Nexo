#!/bin/bash
# ufw-srv-bd.sh - firewall de SRV-BD (10.0.20.20)
# Uso, como root:  sudo bash ufw-srv-bd.sh

set -e

IP_WEB="10.0.20.10"     # AJUSTAR: IP de SRV-WEB
IP_ADMIN="10.0.30.10"   # AJUSTAR: IP de PC-ADMIN
IP_BACKUP="10.0.20.30"  # AJUSTAR: IP de SRV-BACKUP

echo "[1/5] Politica por defecto: denegar entrada, permitir salida"
ufw --force reset
ufw default deny incoming
ufw default allow outgoing

echo "[2/5] MariaDB solo desde SRV-WEB"
ufw allow from "$IP_WEB" to any port 3306 proto tcp comment 'MariaDB solo desde SRV-WEB'

echo "[3/5] SSH solo desde PC-ADMIN"
ufw allow from "$IP_ADMIN" to any port 22 proto tcp comment 'SSH solo desde PC-ADMIN'

echo "[4/5] Respaldos hacia SRV-BACKUP"
ufw allow out to "$IP_BACKUP" port 22 proto tcp comment 'Respaldo diario por SSH/rsync'

echo "[5/5] Activar y mostrar el estado"
ufw --force enable
ufw status verbose
