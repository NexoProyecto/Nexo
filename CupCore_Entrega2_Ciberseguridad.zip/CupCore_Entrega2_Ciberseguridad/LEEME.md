# CupCore — Segunda entrega — Área de Ciberseguridad

Grupo Nexo · 3.º MK · Instituto Tecnológico Superior Arias-Balparda · setiembre de 2026
Responsable del área: Sofía García

Índice del paquete. El documento de la entrega, `Nexo_Ciberseguridad_SegundaEntrega.docx`,
está en la carpeta de la materia, junto a esta carpeta.

## Contenido

| Carpeta | Qué contiene | ¿Va a la máquina virtual? |
|---|---|---|
| **`servidor/`** | **Todo lo que se instala en la máquina virtual, y nada más.** | **Sí, entera** |
| `red-con-varios-servidores/` | Scripts y guías del esquema de red con un equipo para cada función. | No |
| `pruebas/` | Programas que verifican la capa de seguridad. | No |
| `evidencias/` | Capturas de pantalla y salidas de las pruebas. | No |
| `arquitectura/` | Diagrama de red: `.drawio` editable, `.png` y `.svg`. | No |

## La carpeta `servidor/`

```
servidor/
├── instalar-servidor.sh        instala y configura todo: se ejecuta primero
├── instalar-suricata.sh        agrega Suricata: se ejecuta después, opcional
├── sitio/                      código de CupCore que publica Apache
├── base-de-datos/
│   ├── BD_CupCore.sql                      estructura, datos fijos y cuentas de la base
│   └── CupCore_datos_ejemplo_reducido.sql  datos de prueba
└── configuracion/              archivos que los instaladores copian al sistema
    ├── apache/cupcore.conf              → /etc/apache2/sites-available/cupcore.conf
    ├── apache/zz-cupcore-seguridad.conf → /etc/apache2/conf-available/
    ├── php/99-cupcore.ini               → /etc/php/<versión>/apache2/conf.d/
    ├── fail2ban/jail.local              → /etc/fail2ban/jail.local
    ├── fail2ban/cupcore-login.conf      → /etc/fail2ban/filter.d/
    └── suricata/cupcore.rules           → /var/lib/suricata/rules/
```

Los archivos de `configuracion/` son de texto y se abren con cualquier editor. Los
instaladores los copian a su lugar; no se copian a mano.

## Instalación en la máquina virtual

Ubuntu Server 22.04 o 24.04, o Debian 12. Desde el equipo que tiene el paquete (en Windows 10
o 11, en PowerShell, con los mismos comandos; WinSCP también sirve para la copia):

```
scp -r CupCore_Entrega2_Ciberseguridad/servidor usuario@IP-DEL-SERVIDOR:cupcore
ssh usuario@IP-DEL-SERVIDOR
```

En el servidor:

```
cd cupcore
sudo bash instalar-servidor.sh
sudo bash instalar-suricata.sh
```

`instalar-servidor.sh` deja:

- Apache con el sitio en `/var/www/cupcore`, por HTTPS con certificado autofirmado; el
  puerto 80 redirige a HTTPS.
- MariaDB escuchando solo en `127.0.0.1`, con la base `CupCore` y los datos de prueba.
- Claves nuevas para las tres cuentas de la base, en `/root/cupcore-credenciales.txt`;
  `config/database.php` recibe la de `cupcoreapp`.
- Apache y PHP sin versión en las cabeceras; PHP sin errores en pantalla.
- Registro de accesos en `/var/log/cupcore/acceso.log`.
- UFW: entrada denegada salvo 80, 443 y SSH con límite de intentos; 3306 denegado.
- fail2ban con las cárceles `sshd`, `cupcore-login` y `apache-badbots`.

Variables de `instalar-servidor.sh`:

| Variable | Efecto |
|---|---|
| `IP_ADMIN=192.168.56.1` | SSH solo desde esa IP. Con una IP equivocada, el servidor queda accesible solo desde la consola de la máquina virtual. |
| `RECARGAR_BASE=1` | Vuelve a cargar la base y borra sus datos. |
| `PASOS=sitio` | Ejecuta solo los pasos indicados: `paquetes`, `base`, `sitio`, `apache`, `firewall`, `fail2ban`. |

Se puede ejecutar más de una vez: conserva la base y las claves.

`instalar-suricata.sh` detecta la interfaz y la red del servidor; `INTERFAZ=` y `RED=` las
fijan a mano.

Acceso: `https://IP-DEL-SERVIDOR/`, con el aviso del navegador por el certificado
autofirmado. Las tres cuentas usan la contraseña `CupCore2026$`: `admin@cupcore.com`
(administrador), `rfranco@cupcore.com` (organizador) y `sofia@cupcore.com`
(participante).

Comprobación, en el servidor:

```
sudo ss -tlnp | grep -E ':(80|443|3306) '   # 3306 solo en 127.0.0.1
sudo ufw status verbose
sudo fail2ban-client status cupcore-login
curl -kI https://127.0.0.1/                 # Server: Apache, sin versión
sudo grep CUPCORE /var/log/suricata/fast.log
```

Desde otro equipo de la red:

```
nmap -sV IP-DEL-SERVIDOR    # 80 y 443 abiertos; 3306 no aparece
```

## Medidas de seguridad en el sitio

| Archivo de `servidor/sitio/` | Medida |
|---|---|
| `index.php` | Sesión con `SesionSegura` y cierre por inactividad. |
| `controladores/LoginController.php` | Ingreso con `ControlAcceso`, token CSRF y renovación de la sesión. |
| `controladores/AdminController.php` | Validación en el servidor, lista cerrada de roles y token CSRF. |
| `modelos/GestorUsuarios.php` | Sentencias preparadas y hash bcrypt de costo 12. |
| `vistas/login.php`, `vistas/admin.php` | Token CSRF y mensajes de validación. |
| `seguridad/Validador.php` | Validación de datos en el servidor. |
| `seguridad/Contrasena.php` | Hash y verificación con bcrypt, costo 12. |
| `seguridad/SesionSegura.php` | Cookie de sesión, caducidad y token CSRF. |
| `seguridad/RegistroSeguridad.php` | Registro de accesos en UTC, que lee fail2ban. |
| `seguridad/ControlAcceso.php` | Verificación completa del ingreso. |
| `js/validaciones.js`, `css/validaciones.css` | Validación en el navegador y sus mensajes. |

## Red con varios servidores

`red-con-varios-servidores/` aplica el esquema de la sección 2 del documento, con un
equipo para cada función. Cada carpeta lleva el nombre del equipo donde se ejecuta:

```
srv-web/      sudo bash ufw-srv-web.sh
              sudo bash instalar-fail2ban.sh
srv-bd/       sudo bash ufw-srv-bd.sh
              sudo bash ocultar-base-de-datos.sh
pc-monitor/   instalar-suricata.md, secciones 2 y 3
```

`inventario-puertos-y-reglas.md` tiene los servicios, las reglas del firewall y la
comprobación con Nmap. Las direcciones de cada equipo llevan la marca `AJUSTAR`.

## Pruebas

Desde la carpeta del paquete, con la base cargada:

```
php pruebas/pruebas_php.php      48 comprobaciones de la capa de seguridad
node pruebas/pruebas_js.js       22 comprobaciones de la validación del navegador
php pruebas/pruebas_login.php    30 comprobaciones contra la base
php pruebas/demo_hash.php        hash de una contraseña con bcrypt
```

En Windows con XAMPP, `php` es `C:\xampp\php\php.exe`.

`pruebas_login.php` usa la conexión de `servidor/sitio/config/database.php`; las variables
`CUPCORE_SOCKET`, `CUPCORE_PORT`, `CUPCORE_USER` y `CUPCORE_PASS` la reemplazan. Trabaja
dentro de una transacción que se deshace al terminar.

Requisitos: PHP 8 con `pdo_mysql` y `mbstring`, MariaDB 10.4 o posterior, y Node.js para
`pruebas_js.js`. Las salidas de las tres primeras están en `evidencias/`.
