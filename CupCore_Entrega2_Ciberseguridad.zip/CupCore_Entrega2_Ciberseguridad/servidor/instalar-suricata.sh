#!/bin/bash
# instalar-suricata.sh - instala Suricata en modo deteccion con las reglas de CupCore
#
# Uso, como root desde esta carpeta, despues de instalar-servidor.sh:
#   sudo bash instalar-suricata.sh
#   sudo INTERFAZ=enp0s3 RED=192.168.56.0/24 bash instalar-suricata.sh

set -euo pipefail

AQUI="$(cd "$(dirname "$0")" && pwd)"
YAML=/etc/suricata/suricata.yaml
REGLAS=/var/lib/suricata/rules

[ "$(id -u)" -eq 0 ] || { echo "Ejecutar como root: sudo bash $0"; exit 1; }

# Interfaz de la ruta por defecto y red de esa interfaz
INTERFAZ="${INTERFAZ:-$(ip -o route show default | awk '{for (i = 1; i < NF; i++) if ($i == "dev") { print $(i + 1); exit }}')}"
RED="${RED:-$(ip -o -f inet addr show "$INTERFAZ" | awk '{print $4; exit}')}"
RED="$(python3 -c 'import ipaddress, sys; print(ipaddress.ip_interface(sys.argv[1]).network)' "$RED")"
echo "Interfaz: $INTERFAZ   Red propia: $RED"

echo "[1/5] Instalar Suricata"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y suricata

echo "[2/5] Reglas publicas y reglas propias"
suricata-update || echo "Sin acceso a las reglas publicas: quedan solo las propias."
install -d "$REGLAS"
cp "$AQUI/configuracion/suricata/cupcore.rules" "$REGLAS/cupcore.rules"
[ -f "$REGLAS/suricata.rules" ] || : > "$REGLAS/suricata.rules"

echo "[3/5] Configuracion: red propia, interfaz y archivo de reglas"
cp -n "$YAML" "$YAML.respaldo"
sed -i -E "s|^(\s*HOME_NET:\s*).*|\1\"[$RED]\"|" "$YAML"
sed -i -E "0,/^(\s*- interface:\s*).*/s||\1$INTERFAZ|" "$YAML"
grep -q -- '- cupcore.rules' "$YAML" \
    || sed -i -E "s|^(\s*)- suricata.rules\s*$|&\n\1- cupcore.rules|" "$YAML"
[ -f /etc/default/suricata ] && sed -i -E "s|^IFACE=.*|IFACE=$INTERFAZ|" /etc/default/suricata

echo "[4/5] Prueba de la configuracion"
suricata -T -c "$YAML" -v

echo "[5/5] Activar el servicio"
systemctl enable suricata
systemctl restart suricata
systemctl --no-pager status suricata | head -5
