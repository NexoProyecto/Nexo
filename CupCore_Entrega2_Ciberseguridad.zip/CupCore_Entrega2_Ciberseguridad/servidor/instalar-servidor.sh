#!/bin/bash
# instalar-servidor.sh - instala CupCore en Ubuntu Server 22.04/24.04 o Debian 12
#
# Uso, como root desde esta carpeta:
#   sudo bash instalar-servidor.sh
#   sudo IP_ADMIN=192.168.56.1 bash instalar-servidor.sh
#
# Variables:
#   IP_ADMIN          unica IP con acceso SSH; sin valor, SSH abierto con limite de intentos
#   NOMBRE_SERVIDOR   nombre del certificado HTTPS; por omision, el del equipo
#   RECARGAR_BASE=1   vuelve a cargar la base y borra sus datos
#   PASOS             pasos a ejecutar: paquetes,base,sitio,apache,firewall,fail2ban

set -euo pipefail

AQUI="$(cd "$(dirname "$0")" && pwd)"
SITIO="$AQUI/sitio"
SQL="$AQUI/base-de-datos"
CONF="$AQUI/configuracion"

DESTINO=/var/www/cupcore
CARPETA_LOG=/var/log/cupcore
CERTIFICADOS=/etc/ssl/cupcore
CREDENCIALES=/root/cupcore-credenciales.txt
CONF_MARIADB=/etc/mysql/mariadb.conf.d/60-cupcore.cnf

IP_ADMIN="${IP_ADMIN:-}"
NOMBRE_SERVIDOR="${NOMBRE_SERVIDOR:-$(hostname -f 2>/dev/null || hostname)}"
RECARGAR_BASE="${RECARGAR_BASE:-0}"
PASOS="${PASOS:-paquetes,base,sitio,apache,firewall,fail2ban}"

paso()   { [[ ",$PASOS," == *",$1,"* ]]; }
titulo() { echo; echo "== $1"; }

[ "$(id -u)" -eq 0 ] || { echo "Ejecutar como root: sudo bash $0"; exit 1; }

# --- Paquetes -----------------------------------------------------------------
if paso paquetes; then
    titulo "Paquetes"
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -qq
    apt-get install -y apache2 libapache2-mod-php php-cli php-mysql php-mbstring \
        mariadb-server ufw fail2ban python3-systemd openssl
fi

# --- Base de datos ------------------------------------------------------------
if paso base; then
    titulo "Base de datos"
    printf '[mysqld]\nbind-address = 127.0.0.1\n' > "$CONF_MARIADB"
    systemctl restart mariadb

    if [ "$RECARGAR_BASE" = 1 ] || ! mariadb -N -e "show databases like 'CupCore'" | grep -q CupCore; then
        mariadb < "$SQL/BD_CupCore.sql"
        mariadb < "$SQL/CupCore_datos_ejemplo_reducido.sql"
        echo "Base CupCore cargada con los datos de prueba."
    else
        echo "La base CupCore ya existe y se conserva (RECARGAR_BASE=1 la vuelve a cargar)."
    fi

    # Claves de las cuentas de la base
    if [ ! -f "$CREDENCIALES" ]; then
        generar() { openssl rand -base64 18 | tr '+/' '_-'; }
        ( umask 077
          printf 'CLAVE_APP=%s\nCLAVE_ADMIN=%s\nCLAVE_CONSULTA=%s\n' \
              "$(generar)" "$(generar)" "$(generar)" > "$CREDENCIALES" )
    fi
    # shellcheck source=/dev/null
    . "$CREDENCIALES"
    mariadb <<EOF
ALTER USER 'cupcoreapp'@'localhost'      IDENTIFIED BY '$CLAVE_APP';
ALTER USER 'cupcoreadmin'@'localhost'    IDENTIFIED BY '$CLAVE_ADMIN';
ALTER USER 'cupcoreconsulta'@'localhost' IDENTIFIED BY '$CLAVE_CONSULTA';
EOF
    echo "Claves de las cuentas de la base en $CREDENCIALES"
fi

# --- Sitio --------------------------------------------------------------------
if paso sitio; then
    titulo "Sitio"
    [ -f "$CREDENCIALES" ] || { echo "Falta $CREDENCIALES: ejecutar antes el paso base."; exit 1; }
    # shellcheck source=/dev/null
    . "$CREDENCIALES"

    rm -rf "${DESTINO:?}"
    install -d -m 750 "$DESTINO"
    tar -C "$SITIO" -cf - . | tar -C "$DESTINO" -xf -

    sed -i -e "s|^define('DB_PASS'.*|define('DB_PASS',    '$CLAVE_APP');|" \
           "$DESTINO/config/database.php"

    # Permisos: root escribe, Apache (www-data) solo lee
    chown -R root:www-data "$DESTINO"
    find "$DESTINO" -type d -exec chmod 750 {} +
    find "$DESTINO" -type f -exec chmod 640 {} +

    # Registro de accesos
    install -d -o www-data -g adm -m 750 "$CARPETA_LOG"
    touch "$CARPETA_LOG/acceso.log"
    chown www-data:adm "$CARPETA_LOG/acceso.log"
    chmod 640 "$CARPETA_LOG/acceso.log"
    echo "Sitio en $DESTINO"
fi

# --- Apache con HTTPS ---------------------------------------------------------
if paso apache; then
    titulo "Apache con HTTPS"
    install -d -m 755 "$CERTIFICADOS"
    if [ ! -f "$CERTIFICADOS/cupcore.crt" ]; then
        openssl req -x509 -nodes -newkey rsa:2048 -days 825 \
            -subj "/CN=$NOMBRE_SERVIDOR" -addext "subjectAltName=DNS:$NOMBRE_SERVIDOR" \
            -keyout "$CERTIFICADOS/cupcore.key" -out "$CERTIFICADOS/cupcore.crt"
        chmod 600 "$CERTIFICADOS/cupcore.key"
    fi

    sed -e "s|@DESTINO@|$DESTINO|g" -e "s|@CERTIFICADOS@|$CERTIFICADOS|g" \
        "$CONF/apache/cupcore.conf" > /etc/apache2/sites-available/cupcore.conf
    cp "$CONF/apache/zz-cupcore-seguridad.conf" /etc/apache2/conf-available/
    for carpeta in /etc/php/*/apache2/conf.d; do
        cp "$CONF/php/99-cupcore.ini" "$carpeta/"
    done

    a2enmod -q rewrite headers ssl
    a2enconf -q zz-cupcore-seguridad
    a2dissite -q 000-default || true
    a2ensite -q cupcore
    apache2ctl configtest
    systemctl restart apache2
fi

# --- Firewall (UFW) -----------------------------------------------------------
if paso firewall; then
    titulo "Firewall (UFW)"
    ufw --force reset
    ufw default deny incoming
    ufw default allow outgoing
    ufw allow 80/tcp  comment 'HTTP - redirige a HTTPS'
    ufw allow 443/tcp comment 'HTTPS - CupCore'
    if [ -n "$IP_ADMIN" ]; then
        ufw limit from "$IP_ADMIN" to any port 22 proto tcp comment 'SSH solo desde IP_ADMIN'
    else
        ufw limit 22/tcp comment 'SSH con limite de intentos'
    fi
    ufw deny 3306/tcp comment 'MariaDB solo local'
    ufw --force enable
    ufw status verbose
fi

# --- fail2ban -----------------------------------------------------------------
if paso fail2ban; then
    titulo "fail2ban"
    cp "$CONF/fail2ban/cupcore-login.conf" /etc/fail2ban/filter.d/
    sed -E "s|^ignoreip *=.*|&${IP_ADMIN:+ $IP_ADMIN}|" \
        "$CONF/fail2ban/jail.local" > /etc/fail2ban/jail.local
    # Debian 12 no tiene /var/log/auth.log: la carcel sshd lee el journal
    if [ ! -f /var/log/auth.log ]; then
        printf '[sshd]\nbackend = systemd\n' > /etc/fail2ban/jail.d/cupcore-sshd.local
    fi
    systemctl enable fail2ban
    systemctl restart fail2ban
    sleep 3
    fail2ban-client status
fi

# --- Resumen ------------------------------------------------------------------
titulo "Listo"
IP_SERVIDOR="$(hostname -I 2>/dev/null | awk '{print $1}')"
echo "Sitio:        https://${IP_SERVIDOR:-IP-DEL-SERVIDOR}/  (certificado autofirmado)"
echo "Ingreso:      admin@cupcore.com / CupCore2026\$"
echo "Claves BD:    $CREDENCIALES"
echo "Comprobacion: ss -tlnp | grep 3306   -> 127.0.0.1:3306"
