--  CupCore - Sistema de Gestion Deportiva Modular

CREATE DATABASE IF NOT EXISTS CupCore
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE CupCore;

--  ROL
CREATE TABLE IF NOT EXISTS Rol (
    IdRol       INT             NOT NULL AUTO_INCREMENT,
    NombreRol   VARCHAR(20)     NOT NULL,
    PRIMARY KEY (IdRol),
    CONSTRAINT uqRolNombreRol   UNIQUE (NombreRol),
    -- RNE3
    CONSTRAINT chkRolNombreRol  CHECK (NombreRol IN
        ('ADMINISTRADOR','ORGANIZADOR','PARTICIPANTE'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


--  USUARIO
CREATE TABLE IF NOT EXISTS Usuario (
    IdUsuario   INT             NOT NULL AUTO_INCREMENT,
    Nombre      VARCHAR(50)     NOT NULL,
    Apellido    VARCHAR(50)     NOT NULL,
    Email       VARCHAR(120)    NOT NULL,
    Password    VARCHAR(255)    NOT NULL,   -- se guarda el hash
    Estado      VARCHAR(10)     NOT NULL DEFAULT 'ACTIVO',
    FechaAlta   DATE            NOT NULL,
    IdRol       INT             NOT NULL,
    PRIMARY KEY (IdUsuario),
    -- RNE1
    CONSTRAINT uqUsuarioEmail   UNIQUE (Email),
    CONSTRAINT chkUsuarioEmail  CHECK (Email LIKE '%_@_%._%'),
    -- RNE2
    CONSTRAINT chkUsuarioEstado CHECK (Estado IN ('ACTIVO','INACTIVO')),
    CONSTRAINT fkUsuarioIdRol   FOREIGN KEY (IdRol)
        REFERENCES Rol (IdRol) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- AUDITORIAREGISTRO
CREATE TABLE IF NOT EXISTS AuditoriaRegistro (
    IdAuditoria     INT             NOT NULL AUTO_INCREMENT,
    AccionRealizada VARCHAR(20)     NOT NULL,
    TablaAfectada   VARCHAR(50)     NOT NULL,
    FechaHora       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    IpOrigen        VARCHAR(45)     NOT NULL,
    IdUsuario       INT             NOT NULL,
    PRIMARY KEY (IdAuditoria),
    CONSTRAINT chkAuditoriaRegistroAccion CHECK (AccionRealizada IN
        ('ALTA','MODIFICACION','BAJA','LOGIN','LOGOUT')),
    CONSTRAINT fkAuditoriaRegistroIdUsuario FOREIGN KEY (IdUsuario)
        REFERENCES Usuario (IdUsuario) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- PARTICIPANTE
CREATE TABLE IF NOT EXISTS Participante (
    IdParticipante      INT         NOT NULL AUTO_INCREMENT,
    NombreParticipante  VARCHAR(80) NOT NULL,
    Alias               VARCHAR(40)     NULL,
    FechaNacimiento     DATE            NULL,
    PerfilPublico       BOOLEAN     NOT NULL DEFAULT FALSE,
    PRIMARY KEY (IdParticipante)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- VINCULA
CREATE TABLE IF NOT EXISTS Vincula (
    IdParticipante  INT     NOT NULL,
    IdUsuario       INT     NOT NULL,
    PRIMARY KEY (IdParticipante),
    CONSTRAINT uqVinculaIdUsuario   UNIQUE (IdUsuario),
    CONSTRAINT fkVinculaIdParticipante FOREIGN KEY (IdParticipante)
        REFERENCES Participante (IdParticipante)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fkVinculaIdUsuario   FOREIGN KEY (IdUsuario)
        REFERENCES Usuario (IdUsuario) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- EQUIPO
CREATE TABLE IF NOT EXISTS Equipo (
    IdEquipo        INT         NOT NULL AUTO_INCREMENT,
    NombreEquipo    VARCHAR(80) NOT NULL,
    PerfilPublico   BOOLEAN     NOT NULL DEFAULT FALSE,
    FechaCreacion   DATE        NOT NULL,
    PRIMARY KEY (IdEquipo),
    CONSTRAINT uqEquipoNombreEquipo UNIQUE (NombreEquipo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- INTEGRA
CREATE TABLE IF NOT EXISTS Integra (
    IdParticipante  INT     NOT NULL,
    IdEquipo        INT     NOT NULL,
    FechaIngreso    DATE    NOT NULL,
    PRIMARY KEY (IdParticipante, IdEquipo),
    CONSTRAINT fkIntegraIdParticipante FOREIGN KEY (IdParticipante)
        REFERENCES Participante (IdParticipante)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fkIntegraIdEquipo    FOREIGN KEY (IdEquipo)
        REFERENCES Equipo (IdEquipo) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TIPOTORNEO
CREATE TABLE IF NOT EXISTS TipoTorneo (
    IdTipoTorneo    INT             NOT NULL AUTO_INCREMENT,
    NombreTipo      VARCHAR(40)     NOT NULL,
    Descripcion     VARCHAR(200)        NULL,
    PRIMARY KEY (IdTipoTorneo),
    CONSTRAINT uqTipoTorneoNombreTipo UNIQUE (NombreTipo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- MODULOCOMPETENCIA
CREATE TABLE IF NOT EXISTS ModuloCompetencia (
    IdModulo        INT             NOT NULL AUTO_INCREMENT,
    NombreModulo    VARCHAR(30)     NOT NULL,
    Descripcion     VARCHAR(200)        NULL,
    PRIMARY KEY (IdModulo),
    CONSTRAINT uqModuloCompetenciaNombre UNIQUE (NombreModulo),
    -- RNE4
    CONSTRAINT chkModuloCompetenciaNombre CHECK (NombreModulo IN
        ('LIGA','ELIMINATORIA','SUIZO'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TORNEO
CREATE TABLE IF NOT EXISTS Torneo (
    IdTorneo        INT             NOT NULL AUTO_INCREMENT,
    NombreTorneo    VARCHAR(100)    NOT NULL,
    FechaInicio     DATE            NOT NULL,
    FechaFin        DATE                NULL,
    Estado          VARCHAR(12)     NOT NULL DEFAULT 'BORRADOR',
    IdTipoTorneo    INT             NOT NULL,
    IdUsuario       INT             NOT NULL, 
    PRIMARY KEY (IdTorneo),
    -- RNE5
    CONSTRAINT chkTorneoEstado      CHECK (Estado IN
        ('BORRADOR','ABIERTO','EN CURSO','FINALIZADO','CANCELADO')),
    -- RNE6
    CONSTRAINT chkTorneoFechas      CHECK (FechaFin IS NULL
                                           OR FechaFin >= FechaInicio),
    CONSTRAINT fkTorneoIdTipoTorneo FOREIGN KEY (IdTipoTorneo)
        REFERENCES TipoTorneo (IdTipoTorneo)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fkTorneoIdUsuario    FOREIGN KEY (IdUsuario)
        REFERENCES Usuario (IdUsuario) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- CONFIGURA
CREATE TABLE IF NOT EXISTS Configura (
    IdTorneo            INT             NOT NULL,
    IdModulo            INT             NOT NULL,
    ReglasEspecificas   VARCHAR(500)        NULL,
    Habilitado          BOOLEAN         NOT NULL DEFAULT TRUE,
    PRIMARY KEY (IdTorneo, IdModulo),
    CONSTRAINT fkConfiguraIdTorneo  FOREIGN KEY (IdTorneo)
        REFERENCES Torneo (IdTorneo) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fkConfiguraIdModulo  FOREIGN KEY (IdModulo)
        REFERENCES ModuloCompetencia (IdModulo)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- RONDA
CREATE TABLE IF NOT EXISTS Ronda (
    IdTorneo        INT         NOT NULL,
    NumeroRonda     INT         NOT NULL,
    EstadoRonda     VARCHAR(10) NOT NULL DEFAULT 'PENDIENTE',
    FechaProgramada DATE            NULL,
    PRIMARY KEY (IdTorneo, NumeroRonda),
    -- RNE9
    CONSTRAINT chkRondaNumeroRonda  CHECK (NumeroRonda > 0),
    -- RNE10
    CONSTRAINT chkRondaEstadoRonda  CHECK (EstadoRonda IN
        ('PENDIENTE','EN CURSO','CERRADA')),
    CONSTRAINT fkRondaIdTorneo      FOREIGN KEY (IdTorneo)
        REFERENCES Torneo (IdTorneo) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- INSCRIPCION
CREATE TABLE IF NOT EXISTS Inscripcion (
    IdInscripcion       INT         NOT NULL AUTO_INCREMENT,
    FechaInscripcion    DATE        NOT NULL,
    EstadoInscripcion   VARCHAR(10) NOT NULL DEFAULT 'PENDIENTE',
    IdTorneo            INT         NOT NULL,
    IdParticipante      INT         NOT NULL,
    PRIMARY KEY (IdInscripcion),
    -- RNE8
    CONSTRAINT uqInscripcionTorneoParticipante
        UNIQUE (IdTorneo, IdParticipante),
    CONSTRAINT uqInscripcionAgregacion UNIQUE (IdInscripcion, IdTorneo),
    -- RNE7
    CONSTRAINT chkInscripcionEstado CHECK (EstadoInscripcion IN
        ('PENDIENTE','ACEPTADA','RECHAZADA')),
    CONSTRAINT fkInscripcionIdTorneo FOREIGN KEY (IdTorneo)
        REFERENCES Torneo (IdTorneo) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fkInscripcionIdParticipante FOREIGN KEY (IdParticipante)
        REFERENCES Participante (IdParticipante)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ENFRENTAMIENTO
CREATE TABLE IF NOT EXISTS Enfrentamiento (
    IdEnfrentamiento        INT         NOT NULL AUTO_INCREMENT,
    FechaHora               DATETIME        NULL,
    EstadoPartido           VARCHAR(12) NOT NULL DEFAULT 'PROGRAMADO',
    IdTorneo                INT         NOT NULL,
    NumeroRonda             INT         NOT NULL,
    IdInscripcionLocal      INT         NOT NULL,
    IdInscripcionVisitante  INT         NOT NULL,
    PRIMARY KEY (IdEnfrentamiento),
    CONSTRAINT chkEnfrentamientoEstado CHECK (EstadoPartido IN
        ('PROGRAMADO','JUGADO','SUSPENDIDO','CANCELADO')),
    -- RNE11: local y visitante deben ser distintos
    CONSTRAINT chkEnfrentamientoRivales
        CHECK (IdInscripcionLocal <> IdInscripcionVisitante),
    CONSTRAINT fkEnfrentamientoRonda FOREIGN KEY (IdTorneo, NumeroRonda)
        REFERENCES Ronda (IdTorneo, NumeroRonda)
        ON UPDATE CASCADE ON DELETE CASCADE,
    -- RNE12: la inscripcion local pertenece al torneo del enfrentamiento
    CONSTRAINT fkEnfrentamientoLocal
        FOREIGN KEY (IdInscripcionLocal, IdTorneo)
        REFERENCES Inscripcion (IdInscripcion, IdTorneo)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
    -- RNE12: y la visitante tambien
    CONSTRAINT fkEnfrentamientoVisitante
        FOREIGN KEY (IdInscripcionVisitante, IdTorneo)
        REFERENCES Inscripcion (IdInscripcion, IdTorneo)
        ON UPDATE RESTRICT ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- RESULTADO
CREATE TABLE IF NOT EXISTS Resultado (
    IdResultado         INT         NOT NULL AUTO_INCREMENT,
    PuntuacionLocal     INT         NOT NULL DEFAULT 0,
    PuntuacionVisitante INT         NOT NULL DEFAULT 0,
    Ganador             VARCHAR(10) NOT NULL,
    Validado            BOOLEAN     NOT NULL DEFAULT FALSE,
    FechaCarga          DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    IdEnfrentamiento    INT         NOT NULL,
    PRIMARY KEY (IdResultado),
    CONSTRAINT uqResultadoIdEnfrentamiento UNIQUE (IdEnfrentamiento),
    -- RNE13
    CONSTRAINT chkResultadoPuntuaciones CHECK (PuntuacionLocal >= 0
                                           AND PuntuacionVisitante >= 0),
    -- RNE14
    CONSTRAINT chkResultadoGanador  CHECK (Ganador IN
        ('LOCAL','VISITANTE','EMPATE')),
    CONSTRAINT fkResultadoIdEnfrentamiento FOREIGN KEY (IdEnfrentamiento)
        REFERENCES Enfrentamiento (IdEnfrentamiento)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABLAPOSICIONES
CREATE TABLE IF NOT EXISTS TablaPosiciones (
    IdPosicion          INT     NOT NULL AUTO_INCREMENT,
    PartidosJugados     INT     NOT NULL DEFAULT 0,
    Victorias           INT     NOT NULL DEFAULT 0,
    Empates             INT     NOT NULL DEFAULT 0,
    Derrotas            INT     NOT NULL DEFAULT 0,
    PuntosAcumulados    INT     NOT NULL DEFAULT 0,
    IdTorneo            INT     NOT NULL,
    IdInscripcion       INT     NOT NULL,
    PRIMARY KEY (IdPosicion),
    CONSTRAINT uqTablaPosicionesInscripcion UNIQUE (IdInscripcion),
    -- RNE15
    CONSTRAINT chkTablaPosicionesPartidos
        CHECK (PartidosJugados = Victorias + Empates + Derrotas),
    CONSTRAINT chkTablaPosicionesValores
        CHECK (Victorias >= 0 AND Empates >= 0 AND Derrotas >= 0
               AND PuntosAcumulados >= 0),
    CONSTRAINT fkTablaPosicionesAgregacion
        FOREIGN KEY (IdInscripcion, IdTorneo)
        REFERENCES Inscripcion (IdInscripcion, IdTorneo)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--  Datos de configuracion
INSERT IGNORE INTO Rol (NombreRol) VALUES
    ('ADMINISTRADOR'), ('ORGANIZADOR'), ('PARTICIPANTE');

INSERT IGNORE INTO TipoTorneo (NombreTipo, Descripcion) VALUES
    ('DEPORTIVO',   'Competencias deportivas tradicionales'),
    ('MENTAL',      'Ajedrez, juegos de cartas y de estrategia'),
    ('ELECTRONICO', 'Deportes electronicos y videojuegos');

INSERT IGNORE INTO ModuloCompetencia (NombreModulo, Descripcion) VALUES
    ('LIGA',         'Todos contra todos'),
    ('ELIMINATORIA', 'Llaves con eliminacion directa en cada ronda'),
    ('SUIZO',        'Emparejamiento por rendimiento acumulado');

--  DCL usuarios de la base de datos y sus permisos
--  La clave de cupcoreapp coincide con DB_PASS de config/database.php
CREATE USER IF NOT EXISTS 'cupcoreadmin'@'localhost'
    IDENTIFIED BY 'Cambiar-Admin-2026';
CREATE USER IF NOT EXISTS 'cupcoreapp'@'localhost'
    IDENTIFIED BY 'Cambiar-App-2026';
CREATE USER IF NOT EXISTS 'cupcoreconsulta'@'localhost'
    IDENTIFIED BY 'Cambiar-Consulta-2026';

-- Administrador de la base: mantenimiento y respaldos
GRANT ALL PRIVILEGES ON CupCore.* TO 'cupcoreadmin'@'localhost';

-- Usuario de la aplicacion PHP: solo operaciones CRUD
GRANT SELECT, INSERT, UPDATE, DELETE ON CupCore.* TO 'cupcoreapp'@'localhost';

-- Usuario de consulta publica: solo lectura de lo que se publica
GRANT SELECT ON CupCore.Torneo          TO 'cupcoreconsulta'@'localhost';
GRANT SELECT ON CupCore.TipoTorneo      TO 'cupcoreconsulta'@'localhost';
GRANT SELECT ON CupCore.Ronda           TO 'cupcoreconsulta'@'localhost';
GRANT SELECT ON CupCore.Enfrentamiento  TO 'cupcoreconsulta'@'localhost';
GRANT SELECT ON CupCore.Resultado       TO 'cupcoreconsulta'@'localhost';
GRANT SELECT ON CupCore.TablaPosiciones TO 'cupcoreconsulta'@'localhost';
GRANT SELECT ON CupCore.Participante    TO 'cupcoreconsulta'@'localhost';
GRANT SELECT ON CupCore.Equipo          TO 'cupcoreconsulta'@'localhost';

FLUSH PRIVILEGES;
