<?php
/** Hash y verificación de contraseñas con bcrypt */
class Contrasena
{
    const COSTO = 12;

    public static function generarHash(string $clave): string
    {
        return password_hash($clave, PASSWORD_BCRYPT, ['cost' => self::COSTO]);
    }

    public static function verificar(string $clave, string $hash): bool
    {
        return password_verify($clave, $hash);
    }

    public static function necesitaActualizacion(string $hash): bool
    {
        return password_needs_rehash($hash, PASSWORD_BCRYPT, ['cost' => self::COSTO]);
    }

    public static function informacion(string $hash): array
    {
        return password_get_info($hash);
    }

    /** Contraseña provisional que cumple la política */
    public static function provisional(): string
    {
        $mayusculas = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
        $minusculas = 'abcdefghijkmnpqrstuvwxyz';
        $numeros    = '23456789';
        $especiales = '!@#$%&*?';
        $clave  = $mayusculas[random_int(0, strlen($mayusculas) - 1)];
        $clave .= $especiales[random_int(0, strlen($especiales) - 1)];
        $clave .= $numeros[random_int(0, strlen($numeros) - 1)];
        for ($i = 0; $i < 7; $i++) {
            $clave .= $minusculas[random_int(0, strlen($minusculas) - 1)];
        }
        return $clave;
    }
}
