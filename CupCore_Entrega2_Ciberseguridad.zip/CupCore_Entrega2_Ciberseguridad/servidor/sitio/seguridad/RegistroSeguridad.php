<?php
/**
 * Registro de accesos, con fecha en UTC.
 * Formato fijo: lo lee el filtro cupcore-login de fail2ban.
 */
class RegistroSeguridad
{
    const ARCHIVO = '/var/log/cupcore/acceso.log';

    const INTENTOS_PERMITIDOS = 5;

    /** 15 minutos */
    const VENTANA_SEGUNDOS = 900;

    private string $archivo;

    public function __construct(?string $archivo = null)
    {
        $this->archivo = $archivo ?? self::ARCHIVO;
        $carpeta = dirname($this->archivo);
        if (!is_dir($carpeta)) {
            mkdir($carpeta, 0750, true);
        }
    }

    /** Reemplaza por "_" todo carácter fuera de A-Z a-z 0-9 @ . _ - + */
    private function limpiarValor(string $valor): string
    {
        $limpio = preg_replace('/[^A-Za-z0-9@._\-+]/', '_', $valor);
        if ($limpio === '' || $limpio === null) {
            $limpio = 'desconocido';
        }
        return mb_substr($limpio, 0, 120);
    }

    private function escribir(string $evento, string $usuario, string $ip): void
    {
        $linea = sprintf(
            "%s CUPCORE %s usuario=%s ip=%s\n",
            gmdate('Y-m-d H:i:s'),
            $evento,
            $this->limpiarValor($usuario),
            $this->limpiarValor($ip)
        );
        file_put_contents($this->archivo, $linea, FILE_APPEND | LOCK_EX);
    }

    public function intentoFallido(string $usuario, string $ip): void
    {
        $this->escribir('LOGIN FALLIDO', $usuario, $ip);
    }

    public function ingresoCorrecto(string $usuario, string $ip): void
    {
        $this->escribir('LOGIN OK', $usuario, $ip);
    }

    public function cuentaBloqueada(string $usuario, string $ip): void
    {
        $this->escribir('CUENTA BLOQUEADA', $usuario, $ip);
    }

    public function fallosRecientes(string $usuario): int
    {
        if (!is_readable($this->archivo)) {
            return 0;
        }
        $limite = time() - self::VENTANA_SEGUNDOS;
        $buscado = 'usuario=' . $this->limpiarValor($usuario) . ' ';
        $total = 0;
        foreach (file($this->archivo, FILE_IGNORE_NEW_LINES) as $linea) {
            if (strpos($linea, 'LOGIN FALLIDO') === false) {
                continue;
            }
            if (strpos($linea, $buscado) === false) {
                continue;
            }
            $fecha = strtotime(substr($linea, 0, 19) . ' UTC');
            if ($fecha !== false && $fecha >= $limite) {
                $total++;
            }
        }
        return $total;
    }

    public function estaBloqueado(string $usuario): bool
    {
        return $this->fallosRecientes($usuario) >= self::INTENTOS_PERMITIDOS;
    }
}
