<?php
/** Sesión: cookie, inactividad y token CSRF. Se inicia en index.php. */
class SesionSegura
{
    const MINUTOS_INACTIVIDAD = 30;

    /** Cookie httponly y SameSite=Strict; secure solo bajo HTTPS */
    public static function iniciar(?bool $usarHttps = null): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }
        if ($usarHttps === null) {
            $usarHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
                || (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443;
        }
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'secure'   => $usarHttps,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
        session_name('CUPCORESESSID');
        session_start();
        if (!isset($_SESSION['ultimoAcceso'])) {
            $_SESSION['ultimoAcceso'] = time();
        }
    }

    public static function renovarIdentificador(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }
    }

    public static function vencida(): bool
    {
        if (!isset($_SESSION['ultimoAcceso'])) {
            return false;
        }
        return (time() - (int) $_SESSION['ultimoAcceso']) > (self::MINUTOS_INACTIVIDAD * 60);
    }

    public static function marcarActividad(): void
    {
        $_SESSION['ultimoAcceso'] = time();
    }

    public static function cerrar(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $parametros = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $parametros['path']);
        }
        session_destroy();
    }

    public static function tokenCsrf(): string
    {
        if (empty($_SESSION['tokenCsrf'])) {
            $_SESSION['tokenCsrf'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['tokenCsrf'];
    }

    public static function tokenCsrfValido(?string $recibido): bool
    {
        return is_string($recibido)
            && !empty($_SESSION['tokenCsrf'])
            && hash_equals($_SESSION['tokenCsrf'], $recibido);
    }
}
