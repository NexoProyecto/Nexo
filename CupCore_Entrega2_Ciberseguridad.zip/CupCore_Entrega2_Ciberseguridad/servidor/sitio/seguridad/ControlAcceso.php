<?php
/** Verificación del ingreso */

require_once __DIR__ . '/Validador.php';
require_once __DIR__ . '/RegistroSeguridad.php';
require_once __DIR__ . '/../modelos/GestorUsuarios.php';

class ControlAcceso
{
    const MENSAJE_ERROR = 'Correo o contraseña incorrectos.';

    const MENSAJE_BLOQUEO = 'La cuenta está bloqueada temporalmente por intentos fallidos. Reintentar en 15 minutos.';

    private GestorUsuarios $gestor;
    private RegistroSeguridad $registro;

    public function __construct(?GestorUsuarios $gestor = null, ?RegistroSeguridad $registro = null)
    {
        $this->gestor   = $gestor   ?? new GestorUsuarios();
        $this->registro = $registro ?? new RegistroSeguridad();
    }

    /** Devuelve ['ok' => bool, 'mensaje' => string, 'usuario' => Usuario|null] */
    public function ingresar($correo, $contrasena, string $ip): array
    {
        // 1. Validación
        $validador = new Validador();
        $correoValido = $validador->email('correo', $correo);
        if ($correoValido === null || !is_string($contrasena) || $contrasena === '') {
            return $this->fallo(is_string($correo) ? $correo : 'desconocido', $ip);
        }

        // 2. Límite de intentos
        if ($this->registro->estaBloqueado($correoValido)) {
            $this->registro->cuentaBloqueada($correoValido, $ip);
            return ['ok' => false, 'mensaje' => self::MENSAJE_BLOQUEO, 'usuario' => null];
        }

        // 3. Búsqueda del usuario
        $usuario = $this->gestor->buscarPorCorreo($correoValido);
        if ($usuario === null) {
            return $this->fallo($correoValido, $ip);
        }

        // 4. Estado de la cuenta
        if ($usuario->getEstado() !== 'Activo') {
            return $this->fallo($correoValido, $ip);
        }

        // 5. Contraseña
        if (!$usuario->verificarContrasena($contrasena)) {
            return $this->fallo($correoValido, $ip);
        }

        $this->registro->ingresoCorrecto($correoValido, $ip);
        return ['ok' => true, 'mensaje' => '', 'usuario' => $usuario];
    }

    private function fallo(string $usuario, string $ip): array
    {
        $this->registro->intentoFallido($usuario, $ip);
        return ['ok' => false, 'mensaje' => self::MENSAJE_ERROR, 'usuario' => null];
    }
}
