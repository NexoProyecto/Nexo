<?php
/** Validación de datos de entrada en el servidor */
class Validador
{
    const CLAVE_LARGO_MINIMO = 8;

    private array $errores = [];

    public function errores(): array
    {
        return $this->errores;
    }

    public function hayErrores(): bool
    {
        return count($this->errores) > 0;
    }

    private function error(string $campo, string $mensaje): void
    {
        $this->errores[$campo] = $mensaje;
    }

    /** Rechaza < > " ' ; \ y el carácter nulo */
    public function texto(string $campo, $valor, int $min = 1, int $max = 255): ?string
    {
        if (!is_string($valor)) {
            $this->error($campo, 'El campo debe ser texto.');
            return null;
        }
        $valor = trim($valor);
        if ($valor === '') {
            $this->error($campo, 'El campo es obligatorio.');
            return null;
        }
        $largo = mb_strlen($valor);
        if ($largo < $min || $largo > $max) {
            $this->error($campo, "El campo debe tener entre $min y $max caracteres.");
            return null;
        }
        if (preg_match('/[<>"\';\\\\\x00]/', $valor)) {
            $this->error($campo, 'El campo contiene caracteres no permitidos.');
            return null;
        }
        return $valor;
    }

    public function email(string $campo, $valor): ?string
    {
        if (!is_string($valor)) {
            $this->error($campo, 'El campo debe ser texto.');
            return null;
        }
        $valor = trim($valor);
        if ($valor === '') {
            $this->error($campo, 'El correo es obligatorio.');
            return null;
        }
        if (mb_strlen($valor) > 120) {
            $this->error($campo, 'El correo es demasiado largo.');
            return null;
        }
        $limpio = filter_var($valor, FILTER_VALIDATE_EMAIL);
        if ($limpio === false) {
            $this->error($campo, 'El correo no tiene un formato válido.');
            return null;
        }
        return strtolower($limpio);
    }

    /** Política: 8 a 72 caracteres, mayúscula, minúscula, número y carácter especial */
    public function clave(string $campo, $valor): ?string
    {
        if (!is_string($valor) || $valor === '') {
            $this->error($campo, 'La contraseña es obligatoria.');
            return null;
        }
        if (mb_strlen($valor) < self::CLAVE_LARGO_MINIMO) {
            $this->error($campo, 'La contraseña debe tener al menos ' . self::CLAVE_LARGO_MINIMO . ' caracteres.');
            return null;
        }
        if (mb_strlen($valor) > 72) {
            // bcrypt usa solo los primeros 72 bytes
            $this->error($campo, 'La contraseña no puede superar 72 caracteres.');
            return null;
        }
        $reglas = [
            '/[A-Z]/'                      => 'una letra mayúscula',
            '/[a-z]/'                      => 'una letra minúscula',
            '/[0-9]/'                      => 'un número',
            '/[^A-Za-z0-9]/'               => 'un carácter especial',
        ];
        $faltan = [];
        foreach ($reglas as $patron => $descripcion) {
            if (!preg_match($patron, $valor)) {
                $faltan[] = $descripcion;
            }
        }
        if ($faltan) {
            $this->error($campo, 'La contraseña debe incluir ' . implode(', ', $faltan) . '.');
            return null;
        }
        return $valor;
    }

    public function entero(string $campo, $valor, int $min = 1, int $max = PHP_INT_MAX): ?int
    {
        $numero = filter_var($valor, FILTER_VALIDATE_INT);
        if ($numero === false) {
            $this->error($campo, 'El valor debe ser un número entero.');
            return null;
        }
        if ($numero < $min || $numero > $max) {
            $this->error($campo, "El valor debe estar entre $min y $max.");
            return null;
        }
        return $numero;
    }

    public function fecha(string $campo, $valor): ?string
    {
        if (!is_string($valor) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $valor)) {
            $this->error($campo, 'La fecha debe tener el formato AAAA-MM-DD.');
            return null;
        }
        [$anio, $mes, $dia] = array_map('intval', explode('-', $valor));
        if (!checkdate($mes, $dia, $anio)) {
            $this->error($campo, 'La fecha no existe en el calendario.');
            return null;
        }
        return $valor;
    }

    public function opcion(string $campo, $valor, array $permitidos): ?string
    {
        if (!is_string($valor) || !in_array($valor, $permitidos, true)) {
            $this->error($campo, 'El valor seleccionado no es válido.');
            return null;
        }
        return $valor;
    }

    /** Escape HTML de la salida */
    public static function limpiar(?string $texto): string
    {
        return htmlspecialchars($texto ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
