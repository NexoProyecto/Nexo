<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../modelos/GestorTorneos.php';

/** Calendario: próximos partidos y resultados */
class CalendarioController extends ControladorBase
{
    public function index(): void
    {
        $gestor = new GestorTorneos();

        $this->renderizarVista('calendario', [
            'proximos'  => $gestor->listarProximosPartidos(),
            'resultados' => $gestor->listarResultados(),
            'usuario'   => $_SESSION['usuario'] ?? null,
        ]);
    }
}