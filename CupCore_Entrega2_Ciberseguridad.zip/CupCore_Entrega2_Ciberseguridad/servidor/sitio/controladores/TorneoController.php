<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../modelos/GestorTorneos.php';

/** Listado y búsqueda de torneos */
class TorneoController extends ControladorBase
{
    public function index(): void
    {
        $busqueda = trim($_GET['busqueda'] ?? '');
        $modulo   = $_GET['modulo'] ?? 'Todos';

        $gestor = new GestorTorneos();

        $this->renderizarVista('torneos', [
            'torneos'  => $gestor->listarTorneos($busqueda, $modulo),
            'busqueda' => $busqueda,
            'modulo'   => $modulo,
            'usuario'  => $_SESSION['usuario'] ?? null,
        ]);
    }
}