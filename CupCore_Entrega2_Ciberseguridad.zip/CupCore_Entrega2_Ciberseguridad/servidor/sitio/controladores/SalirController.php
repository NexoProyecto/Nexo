<?php
require_once __DIR__ . '/ControladorBase.php';

/** Cierre de sesión */
class SalirController extends ControladorBase
{
    public function index(): void
    {
        $_SESSION = [];
        session_destroy();

        $this->redirigir('inicio');
    }
}