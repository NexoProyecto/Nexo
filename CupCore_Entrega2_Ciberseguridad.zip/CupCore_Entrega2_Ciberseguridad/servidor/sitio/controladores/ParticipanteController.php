<?php
require_once __DIR__ . '/ControladorBase.php';

/** Panel del participante */
class ParticipanteController extends ControladorBase
{
    public function index(): void
    {
        $this->requiereRol('Participante');

        $this->renderizarVista('participante', [
            'usuario' => $_SESSION['usuario'],
        ]);
    }
}