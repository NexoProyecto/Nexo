<?php
/** Clase base de los controladores: vistas, redirección y control de acceso por rol */
abstract class ControladorBase
{
    protected function renderizarVista(string $vista, array $datos = []): void
    {
        extract($datos);
        require __DIR__ . '/../vistas/' . $vista . '.php';
    }

    protected function redirigir(string $ruta): void
    {
        header('Location: index.php?ruta=' . $ruta);
        exit;
    }

    protected function estaLogueado(): bool
    {
        return isset($_SESSION['usuario']);
    }

    protected function requiereRol(string $rol): void
    {
        if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== $rol) {
            $this->redirigir('login');
        }
    }

    protected function redirigirSegunRol(): void
    {
        switch ($_SESSION['usuario']['rol']) {
            case 'Administrador general':
                $this->redirigir('admin');
            case 'Organizador de torneo':
                $this->redirigir('organizador');
            default:
                $this->redirigir('participante');
        }
    }
}