<?php
/** Punto de entrada: sesión y rutas (index.php?ruta=...) */

require_once __DIR__ . '/seguridad/SesionSegura.php';

SesionSegura::iniciar();

// Sesión vencida por inactividad
if (SesionSegura::vencida()) {
    SesionSegura::cerrar();
    SesionSegura::iniciar();
    $_SESSION['aviso'] = 'Sesión cerrada por inactividad.';
    header('Location: index.php?ruta=login');
    exit;
}
SesionSegura::marcarActividad();

$rutas = [
    ''               => ['InicioController', 'index'],
    'inicio'         => ['InicioController', 'index'],
    'torneos'        => ['TorneoController', 'index'],
    'calendario'     => ['CalendarioController', 'index'],
    'login'          => ['LoginController', 'index'],
    'salir'          => ['SalirController', 'index'],
    'admin'          => ['AdminController', 'index'],
    'admin/crear'    => ['AdminController', 'crearUsuario'],
    'admin/eliminar' => ['AdminController', 'eliminarUsuario'],
    'organizador'    => ['OrganizadorController', 'index'],
    'participante'   => ['ParticipanteController', 'index'],
];

$ruta = trim($_GET['ruta'] ?? '', '/');

// Ruta desconocida
if (!isset($rutas[$ruta])) {
    header('Location: index.php?ruta=inicio');
    exit;
}

[$nombreControlador, $accion] = $rutas[$ruta];

require_once __DIR__ . '/controladores/' . $nombreControlador . '.php';

$controlador = new $nombreControlador();
$controlador->$accion();