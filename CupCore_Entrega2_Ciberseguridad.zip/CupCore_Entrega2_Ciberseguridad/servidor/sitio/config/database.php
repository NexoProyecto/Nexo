<?php
/** Conexión a la base CupCore */
define('DB_HOST',    'localhost');
define('DB_PORT',    '3306');
define('DB_NAME',    'CupCore');
define('DB_USER',    'cupcoreapp');
define('DB_PASS',    'Cambiar-App-2026');
define('DB_CHARSET', 'utf8mb4');
