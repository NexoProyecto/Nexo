<?php
// Vista: inicio de sesión ($error, $tokenCsrf)
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SGDM | Iniciar sesión</title>
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/validaciones.css">
</head>
<body>

    <nav class="menu">
        <div class="logo"><img src="img/logo.png" alt="Logo SGDM" class="logo-img"> SGDM</div>
        <ul>
            <li><a href="index.php?ruta=inicio"><span class="icono">🏠</span> Inicio</a></li>
            <li><a href="index.php?ruta=torneos"><span class="icono">𐃯</span> Torneos</a></li>
            <li><a href="index.php?ruta=calendario"><span class="icono">🗓</span> Calendario</a></li>
            <li><a href="index.php?ruta=login" class="activo"><span class="icono">♔</span> Ingresar</a></li>
        </ul>
    </nav>

    <main>
        <header class="encabezado">
            <h1>Iniciar sesión</h1>
            <p>Ingreso al panel según el rol del usuario.</p>
        </header>

        <?php if ($error !== ''): ?>
            <div class="aviso-rol" style="border-color:#c0392b; color:#ffb4ab;">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <section class="seccion">
            <form class="formulario" id="form-ingreso" action="index.php?ruta=login" method="POST" novalidate>
                <input type="hidden" name="ruta" value="login">
                <input type="hidden" name="tokenCsrf" value="<?= htmlspecialchars($tokenCsrf) ?>">
                <label>Correo electrónico
                    <input type="email" name="correo" maxlength="120" placeholder="nombre@correo.com" required>
                </label>
                <span class="mensaje-error" id="error-correo"></span>
                <label>Contraseña
                    <input type="password" name="contrasena" maxlength="72" placeholder="••••••••" required>
                </label>
                <span class="mensaje-error" id="error-contrasena"></span>
                <button type="submit" class="boton">Ingresar</button>
            </form>
        </section>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Usuarios de prueba</h2>
            </div>
            <p style="padding: 0 20px 20px; color: var(--texto-gris);">
                Participante: sofia@cupcore.com &nbsp;·&nbsp;
                Organizador: rfranco@cupcore.com &nbsp;·&nbsp;
                Administrador: admin@cupcore.com &nbsp;·&nbsp;
                Contraseña de los tres: CupCore2026$
            </p>
        </section>

        <footer class="pie">
            SGDM · Sistema de Gestión de Torneos Modulares · Grupo Nexo · 3°MK · 2026
        </footer>
    </main>
    <script src="js/validaciones.js"></script>
</body>
</html>