<?php
// Vista: panel del participante
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SGDM | Mi panel (Participante)</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

    <nav class="menu">
        <div class="logo"><img src="img/logo.png" alt="Logo SGDM" class="logo-img"> SGDM</div>
        <ul>
            <li><a href="index.php?ruta=participante" class="activo"><span class="icono">🎖</span> Mi panel</a></li>
            <li><a href="index.php?ruta=salir"><span class="icono">➜</span> Salir</a></li>
        </ul>
    </nav>

    <main>
        <header class="encabezado">
            <h1>Hola, <?= htmlspecialchars($usuario['nombre']) ?></h1>
            <p>Panel del participante: torneos, partidos y posiciones.</p>
        </header>

        <div class="aviso-rol">Sesión iniciada como: <strong><?= htmlspecialchars($usuario['nombre']) ?></strong> (Participante)</div>

        <section class="estadisticas">
            <div class="estadistica">
                <span class="icono">𐃯</span>
                <div><strong>2</strong><span>Torneos activos</span></div>
            </div>
            <div class="estadistica">
                <span class="icono">⚔</span>
                <div><strong>3</strong><span>Próximos partidos</span></div>
            </div>
            <div class="estadistica">
                <span class="icono">🜲</span>
                <div><strong>5</strong><span>Partidos ganados</span></div>
            </div>
            <div class="estadistica">
                <span class="icono">⍟</span>
                <div><strong>2°</strong><span>Mejor posición</span></div>
            </div>
        </section>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Mis próximos partidos</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Fecha</th><th>Hora</th><th>Torneo</th><th>Rival</th><th>Ronda</th></tr>
                    </thead>
                    <tbody>
                        <tr><td>10/07</td><td>10:00</td><td>Abierto de Ajedrez</td><td>M. Pereira</td><td>Ronda 3</td></tr>
                        <tr><td>12/07</td><td>15:00</td><td>Liga de Tenis de Mesa</td><td>J. Techera</td><td>Fecha 2</td></tr>
                        <tr><td>19/07</td><td>15:00</td><td>Liga de Tenis de Mesa</td><td>C. Núñez</td><td>Fecha 3</td></tr>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Mi perfil</h2>
            </div>
            <form class="formulario">
                <label>Nombre y apellido
                    <input type="text" value="<?= htmlspecialchars($usuario['nombre']) ?>">
                </label>
                <label>Correo electrónico
                    <input type="email" value="<?= htmlspecialchars($usuario['correo']) ?>">
                </label>
                <label>Alias / nombre de jugador
                    <input type="text" value="Sofi_G">
                </label>
                <button type="button" class="boton">Guardar cambios</button>
            </form>
        </section>

        <footer class="pie">
            SGDM · Sistema de Gestión de Torneos Modulares · Grupo Nexo · 3°MK · 2026
        </footer>
    </main>
</body>
</html>