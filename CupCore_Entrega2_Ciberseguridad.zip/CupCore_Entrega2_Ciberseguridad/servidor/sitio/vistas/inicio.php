<?php
// Vista: portada

// Imagen por disciplina y clase CSS por módulo
function imagen_de_disciplina(string $disciplina): string
{
    return match ($disciplina) {
        'Fútbol'  => 'img/futbol.jpg',
        'eSports' => 'img/counter.webp',
        'Ajedrez' => 'img/ajedrez.jpg',
        default   => 'img/pingpong.jpg',
    };
}

function clase_de_modulo(string $modulo): string
{
    return match ($modulo) {
        'Liga'                => 'etiqueta-liga',
        'Eliminación directa' => 'etiqueta-eliminacion',
        default               => 'etiqueta-suizo',
    };
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SGDM | Inicio</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

    <nav class="menu">
        <div class="logo"><img src="img/logo.png" alt="Logo SGDM" class="logo-img"> SGDM</div>
        <ul>
            <li><a href="index.php?ruta=inicio" class="activo"><span class="icono">🏠</span> Inicio</a></li>
            <li><a href="index.php?ruta=torneos"><span class="icono">𐃯</span> Torneos</a></li>
            <li><a href="index.php?ruta=calendario"><span class="icono">🗓</span> Calendario</a></li>
            <li><a href="index.php?ruta=login"><span class="icono">♔</span> Ingresar</a></li>
        </ul>
    </nav>

    <main>
        <header class="encabezado">
            <h1>Bienvenido a SGDM</h1>
            <a href="index.php?ruta=login" class="boton">Iniciar sesión</a>
            <p>Organización, inscripción y seguimiento de torneos deportivos, mentales y electrónicos.</p>
        </header>

        <section class="estadisticas">
            <div class="estadistica">
                <span class="icono">𐃯</span>
                <div><strong><?= $stats['torneos'] ?></strong><span>Torneos creados</span></div>
            </div>
            <div class="estadistica">
                <span class="icono">𖨆</span>
                <div><strong><?= $stats['participantes'] ?></strong><span>Participantes inscriptos</span></div>
            </div>
            <div class="estadistica">
                <span class="icono">🗓</span>
                <div><strong><?= $stats['proximos'] ?></strong><span>Próximos torneos</span></div>
            </div>
            <div class="estadistica">
                <span class="icono">🕹</span>
                <div><strong><?= $stats['partidos'] ?></strong><span>Partidos hoy</span></div>
            </div>
        </section>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Próximos torneos</h2>
                <a href="index.php?ruta=calendario">Ver calendario ›</a>
            </div>

            <div class="lista-torneos">
                <?php foreach ($torneos as $torneo): ?>
                <article class="torneo">
                    <img src="<?= imagen_de_disciplina($torneo['disciplina']) ?>" alt="Torneo de <?= htmlspecialchars($torneo['disciplina']) ?>" class="portada-img">
                    <div class="datos">
                        <span class="etiqueta <?= clase_de_modulo($torneo['modulo']) ?>"><?= htmlspecialchars($torneo['modulo']) ?></span>
                        <h3><?= htmlspecialchars($torneo['nombre']) ?></h3>
                        <div class="dato">🗓 <?= date('d/m', strtotime($torneo['fecha_inicio'])) ?> - <?= date('d/m', strtotime($torneo['fecha_fin'])) ?></div>
                        <div class="dato">Estado: <?= htmlspecialchars($torneo['estado']) ?></div>
                        <a href="index.php?ruta=torneos" class="boton-borde">Ver detalles</a>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Tabla de posiciones · Copa Invierno</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr>
                            <th>#</th><th>Equipo</th><th>PJ</th><th>G</th><th>E</th><th>P</th><th>Pts</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1;
                        foreach ($posiciones as $pos): ?>
                        <tr>
                            <td><?= $i++ ?></td>
                            <td><?= htmlspecialchars($pos['participante']) ?></td>
                            <td><?= $pos['jugados'] ?></td>
                            <td><?= $pos['ganados'] ?></td>
                            <td><?= $pos['empatados'] ?></td>
                            <td><?= $pos['perdidos'] ?></td>
                            <td><?= $pos['puntos'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <footer class="pie">
            SGDM · Sistema de Gestión de Torneos Modulares · Grupo Nexo · 3°MK · 2026
        </footer>
    </main>
</body>
</html>