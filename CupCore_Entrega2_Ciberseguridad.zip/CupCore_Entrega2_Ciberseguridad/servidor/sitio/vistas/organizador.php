<?php
// Vista: panel del organizador
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SGDM | Panel del organizador</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

    <nav class="menu">
        <div class="logo"><img src="img/logo.png" alt="Logo SGDM" class="logo-img"> SGDM</div>
        <ul>
            <li><a href="index.php?ruta=organizador" class="activo"><span class="icono">✎</span> Panel</a></li>
            <li><a href="index.php?ruta=salir"><span class="icono">➜</span> Salir</a></li>
        </ul>
    </nav>

    <main>
        <header class="encabezado">
            <h1>Panel del organizador</h1>
            <p>Gestión de los torneos asignados.</p>
        </header>

        <div class="aviso-rol">
            Sesión iniciada como: <strong><?= htmlspecialchars($usuario['nombre']) ?></strong>
            · Acceso solo a los torneos asignados
        </div>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Acciones</h2>
            </div>
            <div class="panel">
                <a href="#inscribir">
                    <span class="icono"> ╋ </span>
                    <strong>Inscribir participante</strong>
                    <span>Alta de jugador o equipo en el torneo</span>
                </a>
                <a href="#resultados">
                    <span class="icono">🗎</span>
                    <strong>Cargar resultado</strong>
                    <span>Registrar el marcador de un partido</span>
                </a>
                <a href="#mis-torneos">
                    <span class="icono">⟳</span>
                    <strong>Generar rondas</strong>
                    <span>Armar enfrentamientos según el tipo de torneo</span>
                </a>
            </div>
        </section>

        <section class="seccion" id="inscribir">
            <div class="titulo-seccion">
                <h2>Inscribir participante</h2>
            </div>
            <form class="formulario">
                <label>Torneo
                    <select>
                        <option>Copa Invierno · Fútbol 7</option>
                        <option>Abierto de Ajedrez</option>
                    </select>
                </label>
                <label>Nombre del participante o equipo
                    <input type="text" placeholder="Ej: Los Halcones">
                </label>
                <label>Correo de contacto
                    <input type="email" placeholder="equipo@correo.com">
                </label>
                <button type="button" class="boton">Inscribir</button>
            </form>
        </section>

        <section class="seccion" id="resultados">
            <div class="titulo-seccion">
                <h2>Cargar resultado</h2>
            </div>
            <form class="formulario">
                <label>Partido
                    <select>
                        <option>Los Halcones vs Nexo FC · Fecha 5</option>
                        <option>Atlético Sur vs Deportivo Norte · Fecha 5</option>
                    </select>
                </label>
                <label>Goles / puntos del local
                    <input type="number" min="0" placeholder="0">
                </label>
                <label>Goles / puntos del visitante
                    <input type="number" min="0" placeholder="0">
                </label>
                <button type="button" class="boton">Guardar resultado</button>
            </form>
        </section>

        <footer class="pie">
            SGDM · Sistema de Gestión de Torneos Modulares · Grupo Nexo · 3°MK · 2026
        </footer>
    </main>
</body>
</html>