<?php
// Vista: panel del administrador ($usuario, $usuarios, $tokenCsrf, $aviso)
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SGDM | Panel de administración</title>
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/validaciones.css">
</head>
<body>

    <nav class="menu">
        <div class="logo"><img src="img/logo.png" alt="Logo SGDM" class="logo-img"> SGDM</div>
        <ul>
            <li><a href="index.php?ruta=admin" class="activo"><span class="icono">🛠</span> Admin</a></li>
            <li><a href="index.php?ruta=salir"><span class="icono">➜</span> Salir</a></li>
        </ul>
    </nav>

    <main>
        <header class="encabezado">
            <h1>Panel de administración</h1>
            <p>Control total del sistema: usuarios, torneos, módulos y auditoría.</p>
        </header>

        <div class="aviso-rol">
            Sesión iniciada como: <strong><?= htmlspecialchars($usuario['nombre']) ?></strong>
            (<?= htmlspecialchars($usuario['rol']) ?>)
        </div>

        <?php if (!empty($aviso)): ?>
            <div class="aviso-rol"><?= htmlspecialchars($aviso) ?></div>
        <?php endif; ?>

        <section class="seccion" id="usuarios">
            <div class="titulo-seccion">
                <h2>Usuarios del sistema</h2>
                <a href="#nuevo-usuario">+ Nuevo usuario</a>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Usuario</th><th>Correo</th><th>Rol</th><th>Estado</th><th>Acción</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usuarios as $u): ?>
                        <tr>
                            <td><?= htmlspecialchars($u->getNombre()) ?></td>
                            <td><?= htmlspecialchars($u->getCorreo()) ?></td>
                            <td><?= htmlspecialchars($u->getRol()) ?></td>
                            <td><?= htmlspecialchars($u->getEstado()) ?></td>
                            <td>
                                <a href="index.php?ruta=admin/eliminar&id=<?= htmlspecialchars($u->getId()) ?>&tokenCsrf=<?= htmlspecialchars($tokenCsrf) ?>"
                                   class="boton-borde"
                                   onclick="return confirm('¿Dar de baja a <?= htmlspecialchars($u->getNombre()) ?>?');">Dar de baja</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="seccion" id="nuevo-usuario">
            <div class="titulo-seccion">
                <h2>Nuevo usuario</h2>
            </div>
            <form class="formulario" id="form-usuario" action="index.php?ruta=admin/crear" method="POST" novalidate>
                <input type="hidden" name="ruta" value="admin/crear">
                <input type="hidden" name="tokenCsrf" value="<?= htmlspecialchars($tokenCsrf) ?>">
                <label>Nombre y apellido
                    <input type="text" name="nombre" maxlength="60" placeholder="Ej: Camila Pérez" required>
                </label>
                <span class="mensaje-error" id="error-nombre"></span>
                <label>Correo electrónico
                    <input type="email" name="correo" maxlength="120" placeholder="nombre@correo.com" required>
                </label>
                <span class="mensaje-error" id="error-correo"></span>
                <label>Contraseña
                    <input type="password" name="contrasena" maxlength="72" placeholder="••••••••" required>
                </label>
                <span class="mensaje-error" id="error-contrasena"></span>
                <p class="ayuda-campo">
                    Mínimo 8 caracteres, con una mayúscula, una minúscula, un número y un símbolo.
                </p>
                <label>Rol
                    <select name="rol">
                        <option value="Participante">Participante</option>
                        <option value="Organizador de torneo">Organizador de torneo</option>
                        <option value="Administrador general">Administrador general</option>
                    </select>
                </label>
                <button type="submit" class="boton">Crear usuario</button>
            </form>
        </section>

        <footer class="pie">
            SGDM · Sistema de Gestión de Torneos Modulares · Grupo Nexo · 3°MK · 2026
        </footer>
    </main>
    <script src="js/validaciones.js"></script>
</body>
</html>