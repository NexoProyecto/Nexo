<?php
require_once __DIR__ . '/ConexionBD.php';

/**
 * Tabla AuditoriaRegistro.
 * AccionRealizada: ALTA, MODIFICACION, BAJA, LOGIN o LOGOUT (chkAuditoriaRegistroAccion).
 */
class GestorAuditoria
{
    private PDO $bd;

    public function __construct()
    {
        $this->bd = ConexionBD::obtener();
    }

    public function registrar(int $idUsuario, string $accion, string $tabla): bool
    {
        $sql = "insert into AuditoriaRegistro
                    (AccionRealizada, TablaAfectada, FechaHora, IpOrigen, IdUsuario)
                values (:accion, :tabla, now(), :ip, :usuario)";

        $stmt = $this->bd->prepare($sql);
        $stmt->execute([
            ':accion'  => $accion,
            ':tabla'   => $tabla,
            ':ip'      => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            ':usuario' => $idUsuario,
        ]);

        return $stmt->rowCount() > 0;
    }

    public function ultimas(int $limite = 20): array
    {
        $sql = "select AuditoriaRegistro.FechaHora       as fecha_hora,
                       concat(Usuario.Nombre, ' ', Usuario.Apellido) as usuario,
                       AuditoriaRegistro.AccionRealizada as accion,
                       AuditoriaRegistro.TablaAfectada   as tabla,
                       AuditoriaRegistro.IpOrigen        as ip
                from AuditoriaRegistro
                inner join Usuario on AuditoriaRegistro.IdUsuario = Usuario.IdUsuario
                order by AuditoriaRegistro.FechaHora desc
                limit :limite";

        $stmt = $this->bd->prepare($sql);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }
}
