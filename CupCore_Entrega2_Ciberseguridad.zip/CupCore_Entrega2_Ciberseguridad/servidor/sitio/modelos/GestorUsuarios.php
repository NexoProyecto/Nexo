<?php
require_once __DIR__ . '/ConexionBD.php';
require_once __DIR__ . '/Usuario.php';
require_once __DIR__ . '/../seguridad/Contrasena.php';

/** Usuarios: tablas Usuario y Rol */
class GestorUsuarios
{
    /** SELECT de las consultas de lectura */
    private const SELECT_BASE = "
        select Usuario.IdUsuario as id,
               concat(Usuario.Nombre, ' ', Usuario.Apellido) as nombre,
               Usuario.Email    as correo,
               Usuario.Password as contrasena_hash,
               case Rol.NombreRol
                   when 'ADMINISTRADOR' then 'Administrador general'
                   when 'ORGANIZADOR'   then 'Organizador de torneo'
                   else 'Participante'
               end as rol,
               case Usuario.Estado when 'ACTIVO' then 'Activo' else 'Inactivo' end as estado,
               Usuario.FechaAlta as creado_en
        from Usuario
        inner join Rol on Usuario.IdRol = Rol.IdRol";

    /** Rol: texto => código de la tabla Rol */
    private const CODIGO_ROL = [
        'Administrador general' => 'ADMINISTRADOR',
        'Organizador de torneo' => 'ORGANIZADOR',
        'Participante'          => 'PARTICIPANTE',
    ];

    private PDO $bd;

    /** Sin argumento usa ConexionBD::obtener() */
    public function __construct(?PDO $conexion = null)
    {
        $this->bd = $conexion ?? ConexionBD::obtener();
    }

    public function listarUsuarios(): array
    {
        $stmt = $this->bd->query(self::SELECT_BASE . " order by Usuario.IdUsuario");

        $usuarios = [];
        foreach ($stmt as $fila) {
            $usuarios[] = self::mapearFila($fila);
        }

        return $usuarios;
    }

    public function buscarPorCorreo(string $correo): ?Usuario
    {
        $sql  = self::SELECT_BASE . " where lower(Usuario.Email) = lower(:correo) limit 1";
        $stmt = $this->bd->prepare($sql);
        $stmt->execute([':correo' => $correo]);

        $fila = $stmt->fetch();

        return $fila ? self::mapearFila($fila) : null;
    }

    /** Devuelve false si el correo existe o el rol no es válido */
    public function crearUsuario(string $nombre, string $correo, string $contrasena, string $rol): bool
    {
        if ($this->buscarPorCorreo($correo) !== null) {
            return false;
        }

        $idRol = $this->obtenerIdRol($rol);
        if ($idRol === null) {
            return false;
        }

        // Nombre y apellido por separado
        $partes   = explode(' ', trim($nombre), 2);
        $pila     = $partes[0];
        $apellido = $partes[1] ?? '-';

        $sql = "insert into Usuario (Nombre, Apellido, Email, Password,
                                     Estado, FechaAlta, IdRol)
                values (:nombre, :apellido, :correo, :hash, 'ACTIVO', curdate(), :idrol)";

        $stmt = $this->bd->prepare($sql);
        $stmt->execute([
            ':nombre'   => $pila,
            ':apellido' => $apellido,
            ':correo'   => $correo,
            ':hash'     => Contrasena::generarHash($contrasena),
            ':idrol'    => $idRol,
        ]);

        return $stmt->rowCount() > 0;
    }

    /** Borra el usuario; con datos asociados (FK RESTRICT) pasa a INACTIVO */
    public function eliminarUsuario(string $id): void
    {
        try {
            $stmt = $this->bd->prepare("delete from Usuario where IdUsuario = :id");
            $stmt->execute([':id' => $id]);
        } catch (PDOException $e) {
            $stmt = $this->bd->prepare(
                "update Usuario set Estado = 'INACTIVO' where IdUsuario = :id"
            );
            $stmt->execute([':id' => $id]);
        }
    }

    private static function mapearFila(array $fila): Usuario
    {
        return new Usuario(
            (string) $fila['id'],
            $fila['nombre'],
            $fila['correo'],
            $fila['contrasena_hash'],
            $fila['rol'],
            $fila['estado']
        );
    }

    private function obtenerIdRol(string $rol): ?int
    {
        $codigo = self::CODIGO_ROL[$rol] ?? null;
        if ($codigo === null) {
            return null;
        }

        $stmt = $this->bd->prepare("select IdRol from Rol where NombreRol = :nombre limit 1");
        $stmt->execute([':nombre' => $codigo]);

        $fila = $stmt->fetch();

        return $fila ? (int) $fila['IdRol'] : null;
    }
}
