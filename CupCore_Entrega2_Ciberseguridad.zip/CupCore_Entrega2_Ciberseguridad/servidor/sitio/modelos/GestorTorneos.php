<?php
require_once __DIR__ . '/ConexionBD.php';

/** Torneos, calendario, resultados y posiciones */
class GestorTorneos
{
    /** Módulo: código => texto */
    private const MODULO = "case ModuloCompetencia.NombreModulo
                                when 'LIGA'         then 'Liga'
                                when 'ELIMINATORIA' then 'Eliminación directa'
                                else 'Sistema suizo'
                            end";

    /** Estado: código => texto */
    private const ESTADO = "case Torneo.Estado
                                when 'BORRADOR'   then 'Borrador'
                                when 'ABIERTO'    then 'Inscripciones'
                                when 'EN CURSO'   then 'En curso'
                                when 'FINALIZADO' then 'Finalizado'
                                else 'Cancelado'
                            end";

    private PDO $bd;

    public function __construct()
    {
        $this->bd = ConexionBD::obtener();
    }

    /** Torneos con filtros opcionales por nombre y módulo */
    public function listarTorneos(string $busqueda = '', string $modulo = ''): array
    {
        $sql = "select Torneo.IdTorneo     as id,
                       Torneo.NombreTorneo as nombre,
                       Torneo.FechaInicio  as fecha_inicio,
                       Torneo.FechaFin     as fecha_fin,
                       " . self::ESTADO . " as estado,
                       TipoTorneo.NombreTipo as disciplina,
                       " . self::MODULO . " as modulo,
                       concat(Usuario.Nombre, ' ', Usuario.Apellido) as organizador,
                       (select count(*) from Inscripcion
                         where Inscripcion.IdTorneo = Torneo.IdTorneo) as inscriptos
                from Torneo
                inner join TipoTorneo        on Torneo.IdTipoTorneo    = TipoTorneo.IdTipoTorneo
                inner join Usuario           on Torneo.IdUsuario       = Usuario.IdUsuario
                inner join Configura         on Torneo.IdTorneo        = Configura.IdTorneo
                                            and Configura.Habilitado   = 1
                inner join ModuloCompetencia on Configura.IdModulo     = ModuloCompetencia.IdModulo
                where 1 = 1";

        $parametros = [];

        if ($busqueda !== '') {
            $sql .= " and Torneo.NombreTorneo like :busqueda";
            $parametros[':busqueda'] = '%' . $busqueda . '%';
        }

        if ($modulo !== '' && $modulo !== 'Todos') {
            $sql .= " and " . self::MODULO . " = :modulo";
            $parametros[':modulo'] = $modulo;
        }

        $sql .= " order by Torneo.FechaInicio";

        $stmt = $this->bd->prepare($sql);
        $stmt->execute($parametros);

        return $stmt->fetchAll();
    }

    /** Torneos de la portada */
    public function listarTorneosPortada(int $limite = 3): array
    {
        $sql = "select Torneo.IdTorneo     as id,
                       Torneo.NombreTorneo as nombre,
                       Torneo.FechaInicio  as fecha_inicio,
                       Torneo.FechaFin     as fecha_fin,
                       " . self::ESTADO . " as estado,
                       TipoTorneo.NombreTipo as disciplina,
                       " . self::MODULO . " as modulo
                from Torneo
                inner join TipoTorneo        on Torneo.IdTipoTorneo  = TipoTorneo.IdTipoTorneo
                inner join Configura         on Torneo.IdTorneo      = Configura.IdTorneo
                                            and Configura.Habilitado = 1
                inner join ModuloCompetencia on Configura.IdModulo   = ModuloCompetencia.IdModulo
                order by Torneo.FechaInicio
                limit :limite";

        $stmt = $this->bd->prepare($sql);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    /** Partidos sin resultado */
    public function listarProximosPartidos(): array
    {
        $sql = "select Enfrentamiento.IdEnfrentamiento as id,
                       date(Enfrentamiento.FechaHora)  as fecha,
                       time(Enfrentamiento.FechaHora)  as hora,
                       Torneo.NombreTorneo             as torneo,
                       concat('Ronda ', Enfrentamiento.NumeroRonda) as ronda,
                       PartLocal.NombreParticipante  as local,
                       PartVisita.NombreParticipante as visitante
                from Enfrentamiento
                inner join Torneo on Enfrentamiento.IdTorneo = Torneo.IdTorneo
                inner join Inscripcion  InsLocal   on Enfrentamiento.IdInscripcionLocal
                                                    = InsLocal.IdInscripcion
                inner join Participante PartLocal  on InsLocal.IdParticipante
                                                    = PartLocal.IdParticipante
                inner join Inscripcion  InsVisita  on Enfrentamiento.IdInscripcionVisitante
                                                    = InsVisita.IdInscripcion
                inner join Participante PartVisita on InsVisita.IdParticipante
                                                    = PartVisita.IdParticipante
                where Enfrentamiento.EstadoPartido = 'PROGRAMADO'
                order by Enfrentamiento.FechaHora";

        return $this->bd->query($sql)->fetchAll();
    }

    /** Partidos jugados */
    public function listarResultados(): array
    {
        $sql = "select date(Enfrentamiento.FechaHora) as fecha,
                       Torneo.NombreTorneo            as torneo,
                       PartLocal.NombreParticipante   as local,
                       PartVisita.NombreParticipante  as visitante,
                       Resultado.PuntuacionLocal      as puntos_local,
                       Resultado.PuntuacionVisitante  as puntos_visitante
                from Resultado
                inner join Enfrentamiento on Resultado.IdEnfrentamiento
                                           = Enfrentamiento.IdEnfrentamiento
                inner join Torneo on Enfrentamiento.IdTorneo = Torneo.IdTorneo
                inner join Inscripcion  InsLocal   on Enfrentamiento.IdInscripcionLocal
                                                    = InsLocal.IdInscripcion
                inner join Participante PartLocal  on InsLocal.IdParticipante
                                                    = PartLocal.IdParticipante
                inner join Inscripcion  InsVisita  on Enfrentamiento.IdInscripcionVisitante
                                                    = InsVisita.IdInscripcion
                inner join Participante PartVisita on InsVisita.IdParticipante
                                                    = PartVisita.IdParticipante
                order by Enfrentamiento.FechaHora desc";

        return $this->bd->query($sql)->fetchAll();
    }

    /** Tabla de posiciones */
    public function listarPosiciones(int $torneoId): array
    {
        $sql = "select TablaPosiciones.PartidosJugados  as jugados,
                       TablaPosiciones.Victorias        as ganados,
                       TablaPosiciones.Empates          as empatados,
                       TablaPosiciones.Derrotas         as perdidos,
                       TablaPosiciones.PuntosAcumulados as puntos,
                       Participante.NombreParticipante  as participante
                from TablaPosiciones
                inner join Inscripcion  on TablaPosiciones.IdInscripcion
                                         = Inscripcion.IdInscripcion
                inner join Participante on Inscripcion.IdParticipante
                                         = Participante.IdParticipante
                where TablaPosiciones.IdTorneo = :torneo
                order by TablaPosiciones.PuntosAcumulados desc,
                         TablaPosiciones.Victorias desc";

        $stmt = $this->bd->prepare($sql);
        $stmt->execute([':torneo' => $torneoId]);

        return $stmt->fetchAll();
    }

    /** Totales de la portada */
    public function estadisticas(): array
    {
        $contar = function (string $sql): int {
            return (int) $this->bd->query($sql)->fetchColumn();
        };

        return [
            'torneos'       => $contar("select count(*) from Torneo"),
            'participantes' => $contar("select count(*) from Inscripcion"),
            'proximos'      => $contar("select count(*) from Torneo where Estado = 'ABIERTO'"),
            'partidos'      => $contar("select count(*) from Enfrentamiento
                                        where EstadoPartido = 'PROGRAMADO'"),
        ];
    }
}
