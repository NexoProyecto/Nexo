<?php
/** Usuario del sistema */
class Usuario
{
    private string $id;
    private string $nombre;
    private string $correo;
    private string $contrasenaHash;
    private string $rol;
    private string $estado;

    public function __construct(
        string $id,
        string $nombre,
        string $correo,
        string $contrasenaHash,
        string $rol,
        string $estado = 'Activo'
    ) {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->correo = $correo;
        $this->contrasenaHash = $contrasenaHash;
        $this->rol = $rol;
        $this->estado = $estado;
    }

    // Getters

    public function getId(): string
    {
        return $this->id;
    }

    public function getNombre(): string
    {
        return $this->nombre;
    }

    public function getCorreo(): string
    {
        return $this->correo;
    }

    public function getRol(): string
    {
        return $this->rol;
    }

    public function getEstado(): string
    {
        return $this->estado;
    }

    public function getContrasenaHash(): string
    {
        return $this->contrasenaHash;
    }

    public function verificarContrasena(string $intento): bool
    {
        return password_verify($intento, $this->contrasenaHash);
    }
}