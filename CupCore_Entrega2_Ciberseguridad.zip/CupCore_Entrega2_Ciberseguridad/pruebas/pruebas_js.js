/*
 * Pruebas de js/validaciones.js
 * Uso: node pruebas/pruebas_js.js
 */

var v = require('../servidor/sitio/js/validaciones.js');

var totalOk = 0;
var totalError = 0;

function comprobar(descripcion, condicion) {
  if (condicion) {
    totalOk++;
    console.log('  [OK]    ' + descripcion);
  } else {
    totalError++;
    console.log('  [ERROR] ' + descripcion);
  }
}

function titulo(texto) {
  console.log('\n' + texto);
  console.log('-'.repeat(texto.length));
}

console.log('PRUEBAS DE VALIDACION EN EL NAVEGADOR - CupCore (Grupo Nexo)');
console.log('Fecha de ejecución: ' + new Date().toISOString().slice(0, 19).replace('T', ' '));
console.log('Node ' + process.version);

titulo('1. Texto');
comprobar('rechaza el campo vacío', v.validarTexto('   ', 2, 60) !== null);
comprobar('rechaza menos del mínimo', v.validarTexto('A', 2, 60) !== null);
comprobar('rechaza más del máximo', v.validarTexto('A'.repeat(61), 2, 60) !== null);
comprobar('rechaza etiquetas HTML', v.validarTexto('<script>alert(1)</script>', 2, 60) !== null);
comprobar('rechaza comilla simple', v.validarTexto("O'Brien", 2, 60) !== null);
comprobar('acepta un nombre normal', v.validarTexto(' Sofía ', 2, 60) === null);

titulo('2. Correo electrónico');
comprobar('rechaza texto sin arroba', v.validarEmail('sofia.cupcore.com') !== null);
comprobar('rechaza correo sin dominio', v.validarEmail('sofia@') !== null);
comprobar('rechaza correo vacío', v.validarEmail('') !== null);
comprobar('acepta un correo válido', v.validarEmail('sofia@cupcore.com') === null);

titulo('3. Contraseña (misma política que el servidor)');
comprobar('rechaza menos de 8 caracteres', v.validarClave('Ab1$') !== null);
comprobar('rechaza sin mayúscula', v.validarClave('abcdef1$') !== null);
comprobar('rechaza sin minúscula', v.validarClave('ABCDEF1$') !== null);
comprobar('rechaza sin número', v.validarClave('Abcdefg$') !== null);
comprobar('rechaza sin carácter especial', v.validarClave('Abcdefg1') !== null);
comprobar('acepta una contraseña que cumple todo', v.validarClave('Torneo2026$') === null);
comprobar('detecta contraseñas que no coinciden', v.validarClaveRepetida('Torneo2026$', 'Torneo2026#') !== null);
comprobar('acepta contraseñas iguales', v.validarClaveRepetida('Torneo2026$', 'Torneo2026$') === null);

titulo('4. Identificadores numéricos');
comprobar('rechaza un identificador con texto', v.validarEntero('7 or 1=1', 1, 100) !== null);
comprobar('rechaza un identificador fuera de rango', v.validarEntero('500', 1, 100) !== null);
comprobar('acepta un identificador válido', v.validarEntero('7', 1, 100) === null);

titulo('5. Coincidencia con el servidor');
var casos = ['Ab1$', 'abcdef1$', 'ABCDEF1$', 'Abcdefg$', 'Abcdefg1', 'Torneo2026$'];
var esperado = [true, true, true, true, true, false];
var coincide = true;
for (var i = 0; i < casos.length; i++) {
  if ((v.validarClave(casos[i]) !== null) !== esperado[i]) { coincide = false; }
}
comprobar('las 6 contraseñas de prueba dan el mismo veredicto que Validador.php', coincide);

console.log('\n' + '='.repeat(60));
console.log('RESULTADO: ' + totalOk + ' pruebas correctas, ' + totalError + ' con error');
console.log('='.repeat(60));
process.exit(totalError === 0 ? 0 : 1);
