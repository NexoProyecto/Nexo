<?php
/**
 * Prueba del ingreso contra MariaDB: ControlAcceso -> GestorUsuarios -> base CupCore.
 * Uso: php pruebas/pruebas_login.php
 * Conexión: servidor/sitio/config/database.php, o CUPCORE_SOCKET, CUPCORE_PORT,
 * CUPCORE_USER y CUPCORE_PASS. Los cambios en la base se deshacen al terminar.
 */

require_once __DIR__ . '/../servidor/sitio/seguridad/Validador.php';
require_once __DIR__ . '/../servidor/sitio/seguridad/Contrasena.php';
require_once __DIR__ . '/../servidor/sitio/seguridad/RegistroSeguridad.php';
require_once __DIR__ . '/../servidor/sitio/modelos/Usuario.php';
require_once __DIR__ . '/../servidor/sitio/modelos/GestorUsuarios.php';
require_once __DIR__ . '/../servidor/sitio/seguridad/ControlAcceso.php';

const CLAVE_DEMO = 'CupCore2026$';

$totalOk = 0;
$totalError = 0;

function comprobar(string $descripcion, bool $condicion): void
{
    global $totalOk, $totalError;
    if ($condicion) {
        $totalOk++;
        echo "  [OK]    $descripcion\n";
    } else {
        $totalError++;
        echo "  [ERROR] $descripcion\n";
    }
}

function titulo(string $texto): void
{
    echo "\n$texto\n" . str_repeat('-', mb_strlen($texto)) . "\n";
}

function conectar(): PDO
{
    $socket = getenv('CUPCORE_SOCKET');
    $usuario = getenv('CUPCORE_USER') ?: DB_USER;
    $clave = getenv('CUPCORE_PASS');
    $clave = $clave === false ? DB_PASS : $clave;

    $dsn = $socket
        ? 'mysql:unix_socket=' . $socket . ';dbname=' . DB_NAME . ';charset=utf8mb4'
        : 'mysql:host=' . DB_HOST . ';port=' . (getenv('CUPCORE_PORT') ?: DB_PORT)
          . ';dbname=' . DB_NAME . ';charset=utf8mb4';

    return new PDO($dsn, $usuario, $clave, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
}

echo "PRUEBA DE INTEGRACION DEL INGRESO - CupCore (Grupo Nexo)\n";
echo 'Fecha: ' . date('Y-m-d H:i:s') . '  |  PHP ' . PHP_VERSION . "\n";

try {
    $conexion = conectar();
} catch (PDOException $e) {
    echo "\nNo se pudo conectar a la base: " . $e->getMessage() . "\n";
    echo "Verificar que MariaDB este encendido y que la base CupCore este cargada.\n";
    exit(2);
}

echo 'Base  : ' . $conexion->query('select version()')->fetchColumn() . "\n";

$conexion->beginTransaction();   // todo lo que se escriba se deshace al final

$archivoLog = sys_get_temp_dir() . '/cupcore-integracion-' . getmypid() . '.log';
@unlink($archivoLog);
$registro = new RegistroSeguridad($archivoLog);
$gestor   = new GestorUsuarios($conexion);
$control  = new ControlAcceso($gestor, $registro);

titulo('1. Datos cargados en la base');
$filas = (int) $conexion->query('select count(*) from Usuario')->fetchColumn();
comprobar("la tabla Usuario tiene registros cargados ($filas)", $filas > 0);
$hash = $conexion->query("select Password from Usuario where Email = 'sofia@cupcore.com'")->fetchColumn();
comprobar('la contraseña está guardada como hash bcrypt, no en texto plano',
    is_string($hash) && strpos($hash, '$2y$') === 0);
comprobar('el hash guardado usa costo 12',
    (int) (Contrasena::informacion($hash)['options']['cost'] ?? 0) === 12);
comprobar('el hash no contiene la contraseña',
    strpos($hash, CLAVE_DEMO) === false);

titulo('2. Ingreso correcto');
$r = $control->ingresar('sofia@cupcore.com', CLAVE_DEMO, '10.0.10.11');
comprobar('un usuario activo con la clave correcta ingresa', $r['ok'] === true);
comprobar('devuelve un objeto Usuario del modelo', $r['usuario'] instanceof Usuario);
comprobar('el rol llega traducido a la etiqueta de la interfaz',
    in_array($r['usuario']->getRol(), ['Administrador general', 'Organizador de torneo', 'Participante'], true));
$r = $control->ingresar('  SOFIA@CupCore.com  ', CLAVE_DEMO, '10.0.10.11');
comprobar('el correo con mayúsculas y espacios también ingresa', $r['ok'] === true);

titulo('3. Ingresos rechazados');
$r = $control->ingresar('sofia@cupcore.com', 'ClaveEquivocada1$', '10.0.10.12');
comprobar('la contraseña equivocada es rechazada', $r['ok'] === false);
comprobar('el mensaje no revela si falló el correo o la clave',
    $r['mensaje'] === ControlAcceso::MENSAJE_ERROR);
$r = $control->ingresar('nadie@cupcore.com', CLAVE_DEMO, '10.0.10.12');
comprobar('un correo inexistente recibe el mismo mensaje genérico',
    $r['ok'] === false && $r['mensaje'] === ControlAcceso::MENSAJE_ERROR);
$r = $control->ingresar('sin-arroba', CLAVE_DEMO, '10.0.10.12');
comprobar('un correo mal formado se rechaza antes de consultar la base', $r['ok'] === false);
$r = $control->ingresar('sofia@cupcore.com', '', '10.0.10.12');
comprobar('la contraseña vacía se rechaza', $r['ok'] === false);

titulo('4. Inyección SQL sobre el formulario de ingreso');
$antes = (int) $conexion->query('select count(*) from Usuario')->fetchColumn();
foreach ([
    "sofia@cupcore.com' or '1'='1",
    "' or 1=1 -- ",
    "admin@cupcore.com'; drop table Usuario; -- ",
    "' union select 1,2,3,4,5,6,7 -- ",
] as $intento) {
    $r = $control->ingresar($intento, 'cualquiera', '190.64.12.7');
    comprobar('no autentica con: ' . substr($intento, 0, 40), $r['ok'] === false);
}
$despues = (int) $conexion->query('select count(*) from Usuario')->fetchColumn();
comprobar('la tabla Usuario sigue intacta después de los intentos', $antes === $despues);

titulo('5. Cuenta dada de baja (baja lógica)');
$conexion->exec("update Usuario set Estado = 'INACTIVO' where Email = 'agustin@cupcore.com'");
$r = $control->ingresar('agustin@cupcore.com', CLAVE_DEMO, '10.0.10.13');
comprobar('un usuario INACTIVO no ingresa aunque la clave sea correcta', $r['ok'] === false);
$conexion->exec("update Usuario set Estado = 'ACTIVO' where Email = 'agustin@cupcore.com'");
$r = $control->ingresar('agustin@cupcore.com', CLAVE_DEMO, '10.0.10.13');
comprobar('reactivada la cuenta, vuelve a ingresar', $r['ok'] === true);

titulo('6. Límite de intentos fallidos');
$registroLimite = new RegistroSeguridad($archivoLog . '.limite');
@unlink($archivoLog . '.limite');
$controlLimite = new ControlAcceso($gestor, $registroLimite);
for ($i = 1; $i <= 5; $i++) {
    $controlLimite->ingresar('admin@cupcore.com', 'malaClave1$', '190.64.12.7');
}
$r = $controlLimite->ingresar('admin@cupcore.com', CLAVE_DEMO, '190.64.12.7');
comprobar('tras 5 intentos fallidos se rechaza incluso la clave correcta', $r['ok'] === false);
comprobar('el mensaje informa el bloqueo temporal',
    $r['mensaje'] === ControlAcceso::MENSAJE_BLOQUEO);
@unlink($archivoLog . '.limite');

titulo('7. Alta de usuario con la contraseña cifrada');
$correoNuevo = 'prueba.integracion@cupcore.com';
$creado = $gestor->crearUsuario('Prueba Integracion', $correoNuevo, 'Torneo2026$', 'Participante');
comprobar('se crea el usuario nuevo', $creado === true);
$nuevo = $gestor->buscarPorCorreo($correoNuevo);
comprobar('el usuario nuevo se encuentra por correo', $nuevo !== null);
comprobar('su contraseña quedó guardada como hash bcrypt de costo 12',
    $nuevo !== null && strpos($nuevo->getContrasenaHash(), '$2y$12$') === 0);
comprobar('puede ingresar con su contraseña',
    $control->ingresar($correoNuevo, 'Torneo2026$', '10.0.10.14')['ok'] === true);
comprobar('no se permite repetir el correo',
    $gestor->crearUsuario('Otro Nombre', $correoNuevo, 'Torneo2026$', 'Participante') === false);
comprobar('no se permite un rol inventado',
    $gestor->crearUsuario('Tercero', 'tercero@cupcore.com', 'Torneo2026$', 'Superusuario') === false);

$conexion->rollBack();   // se deshacen todos los cambios de la prueba
@unlink($archivoLog);

titulo('8. La base quedó como estaba');
$conexion2 = conectar();
$existe = $conexion2->prepare('select count(*) from Usuario where Email = :correo');
$existe->execute([':correo' => $correoNuevo]);
comprobar('el usuario de prueba no quedó en la base', (int) $existe->fetchColumn() === 0);
$estado = $conexion2->query("select Estado from Usuario where Email = 'agustin@cupcore.com'")->fetchColumn();
comprobar('la cuenta usada en la prueba de baja quedó ACTIVO', $estado === 'ACTIVO');

echo "\n" . str_repeat('=', 60) . "\n";
echo "RESULTADO: $totalOk pruebas correctas, $totalError con error\n";
echo str_repeat('=', 60) . "\n";
exit($totalError === 0 ? 0 : 1);
