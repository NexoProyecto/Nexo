<?php
/**
 * Pruebas de la capa de seguridad, con SQLite en memoria.
 * Uso: php pruebas/pruebas_php.php
 */

require_once __DIR__ . '/../servidor/sitio/seguridad/Validador.php';
require_once __DIR__ . '/../servidor/sitio/seguridad/Contrasena.php';
require_once __DIR__ . '/../servidor/sitio/seguridad/RegistroSeguridad.php';
require_once __DIR__ . '/../servidor/sitio/seguridad/SesionSegura.php';

$totalOk = 0;
$totalError = 0;

function comprobar(string $descripcion, bool $condicion): void
{
    global $totalOk, $totalError;
    if ($condicion) {
        $totalOk++;
        echo "  [OK]    $descripcion\n";
    } else {
        $totalError++;
        echo "  [ERROR] $descripcion\n";
    }
}

function titulo(string $texto): void
{
    echo "\n$texto\n";
    echo str_repeat('-', mb_strlen($texto)) . "\n";
}

echo "PRUEBAS DE LA CAPA DE SEGURIDAD - CupCore (Grupo Nexo)\n";
echo "Fecha de ejecución: " . date('Y-m-d H:i:s') . "\n";
echo "PHP " . PHP_VERSION . "\n";

// ---------------------------------------------------------------------------
titulo('1. Validador: correo electrónico');
$v = new Validador();
comprobar('acepta un correo válido y lo pasa a minúsculas',
    $v->email('correo', ' Sofia@CupCore.com ') === 'sofia@cupcore.com');
comprobar('rechaza un correo sin arroba', (new Validador())->email('correo', 'sofia.cupcore.com') === null);
comprobar('rechaza el campo vacío', (new Validador())->email('correo', '') === null);
comprobar('rechaza un intento de inyección SQL en el correo',
    (new Validador())->email('correo', "admin@cupcore.com' or '1'='1") === null);

titulo('2. Validador: contraseñas según la política del proyecto');
comprobar('rechaza menos de 8 caracteres', (new Validador())->clave('clave', 'Ab1$') === null);
comprobar('rechaza sin mayúscula', (new Validador())->clave('clave', 'abcdef1$') === null);
comprobar('rechaza sin minúscula', (new Validador())->clave('clave', 'ABCDEF1$') === null);
comprobar('rechaza sin número', (new Validador())->clave('clave', 'Abcdefg$') === null);
comprobar('rechaza sin carácter especial', (new Validador())->clave('clave', 'Abcdefg1') === null);
comprobar('acepta una contraseña que cumple todo', (new Validador())->clave('clave', 'Torneo2026$') === 'Torneo2026$');
comprobar('rechaza más de 72 caracteres (límite de bcrypt)',
    (new Validador())->clave('clave', str_repeat('Ab1$', 20)) === null);

titulo('3. Validador: texto, enteros, fechas y listas cerradas');
comprobar('rechaza etiquetas HTML en un nombre (XSS)',
    (new Validador())->texto('nombre', '<script>alert(1)</script>', 2, 60) === null);
comprobar('rechaza comilla simple en un nombre',
    (new Validador())->texto('nombre', "O'Brien", 2, 60) === null);
comprobar('acepta un nombre normal', (new Validador())->texto('nombre', ' Sofía ', 2, 60) === 'Sofía');
comprobar('rechaza un identificador no numérico', (new Validador())->entero('id', '7 or 1=1') === null);
comprobar('acepta un identificador numérico', (new Validador())->entero('id', '7') === 7);
comprobar('rechaza el 30 de febrero', (new Validador())->fecha('fecha', '2026-02-30') === null);
comprobar('acepta una fecha real', (new Validador())->fecha('fecha', '2026-09-14') === '2026-09-14');
comprobar('rechaza un estado que no está en el dominio de la base',
    (new Validador())->opcion('estado', 'BORRADO', ['ABIERTO', 'EN CURSO', 'FINALIZADO']) === null);
comprobar('acepta un estado del dominio de la base',
    (new Validador())->opcion('estado', 'EN CURSO', ['ABIERTO', 'EN CURSO', 'FINALIZADO']) === 'EN CURSO');
comprobar('escapa el HTML antes de imprimirlo',
    Validador::limpiar('<b>"hola"</b>') === '&lt;b&gt;&quot;hola&quot;&lt;/b&gt;');
$acumula = new Validador();
$acumula->email('correo', 'mal');
$acumula->clave('clave', '123');
comprobar('acumula un mensaje de error por cada campo', count($acumula->errores()) === 2);

titulo('4. Contraseñas: cifrado con bcrypt');
$hash1 = Contrasena::generarHash('Torneo2026$');
$hash2 = Contrasena::generarHash('Torneo2026$');
comprobar('el hash empieza con el prefijo de bcrypt ($2y$)', strpos($hash1, '$2y$') === 0);
comprobar('el hash no contiene la contraseña original', strpos($hash1, 'Torneo2026') === false);
comprobar('dos hashes de la misma clave son distintos (salt único)', $hash1 !== $hash2);
comprobar('verifica correctamente la clave buena', Contrasena::verificar('Torneo2026$', $hash1) === true);
comprobar('rechaza una clave equivocada', Contrasena::verificar('Torneo2026#', $hash1) === false);
$info = Contrasena::informacion($hash1);
comprobar('el algoritmo registrado es bcrypt', $info['algoName'] === 'bcrypt');
comprobar('el costo aplicado es 12', (int) $info['options']['cost'] === 12);
comprobar('un hash con costo 10 se marca para actualización',
    Contrasena::necesitaActualizacion(password_hash('Torneo2026$', PASSWORD_BCRYPT, ['cost' => 10])) === true);
$provisional = Contrasena::provisional();
comprobar('la clave provisional cumple la política',
    (new Validador())->clave('clave', $provisional) === $provisional);

titulo('5. Sesión: caducidad y token CSRF');
$_SESSION = [];
$_SESSION['ultimoAcceso'] = time();
comprobar('una sesión recién usada no está vencida', SesionSegura::vencida() === false);
$_SESSION['ultimoAcceso'] = time() - (31 * 60);
comprobar('a los 31 minutos de inactividad la sesión está vencida', SesionSegura::vencida() === true);
$_SESSION = [];
$token = SesionSegura::tokenCsrf();
comprobar('el token CSRF tiene 64 caracteres', strlen($token) === 64);
comprobar('el token válido se acepta', SesionSegura::tokenCsrfValido($token) === true);
comprobar('un token falso se rechaza', SesionSegura::tokenCsrfValido('0000') === false);
comprobar('un formulario sin token se rechaza', SesionSegura::tokenCsrfValido(null) === false);

// ---------------------------------------------------------------------------
titulo('6. Registro de accesos y limite de intentos');

$archivoLog = sys_get_temp_dir() . '/cupcore-prueba-' . getmypid() . '.log';
@unlink($archivoLog);
$registro = new RegistroSeguridad($archivoLog);

for ($i = 1; $i <= 4; $i++) {
    $registro->intentoFallido('sofia@cupcore.com', '10.0.10.99');
}
comprobar('con 4 intentos fallidos la cuenta todavía no está bloqueada',
    $registro->estaBloqueado('sofia@cupcore.com') === false);
comprobar('cuenta 4 intentos fallidos en la ventana de 15 minutos',
    $registro->fallosRecientes('sofia@cupcore.com') === 4);
$registro->intentoFallido('sofia@cupcore.com', '10.0.10.99');
comprobar('al quinto intento fallido la cuenta queda bloqueada',
    $registro->estaBloqueado('sofia@cupcore.com') === true);
comprobar('otra cuenta no queda afectada por el bloqueo',
    $registro->estaBloqueado('agustin@cupcore.com') === false);
$registro->cuentaBloqueada('sofia@cupcore.com', '10.0.10.99');
$registro->ingresoCorrecto('agustin@cupcore.com', '10.0.10.11');

titulo('7. Registro de seguridad que lee fail2ban');
$lineas = file($archivoLog, FILE_IGNORE_NEW_LINES);
comprobar('el archivo de registro se creó', count($lineas) > 0);
comprobar('el formato de línea es el esperado por el filtro de fail2ban',
    (bool) preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} CUPCORE LOGIN FALLIDO usuario=\S+ ip=10\.0\.10\.99$/', $lineas[0]));
comprobar('el registro guarda el evento de ingreso correcto',
    strpos(implode("\n", $lineas), 'CUPCORE LOGIN OK') !== false);
comprobar('el bloqueo también queda registrado',
    strpos(implode("\n", $lineas), 'CUENTA BLOQUEADA') !== false);

// Correo con salto de línea y un evento falso
$registroInyeccion = new RegistroSeguridad($archivoLog);
$contenidoAntes = file($archivoLog, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$lineasAntes = count($contenidoAntes);
$okAntes = substr_count(implode("\n", $contenidoAntes), 'CUPCORE LOGIN OK');
$registroInyeccion->intentoFallido("admin ip=1.2.3.4\n2026-01-01 00:00:00 CUPCORE LOGIN OK usuario=admin", '10.0.10.99');
$lineasDespues = file($archivoLog, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$lineaInyeccion = end($lineasDespues);
comprobar('el intento de inyección en el registro agrega una sola línea',
    count($lineasDespues) === $lineasAntes + 1);
comprobar('la línea inyectada conserva el formato del filtro de fail2ban',
    (bool) preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} CUPCORE LOGIN FALLIDO usuario=\S+ ip=10\.0\.10\.99$/', $lineaInyeccion));
comprobar('el texto inyectado no agrega ningún evento LOGIN OK falso',
    substr_count(implode("\n", $lineasDespues), 'CUPCORE LOGIN OK') === $okAntes);
@unlink($archivoLog);

// ---------------------------------------------------------------------------
echo "\n" . str_repeat('=', 60) . "\n";
echo "RESULTADO: $totalOk pruebas correctas, $totalError con error\n";
echo str_repeat('=', 60) . "\n";
exit($totalError === 0 ? 0 : 1);
