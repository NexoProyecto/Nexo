<?php
/**
 * Hash bcrypt de una contraseña, tal como se guarda en Usuario.Password.
 * Uso: php pruebas/demo_hash.php
 */

require_once __DIR__ . '/../servidor/sitio/seguridad/Contrasena.php';

echo "EVIDENCIA DE CIFRADO DE CONTRASEÑAS - CupCore (Grupo Nexo)\n";
echo "Fecha: " . date('Y-m-d H:i:s') . "  |  PHP " . PHP_VERSION . "\n";
echo str_repeat('=', 78) . "\n\n";

echo "1. CÓMO SE GUARDA CADA CUENTA EN LA TABLA Usuario\n\n";
$cuentas = [
    ['admin@cupcore.com',  'Torneo2026$'],
    ['sofia@cupcore.com',  'Torneo2026$'],   // misma clave que la anterior, a propósito
    ['rfranco@cupcore.com', 'Nexo#2026mk'],
];
foreach ($cuentas as [$correo, $clave]) {
    $hash = Contrasena::generarHash($clave);
    printf("   Email    : %s\n", $correo);
    printf("   Password : %s\n", $hash);
    printf("   Largo    : %d caracteres\n\n", strlen($hash));
}
echo "   Las dos primeras cuentas usan la MISMA contraseña y el hash es distinto:\n";
echo "   eso lo produce el salt único que genera bcrypt en cada llamada.\n\n";

echo str_repeat('-', 78) . "\n";
echo "2. PARTES DE UN HASH BCRYPT\n\n";
$ejemplo = Contrasena::generarHash('Torneo2026$');
echo "   $ejemplo\n\n";
printf("   %-12s %s\n", 'algoritmo', substr($ejemplo, 0, 4) . '   (bcrypt)');
printf("   %-12s %s\n", 'costo', substr($ejemplo, 4, 2) . '     (2^12 = 4096 vueltas)');
printf("   %-12s %s\n", 'salt', substr($ejemplo, 7, 22));
printf("   %-12s %s\n", 'hash', substr($ejemplo, 29));
echo "\n   La contraseña original no está en ninguna de esas partes.\n\n";

echo str_repeat('-', 78) . "\n";
echo "3. VERIFICACIÓN DE UNA CLAVE CONTRA EL HASH GUARDADO\n\n";
$pruebas = ['Torneo2026$', 'torneo2026$', 'Torneo2026', 'Torneo2026#', ''];
foreach ($pruebas as $intento) {
    $resultado = Contrasena::verificar($intento, $ejemplo) ? 'ACEPTADA' : 'RECHAZADA';
    printf("   clave escrita: %-16s -> %s\n", $intento === '' ? '(vacía)' : $intento, $resultado);
}
echo "\n   Cambiar una sola letra o su mayúscula ya invalida el ingreso.\n\n";

echo str_repeat('-', 78) . "\n";
echo "4. COSTO DE BCRYPT Y FUERZA BRUTA\n\n";
foreach ([4, 8, 10, 12] as $costo) {
    $inicio = microtime(true);
    password_hash('Torneo2026$', PASSWORD_BCRYPT, ['cost' => $costo]);
    $ms = (microtime(true) - $inicio) * 1000;
    printf("   costo %-3d -> %7.2f ms por hash\n", $costo, $ms);
}
echo "\n   El proyecto usa costo 12: para el usuario es imperceptible, pero un\n";
echo "   atacante que pruebe millones de claves necesita ese tiempo en cada intento.\n\n";

echo str_repeat('-', 78) . "\n";
echo "5. CONTRASEÑAS PROVISIONALES PARA CUENTAS NUEVAS\n\n";
for ($i = 0; $i < 3; $i++) {
    echo "   " . Contrasena::provisional() . "\n";
}
echo "\n   Cumplen la política del proyecto y el usuario debe cambiarlas al primer ingreso.\n";
