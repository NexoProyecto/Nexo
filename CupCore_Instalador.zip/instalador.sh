#!/usr/bin/env bash
set -Eeuo pipefail

APP_NAME="CupCore"
COMPOSE_FILE=""
ENV_FILE=".env"
BACKUP_DEFAULT="$HOME/base-de-datos.sql"
PORT_DEFAULT="8080"

RED=$'\033[0;31m'; GREEN=$'\033[0;32m'; YELLOW=$'\033[1;33m'; BLUE=$'\033[0;34m'; RESET=$'\033[0m'

ok(){ echo "${GREEN}[OK]${RESET} $*"; }
warn(){ echo "${YELLOW}[AVISO]${RESET} $*"; }
err(){ echo "${RED}[ERROR]${RESET} $*" >&2; }
pause(){ read -r -p "Presioná Enter para continuar..." _; }
need_cmd(){ command -v "$1" >/dev/null 2>&1; }

find_compose() {
  if [[ -f compose.yaml ]]; then COMPOSE_FILE="compose.yaml"
  elif [[ -f compose.yml ]]; then COMPOSE_FILE="compose.yml"
  elif [[ -f docker-compose.yml ]]; then COMPOSE_FILE="docker-compose.yml"
  else COMPOSE_FILE=""
  fi
}

compose() {
  sudo docker compose -f "$COMPOSE_FILE" "$@"
}

check_files() {
  find_compose
  if [[ -z "$COMPOSE_FILE" ]]; then
    err "No encuentro compose.yaml, compose.yml ni docker-compose.yml en: $PWD"
    return 1
  fi
  if [[ ! -f Dockerfile ]]; then
    err "No encuentro Dockerfile en: $PWD"
    return 1
  fi
  if [[ ! -f "$ENV_FILE" ]]; then
    err "No existe $ENV_FILE. Crealo con DB_ROOT_PASSWORD y DB_PASSWORD (ver README-INSTALACION.md)."
    return 1
  fi
  if ! grep -q '^DB_ROOT_PASSWORD=.' "$ENV_FILE" || ! grep -q '^DB_PASSWORD=.' "$ENV_FILE"; then
    err "Faltan DB_ROOT_PASSWORD o DB_PASSWORD en $ENV_FILE."
    return 1
  fi
  if ! need_cmd docker; then err "Docker no está instalado."; return 1; fi
  if ! sudo docker compose version >/dev/null 2>&1; then
    err "Docker Compose no está disponible con 'sudo docker compose'."
    return 1
  fi
  ok "Archivos y Docker encontrados."
}

install_docker_if_possible() {
  if need_cmd docker && sudo docker compose version >/dev/null 2>&1; then
    ok "Docker y Docker Compose ya están instalados."
    return 0
  fi
  warn "Intentaré instalar Docker Engine y el plugin Compose desde los repositorios configurados."
  echo "En AlmaLinux puede requerir que el repositorio de Docker ya esté configurado."
  sudo dnf install -y docker docker-compose-plugin || {
    err "No pude instalar Docker desde los repositorios actuales."
    echo "Instalá Docker Engine y el plugin Compose para AlmaLinux y volvé a ejecutar este instalador."
    return 1
  }
  sudo systemctl enable --now docker
  sudo docker compose version
}

create_env_if_missing() {
  if [[ -f "$ENV_FILE" ]]; then
    warn "Ya existe $ENV_FILE; no lo voy a sobrescribir."
    return
  fi
  echo "Creación de credenciales para la base de datos Docker."
  read -r -s -p "Contraseña para root de MariaDB: " rootpw; echo
  read -r -s -p "Contraseña para el usuario cupcore: " dbpw; echo
  if [[ -z "$rootpw" || -z "$dbpw" ]]; then
    err "Las contraseñas no pueden estar vacías."
    return 1
  fi
  umask 077
  {
    printf 'DB_ROOT_PASSWORD="%s"\n' "${rootpw//\"/\\\"}"
    printf 'DB_PASSWORD="%s"\n' "${dbpw//\"/\\\"}"
  } > "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  unset rootpw dbpw
  ok "Creado .env con permisos privados."
}

validate_compose() {
  check_files || return 1
  if compose config >/dev/null; then
    ok "La configuración de Compose es válida."
  else
    err "Compose encontró un error. No iniciaré los contenedores."
    compose config
    return 1
  fi
}

deploy() {
  find_compose
  if [[ -z "$COMPOSE_FILE" ]]; then
    err "No se encontró el archivo Compose."
    return 1
  fi
  validate_compose || return 1

  echo
  warn "Esto creará/actualizará contenedores y puede crear una base de datos Docker vacía."
  echo "No detiene ni borra el Apache o MariaDB instalados directamente en AlmaLinux."
  read -r -p "¿Continuar? Escribí SI para continuar: " answer
  [[ "$answer" == "SI" ]] || { echo "Cancelado."; return; }

  sudo systemctl enable --now docker
  compose pull db
  compose up -d --build
  ok "Se solicitó iniciar CupCore."
  compose ps

  echo
  if [[ -f "$BACKUP_DEFAULT" && -s "$BACKUP_DEFAULT" ]]; then
    echo "Encontré un respaldo no vacío en $BACKUP_DEFAULT."
    echo "La importación solo se hará si confirmás; puede modificar la base Docker."
    read -r -p "¿Importar ese respaldo a la base Docker cupcore? Escribí SI: " imp
    if [[ "$imp" == "SI" ]]; then
      echo "Esperando hasta 60 segundos a que MariaDB responda..."
      ready=0
      for _ in $(seq 1 30); do
        if compose exec -T db mariadb-admin ping -h 127.0.0.1 -uroot --password="$(env_value DB_ROOT_PASSWORD)" >/dev/null 2>&1; then ready=1; break; fi
        sleep 2
      done
      if [[ "$ready" != 1 ]]; then
        err "MariaDB aún no responde. Mirá la opción de logs y volvé a intentar."
        return 1
      fi
      if compose exec -T db mariadb -uroot --password="$(env_value DB_ROOT_PASSWORD)" -e 'DROP DATABASE IF EXISTS `base-de-datos`; CREATE DATABASE `base-de-datos`;' &&
         compose exec -T db mariadb -uroot --password="$(env_value DB_ROOT_PASSWORD)" 'base-de-datos' < "$BACKUP_DEFAULT"; then
        ok "Respaldo importado a la base Docker."
      else
        err "Falló la importación. Revisá los logs antes de continuar."
        return 1
      fi
    fi
  else
    warn "No encontré $BACKUP_DEFAULT. La base Docker puede estar vacía; no se importó ningún dato."
  fi
  echo
  echo "Probá desde el navegador: http://IP-DEL-SERVIDOR:8080"
  echo "Si no abre, revisá la configuración de la app y los logs."
}

env_value() {
  local key="$1"
  sed -n "s/^${key}=\"\\(.*\\)\"$/\\1/p; s/^${key}=\\([^\"].*\\)$/\\1/p" "$ENV_FILE" | head -n1
}

status() {
  find_compose
  [[ -n "$COMPOSE_FILE" ]] || { err "No se encontró archivo Compose."; return 1; }
  compose ps
  echo
  sudo docker ps --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}'
}

logs() {
  find_compose
  [[ -n "$COMPOSE_FILE" ]] || { err "No se encontró archivo Compose."; return 1; }
  echo "1) Web  2) Base de datos  3) Todos"
  read -r -p "Elegí: " choice
  case "$choice" in
    1) compose logs --tail=100 web ;;
    2) compose logs --tail=100 db ;;
    3) compose logs --tail=100 ;;
    *) echo "Opción inválida." ;;
  esac
}

backup_db() {
  find_compose
  [[ -n "$COMPOSE_FILE" ]] || { err "No se encontró archivo Compose."; return 1; }
  local rootpw dest
  rootpw="$(env_value DB_ROOT_PASSWORD)"
  [[ -n "$rootpw" ]] || { err "No pude leer DB_ROOT_PASSWORD de .env."; return 1; }
  dest="$HOME/cupcore-backup-$(date +%Y%m%d-%H%M%S).sql"
  if compose exec -T db mariadb-dump -uroot --password="$rootpw" 'base-de-datos' > "$dest"; then
    chmod 600 "$dest"
    if [[ -s "$dest" ]]; then ok "Respaldo creado: $dest"; else err "El archivo quedó vacío."; rm -f "$dest"; return 1; fi
  else
    rm -f "$dest"
    err "No se pudo respaldar la base. Verificá que el contenedor db esté funcionando."
    return 1
  fi
}

stop_services() {
  find_compose
  [[ -n "$COMPOSE_FILE" ]] || { err "No se encontró archivo Compose."; return 1; }
  warn "Esto detiene los contenedores de este proyecto, pero no borra los datos del volumen."
  read -r -p "¿Detenerlos? Escribí SI: " answer
  [[ "$answer" == "SI" ]] || return
  compose stop
}

menu() {
  while true; do
    clear 2>/dev/null || true
    echo "===================================="
    echo "       INSTALADOR DE CUPCORE"
    echo "===================================="
    echo "Carpeta: $PWD"
    echo
    echo "1) Revisar requisitos y configuración"
    echo "2) Instalar Docker si falta"
    echo "3) Crear .env si falta"
    echo "4) Instalar / actualizar CupCore"
    echo "5) Ver estado de contenedores"
    echo "6) Ver logs"
    echo "7) Respaldar base de datos Docker"
    echo "8) Detener contenedores"
    echo "0) Salir"
    echo
    read -r -p "Elegí una opción: " choice
    case "$choice" in
      1) validate_compose; pause ;;
      2) install_docker_if_possible; pause ;;
      3) create_env_if_missing; pause ;;
      4) deploy; pause ;;
      5) status; pause ;;
      6) logs; pause ;;
      7) backup_db; pause ;;
      8) stop_services; pause ;;
      0) exit 0 ;;
      *) echo "Opción inválida."; pause ;;
    esac
  done
}

if [[ "${1:-}" == "--check" ]]; then
  validate_compose
  exit $?
fi

menu
