# Instalador de CupCore (AlmaLinux + Docker Compose)

## Qué hace
- Muestra un menú de instalación, validación, estado, logs, respaldo y detención.
- Valida los archivos antes de iniciar contenedores.
- No borra ni detiene automáticamente el Apache o MariaDB instalado directamente en AlmaLinux.
- Si existe `~/base-de-datos.sql`, pregunta antes de importarlo en la base MariaDB de Docker.
- El respaldo de la base Docker se guarda en el directorio personal del usuario.

## Archivos que deben estar juntos en el repositorio
- `instalador.sh`
- `compose.yaml` (o `compose.yml` / `docker-compose.yml`)
- `Dockerfile`
- Los archivos de la aplicación CupCore

El `compose.yaml` debe definir los servicios `web` y `db`, y el volumen de la base debe escribirse así:

```yaml
services:
  web:
    build: .
    ports:
      - "8080:80"
    depends_on:
      - db

  db:
    image: mariadb:10.11
    restart: unless-stopped
    environment:
      MARIADB_ROOT_PASSWORD: ${DB_ROOT_PASSWORD}
      MARIADB_DATABASE: base-de-datos
      MARIADB_USER: cupcore
      MARIADB_PASSWORD: ${DB_PASSWORD}
    volumes:
      - cupcore_db:/var/lib/mysql

volumes:
  cupcore_db:
```

## Uso en el servidor
Desde la carpeta del repositorio:

```bash
chmod +x instalador.sh
./instalador.sh
```

Elegí primero `2` para instalar Docker si falta, luego `3` para crear `.env` si no existe, después `1` para validar y finalmente `4` para desplegar.

Si Docker ya está instalado, podés ir directamente a la opción 3 o 1 según corresponda.

## Variables de entorno
La opción 3 crea `.env` solicitando las contraseñas de forma interactiva y aplica permisos `600`. No subas `.env` a Git. Agregá estas líneas a `.gitignore`:

```gitignore
.env
*.sql
```

Si ya existe `.env`, el instalador no lo sobrescribe.

## Importante antes de desplegar
1. La aplicación debe conectarse a MariaDB usando el nombre de servicio `db` como host, la base `base-de-datos`, el usuario `cupcore` y la contraseña definida en `.env`. No uses `localhost` como host de la base dentro del contenedor web.
2. El `Dockerfile` tiene que coincidir con la versión de PHP y las extensiones que usa CupCore.
3. La primera ejecución de MariaDB crea una base nueva. Si necesitás los datos existentes, hacé un respaldo válido y guardalo como `~/base-de-datos.sql`; el menú preguntará antes de importarlo.
4. El puerto publicado es `8080`; se accede como `http://IP-DEL-SERVIDOR:8080`. Si firewalld está activo, quizá haya que autorizar ese puerto de forma controlada.
5. No ejecutes `docker compose down -v`: puede borrar el volumen de datos de la base.
6. El instalador no configura automáticamente las credenciales de la aplicación ni arregla errores internos del código. Probá la web y revisá los logs.

## Publicar en Git
Antes de hacer `git add`, comprobá que `.env` y los respaldos SQL no estén en el repositorio:

```bash
git status --short
```

No subas contraseñas ni respaldos con datos reales.
