#!/usr/bin/env bash
#==============================================================================
# instalar-servidor.sh — instala, actualiza y comprueba CupCore en AlmaLinux 9
#
# Menu de consola que corre en el servidor, como root. Comprueba lo que ya
# esta instalado, lo compara con la version final del paquete, instala o
# reemplaza por etapas (PHP 8.3, Apache con HTTPS, MariaDB, firewall,
# fail2ban, respaldo cifrado y Suricata), corre pruebas del sitio y muestra el
# estado de los servicios y los registros. Cada etapa se puede repetir: la
# base, las claves y el certificado se conservan.
#
# Uso, como root desde esta carpeta:
#   sudo bash instalar-servidor.sh                    menu
#   sudo bash instalar-servidor.sh --todo             todas las etapas, sin menu
#   sudo PASOS=sitio,apache bash instalar-servidor.sh solo esas etapas
#
# Variables:
#   IP_ADMIN          unica IP con acceso SSH; sin valor, SSH abierto y limitado por fail2ban
#   NOMBRE_SERVIDOR   nombre del certificado HTTPS; por omision, el del equipo
#   RECARGAR_BASE=1   vuelve a cargar los datos de prueba y borra los datos de la base
#   INTERFAZ, RED     interfaz y red que vigila Suricata; por omision, las de la ruta por defecto
#   PASOS             etapas: paquetes,base,sitio,apache,firewall,fail2ban,respaldo,suricata
#   NO_COLOR, SOLO_ASCII, ANCHO_MARCO   pantalla sin color, sin Unicode o de ancho fijo
#==============================================================================
if [ -z "${BASH_VERSION:-}" ]; then exec bash "$0" "$@"; fi
set -uo pipefail

#==============================================================================
# Interfaz de consola: marcos, menus, tablas, reloj de avance y confirmaciones
#==============================================================================
shopt -s extglob

#--------------------------------------------------------------- Capacidades
# Color y glifos se deciden una vez, al iniciar. Sin TTY (salida a archivo o
# a un pipe) se apaga el color: los codigos ANSI ensucian el texto guardado.
UI_COLOR=1
UI_UNICODE=1

ui__detectar() {
    local colores
    [ -t 1 ] || UI_COLOR=0
    [ -n "${NO_COLOR:-}" ] && UI_COLOR=0
    colores=$(tput colors 2>/dev/null || printf '0')
    [ "$colores" -ge 8 ] 2>/dev/null || UI_COLOR=0
    case "${LC_ALL:-${LC_CTYPE:-${LANG:-}}}" in
        *UTF-8*|*utf8*|*UTF8*) ;;
        *) UI_UNICODE=0 ;;
    esac
    [ -n "${SOLO_ASCII:-}" ] && UI_UNICODE=0
    return 0
}

#-------------------------------------------------------------------- Paleta
# Paleta 256 saturada, sin negrita, para terminal de fondo negro. La forma
# $'\033' guarda el byte ESC real: el ancho visible se mide quitando los
# codigos, y para eso tienen que estar en la variable.
ui__paleta() {
    if [ "$UI_COLOR" -eq 1 ]; then
        R=$'\033[0m'
        CC=$'\033[38;5;44m'      # cian    — marcos y titulos
        CB=$'\033[38;5;39m'      # azul    — teclas de opcion
        CG=$'\033[38;5;78m'      # verde   — ok
        CY=$'\033[38;5;178m'     # amarillo— aviso
        CR=$'\033[38;5;167m'     # rojo    — error y salidas
        CW=$'\033[38;5;253m'     # blanco  — texto destacado
        CD=$'\033[38;5;244m'     # gris    — detalles
        CM=$'\033[38;5;140m'     # violeta — datos secundarios
        FR=$'\033[48;5;167m\033[38;5;16m'   # chip de produccion
        FY=$'\033[48;5;178m\033[38;5;16m'   # chip de pre-produccion
        FB=$'\033[48;5;39m\033[38;5;16m'    # chip de testing
        FD=$'\033[48;5;244m\033[38;5;16m'   # chip neutro
    else
        R=''; CC=''; CB=''; CG=''; CY=''; CR=''; CW=''; CD=''; CM=''
        FR=''; FY=''; FB=''; FD=''
    fi
}

#--------------------------------------------------------------------- Glifos
ui__glifos() {
    if [ "$UI_UNICODE" -eq 1 ]; then
        G_OK='✔'; G_INFO='→'; G_AVISO='!'; G_ERR='✘'; G_RIESGO='⚠'
        G_PUNTA='▸'; G_SEP='›'; G_BARRA='▌'; G_PUNTO='·'; G_CORTE='…'
        M_TL='╔'; M_TR='╗'; M_BL='╚'; M_BR='╝'; M_H='═'; M_V='║'
        M_ML='╠'; M_MR='╣'; M_FINA='─'
        G_LLENO='█'; G_VACIO='░'
    else
        G_OK='OK'; G_INFO='->'; G_AVISO='!'; G_ERR='XX'; G_RIESGO='!!'
        G_PUNTA='>'; G_SEP='>'; G_BARRA='|'; G_PUNTO='-'; G_CORTE='~'
        M_TL='+'; M_TR='+'; M_BL='+'; M_BR='+'; M_H='='; M_V='|'
        M_ML='+'; M_MR='+'; M_FINA='-'
        G_LLENO='#'; G_VACIO='.'
    fi
}

#---------------------------------------------------------------------- Ancho
# El marco se adapta al terminal entre 52 y 76 columnas de interior. Fijo en 60
# cuando no hay TTY, para que la salida redirigida a un archivo sea estable.
# Al pintar un menu puede crecer hasta UI_TOPE_ANCHO si el contenido lo pide.
UI_TOPE_ANCHO=96

# Ancho minimo de una columna de tabla: por debajo el dato deja de leerse.
UI_MIN_COL=10
UI_TABLA_TIT=()
UI_TABLA_ANCHO=()
UI_TABLA_REAL=()

ui__ancho() {
    local cols
    if [ -n "${ANCHO_MARCO:-}" ]; then
        UI_ANCHO="$ANCHO_MARCO"
        return 0
    fi
    cols=$(tput cols 2>/dev/null || printf '0')
    if [ ! -t 1 ] || [ "$cols" -lt 20 ] 2>/dev/null; then
        UI_ANCHO=60
        return 0
    fi
    UI_ANCHO=$(( cols - 8 ))
    (( UI_ANCHO < 52 )) && UI_ANCHO=52
    (( UI_ANCHO > 76 )) && UI_ANCHO=76
    return 0
}

# Columnas que el terminal deja usar para el marco.
ui__ancho_disponible() {
    local cols
    cols=$(tput cols 2>/dev/null || printf '0')
    # Se llama dentro de $(...), donde la salida es una tuberia: el terminal
    # se reconoce tambien por la salida de error.
    if { [ ! -t 1 ] && [ ! -t 2 ]; } || [ "$cols" -lt 20 ] 2>/dev/null; then
        printf '%s' "$UI_TOPE_ANCHO"
        return 0
    fi
    cols=$(( cols - 8 ))
    (( cols > UI_TOPE_ANCHO )) && cols=$UI_TOPE_ANCHO
    (( cols < 40 )) && cols=40
    printf '%s' "$cols"
}

# Corta a `tope` columnas visibles arrastrando los codigos ANSI que va
# encontrando, y cierra el color al final.
ui__cortar() {
    local s=$1 tope=$2 salida='' vis=0 i j n c
    n=${#s}
    for (( i = 0; i < n; i++ )); do
        c=${s:i:1}
        if [ "$c" = $'\033' ]; then
            j=$i
            while (( j < n )) && [ "${s:j:1}" != m ]; do j=$(( j + 1 )); done
            salida="$salida${s:i:j-i+1}"
            i=$j
            continue
        fi
        (( vis >= tope )) && break
        salida="$salida$c"
        vis=$(( vis + 1 ))
    done
    printf '%s%s' "$salida" "$R"
}

# Ancho visible de un texto que puede traer codigos ANSI.
ui__visible() {
    local s=$1
    s="${s//$'\033'\[*([0-9;])m/}"
    printf '%s' "${#s}"
}

# Repite un caracter n veces.
ui__repetir() {
    local car=$1 n=$2 s=''
    while (( n > 0 )); do s="$s$car"; n=$(( n - 1 )); done
    printf '%s' "$s"
}

#------------------------------------------------------------------- Bitacora
# Registro de cada corrida en UI_LOG: acciones, resultados y la salida
# completa de cada comando.
ui__abrir_log() {
    touch "$UI_LOG" 2>/dev/null && chmod 600 "$UI_LOG" 2>/dev/null || { UI_LOG=''; return 0; }
    printf '\n===== %s | %s | %s =====\n' \
        "$(date '+%Y-%m-%d %H:%M:%S')" "$UI_CLAVE" "${USER:-desconocido}" \
        >> "$UI_LOG" 2>/dev/null
    return 0
}

ui_log() {
    [ -n "${UI_LOG:-}" ] || return 0
    printf '%s  %s\n' "$(date '+%H:%M:%S')" "$*" >> "$UI_LOG" 2>/dev/null
    return 0
}

#--------------------------------------------------------------------- Inicio
# $1 = titulo del script (cabecera)   $2 = clave corta (nombre de la bitacora)
ui_init() {
    UI_TITULO="$1"
    UI_CLAVE="$2"
    UI_AMBIENTE=''
    UI_AMB_TONO='neutro'
    UI_CHIPS=()
    ui__detectar
    ui__paleta
    ui__glifos
    ui__ancho
    ui__abrir_log
    trap 'ui__al_salir' EXIT
    trap 'ui__interrupcion' INT
    return 0
}

ui__al_salir() {
    [ "$UI_COLOR" -eq 1 ] && printf '%s' "$R"
    return 0
}

ui__interrupcion() {
    printf '\n'
    ui_aviso "Interrumpido por el usuario."
    ui_log "INTERRUMPIDO"
    exit 130
}

ui_salir() {
    printf '\n    %sHasta luego.%s\n\n' "$CD" "$R"
    ui_log "FIN"
    exit "${1:-0}"
}

#---------------------------------------------------------------------- Marcos
ui_marco_top() { printf '    %s%s%s%s%s\n' "$CC" "$M_TL" "$(ui__repetir "$M_H" "$UI_ANCHO")" "$M_TR" "$R"; }
ui_marco_sep() { printf '    %s%s%s%s%s\n' "$CC" "$M_ML" "$(ui__repetir "$M_H" "$UI_ANCHO")" "$M_MR" "$R"; }
ui_marco_bot() { printf '    %s%s%s%s%s\n' "$CC" "$M_BL" "$(ui__repetir "$M_H" "$UI_ANCHO")" "$M_BR" "$R"; }

# Fila del marco. Recibe el texto ya coloreado; el relleno se calcula sobre el
# ancho visible para que el borde derecho quede siempre alineado.
ui_fila() {
    local txt=${1:-} vis pad
    vis=$(ui__visible "$txt")
    if (( vis > UI_ANCHO )); then
        txt=$(ui__cortar "$txt" "$UI_ANCHO")
        vis=$UI_ANCHO
    fi
    pad=$(( UI_ANCHO - vis ))
    printf '    %s%s%s%s%*s%s%s%s\n' \
        "$CC" "$M_V" "$R" "$txt" "$pad" "" "$CC" "$M_V" "$R"
}

# Titulo centrado dentro del marco.
ui_marco_titulo() {
    local t=$1 izq der
    izq=$(( (UI_ANCHO - ${#t}) / 2 ));      (( izq < 0 )) && izq=0
    der=$(( UI_ANCHO - izq - ${#t} ));      (( der < 0 )) && der=0
    printf '    %s%s%s%*s%s%s%s%*s%s%s%s\n' \
        "$CC" "$M_V" "$R" "$izq" "" "$CW" "$t" "$R" "$der" "" "$CC" "$M_V" "$R"
}

ui_caja() { ui_marco_top; ui_marco_titulo "$1"; ui_marco_bot; }

ui_regla() {
    printf '    %s%s%s\n' "$CD" "$(ui__repetir "$M_FINA" "$(( UI_ANCHO + 2 ))")" "$R"
}

# Debajo del titulo va la linea de procedencia: script, ambiente, alcance y
# momento de la medicion. Un resultado copiado a un documento llega
# con eso, que fuera de la pantalla no se deduce.
ui_titulo() {
    local ctx c linea='' palabra
    printf '\n    %s%s%s\n' "$CC" "$1" "$R"
    ctx="$UI_TITULO"
    [ -n "${UI_AMBIENTE:-}" ] && ctx="$ctx|$UI_AMBIENTE"
    for c in ${UI_CHIPS[@]+"${UI_CHIPS[@]}"}; do ctx="$ctx|$c"; done
    ctx="$ctx|$(date '+%Y-%m-%d %H:%M')"
    # El corte cae entre dos datos, nunca dentro de uno.
    while IFS= read -r -d '|' palabra || [ -n "$palabra" ]; do
        palabra=${palabra%$'\n'}
        [ -n "$palabra" ] || continue
        if [ ${#linea} -gt 0 ] && [ $(( ${#linea} + ${#palabra} + 3 )) -gt "$UI_ANCHO" ]; then
            printf '    %s%s %s%s\n' "$CD" "$linea" "$G_PUNTO" "$R"
            linea="$palabra"
        else
            linea="${linea:+$linea $G_PUNTO }$palabra"
        fi
    done <<< "$ctx"
    [ -n "$linea" ] && printf '    %s%s%s\n' "$CD" "$linea" "$R"
    ui_regla
    ui_log "== $1"
}

#----------------------------------------------------------- Chips de contexto
# El ambiente se pinta con fondo para que no pase inadvertido: el color del
# chip es la unica senal que distingue una maniobra en produccion de una en
# testing cuando el resto de la pantalla es igual.
#
# $1 = etiqueta   $2 = tono (prod | preprod | testing | neutro)
ui_ambiente() {
    UI_AMBIENTE="$1"
    UI_AMB_TONO="${2:-neutro}"
}

ui_chip_reset() { UI_CHIPS=(); }

# $1 = nombre   $2 = valor
ui_chip() { UI_CHIPS+=("$1 $2"); }

ui__chip_fondo() {
    case "$1" in
        prod)    printf '%s' "$FR" ;;
        preprod) printf '%s' "$FY" ;;
        testing) printf '%s' "$FB" ;;
        *)       printf '%s' "$FD" ;;
    esac
}

ui__linea_chips() {
    local salida='' c fondo
    if [ -n "$UI_AMBIENTE" ]; then
        fondo=$(ui__chip_fondo "$UI_AMB_TONO")
        salida="${fondo} ${UI_AMBIENTE} ${R}"
    fi
    for c in ${UI_CHIPS[@]+"${UI_CHIPS[@]}"}; do
        [ -n "$salida" ] && salida="$salida  ${CD}${G_PUNTO}${R}  "
        salida="$salida${CD}${c%% *}${R} ${CW}${c#* }${R}"
    done
    [ -n "$salida" ] && printf '    %s\n' "$salida"
    return 0
}

# Cabecera de pantalla: limpia, dibuja el banner, la ubicacion y los chips.
# Los argumentos son los pasos de la ubicacion (breadcrumb).
ui_pantalla() {
    clear 2>/dev/null
    printf '\n'
    ui_caja "$UI_TITULO"
    printf '\n'
    local linea="    ${CD}Ubicacion ${G_PUNTA}${R}"
    local p
    for p in "$@"; do
        [ -n "$p" ] || continue
        linea="$linea  ${CW}${p}${R}  ${CD}${G_SEP}${R}"
    done
    linea="${linea%  ${CD}${G_SEP}${R}}"
    printf '%s\n' "$linea"
    ui__linea_chips
    printf '\n'
}

#-------------------------------------------------------------- Salida basica
ui_ok()      { printf '    %s%s%s  %b\n' "$CG" "$G_OK"    "$R" "$*"; ui_log "OK    $*"; }
ui_info()    { printf '    %s%s%s  %b\n' "$CB" "$G_INFO"  "$R" "$*"; ui_log "INFO  $*"; }
ui_aviso()   { printf '    %s%s%s  %b\n' "$CY" "$G_AVISO" "$R" "$*"; ui_log "AVISO $*"; }
ui_error()   { printf '    %s%s%s  %b\n' "$CR" "$G_ERR"   "$R" "$*"; ui_log "ERROR $*"; }
ui_detalle() { printf '       %s%b%s\n' "$CD" "$*" "$R"; }
ui_dato()    { printf '    %s%-18s%s %s%b%s\n' "$CD" "$1" "$R" "$CW" "$2" "$R"; }

# Encabezado de un bloque de trabajo.
ui_bloque() {
    printf '\n    %s%s%s %s%s%s' "$CC" "$M_FINA$M_FINA" "$R" "$CW" "$1" "$R"
    [ -n "${2:-}" ] && printf ' %s(%s)%s' "$CD" "$2" "$R"
    printf ' %s%s%s\n' "$CC" "$(ui__repetir "$M_FINA" 6)" "$R"
    ui_log "---- $1 ${2:-}"
}

# Paso n de m dentro de una maniobra.
ui_paso() {
    printf '    %s[%s/%s]%s %b\n' "$CM" "$1" "$2" "$R" "$3"
    ui_log "PASO  [$1/$2] $3"
}

#------------------------------------------------------------------- Progreso
# Barra de progreso en una sola linea, reescrita en el lugar.
ui_progreso() {
    local hechos=$1 total=$2 etiqueta=${3:-} ancho=24 llenos vacios pct texto disponible
    disponible=$(ui__ancho_disponible)
    # En un terminal angosto la barra se acorta y deja lugar a la etiqueta.
    (( disponible < 80 )) && ancho=16
    (( total <= 0 )) && total=1
    pct=$(( hechos * 100 / total ))
    llenos=$(( hechos * ancho / total ))
    (( llenos > ancho )) && llenos=$ancho
    vacios=$(( ancho - llenos ))
    # La etiqueta ocupa lo que deja la terminal: la linea se reescribe en el
    # lugar y una que pasa del ancho deja de reescribirse.
    texto=$(( disponible - ancho - 13 ))
    (( texto < 28 )) && texto=28
    printf '\r    %s%s%s%s%s%s %3s%%  %s%-*.*s%s' \
        "$CG" "$(ui__repetir "$G_LLENO" "$llenos")" "$R" \
        "$CD" "$(ui__repetir "$G_VACIO" "$vacios")" "$R" \
        "$pct" "$CD" "$texto" "$texto" "$etiqueta" "$R"
    (( hechos >= total )) && printf '\n'
    return 0
}

# Mata un proceso y todo lo que colgo de el: el comando corre dentro de una
# subshell y matar solo al padre deja vivos a sus hijos.
ui__matar_arbol() {
    local pid=$1 hijo
    for hijo in $(pgrep -P "$pid" 2>/dev/null); do
        ui__matar_arbol "$hijo"
    done
    kill -TERM "$pid" 2>/dev/null
}

# 1 si el operador corto la ultima espera. Lo consultan quienes encadenan
# pasos, para no seguir con el siguiente.
UI_CANCELADO=0
# Bytes de la ultima descarga completa (ui_traer_archivo).
UI_TRAIDO_BYTES=0

# Espera `pausa` segundos escuchando el teclado. Pone UI_CANCELADO en 1 si el
# operador pidio cortar. Sin terminal solo espera.
ui__escuchar_corte() {
    local pausa=$1 tecla
    if [ "${UI_CORTABLE:-0}" -eq 1 ]; then
        if read -rsn1 -t "$pausa" tecla < /dev/tty 2>/dev/null; then
            case "$tecla" in c|C|$'\e'|q|Q) UI_CANCELADO=1 ;; esac
        fi
    else
        sleep "$pausa" 2>/dev/null || sleep 1
    fi
    return 0
}

# Corta la espera: mata el arbol del proceso y deja constancia.
ui__cortar_espera() {
    ui__matar_arbol "$1"
    sleep 0.4 2>/dev/null
    kill -KILL "$1" 2>/dev/null
}

# Reloj de actividad mientras corre un PID: muestra que sigue vivo y cuanto
# lleva. $1 pid  $2 mensaje  [$3 =1 no cierra la linea: la cierra quien llama,
# que es el unico que sabe si el comando salio bien]. Deja UI_SEGUNDOS.
UI_SEGUNDOS=0

ui_reloj() {
    local pid=$1 msg=$2 callado=${3:-0}
    local marcos='|/-\' i=0 c inicio=$SECONDS pasado tecla
    local pista='' cortable=0 extra='' ancho_msg=38
    [ "$UI_UNICODE" -eq 1 ] && marcos='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
    local n=${#marcos}
    UI_CANCELADO=0
    # La espera se corta desde el teclado solo si hay terminal: en una corrida
    # sin tty (cron, tuberia) no hay a quien preguntarle.
    if [ -r /dev/tty ] && [ -t 1 ]; then
        cortable=1
        UI_CORTABLE=1
        pista="  ${CD}[c] o Ctrl-C cortar${R}"
    else
        UI_CORTABLE=0
    fi
    # Durante la espera Ctrl-C corta solo la espera: el trap general queda
    # suspendido para que el script siga en el menu.
    trap 'UI_CANCELADO=1' INT
    while kill -0 "$pid" 2>/dev/null; do
        i=$(( (i + 1) % n ))
        c=${marcos:i:1}
        pasado=$(( SECONDS - inicio ))
        printf '\r    %s%s%s  %-*.*s %s%02d:%02d%s%s%b ' \
            "$CB" "$c" "$R" "$ancho_msg" "$ancho_msg" "$msg" \
            "$CD" "$(( pasado / 60 ))" "$(( pasado % 60 ))" "$extra" "$R" "$pista"
        ui__escuchar_corte 0.2
        if [ "$UI_CANCELADO" -eq 1 ]; then
            ui__cortar_espera "$pid"
            break
        fi
    done
    trap 'ui__interrupcion' INT
    pasado=$(( SECONDS - inicio ))
    UI_SEGUNDOS=$pasado
    printf '\r%*s\r' "$(( $(ui__ancho_disponible) + 8 ))" ''
    if [ "$callado" -eq 1 ]; then
        [ "$UI_CANCELADO" -eq 1 ] && return 130
        return 0
    fi
    if [ "$UI_CANCELADO" -eq 1 ]; then
        printf '    %s%s%s  %-52.52s %s%02d:%02d%s  %scortado%s\n' \
            "$CY" "$G_AVISO" "$R" "$msg" \
            "$CD" "$(( pasado / 60 ))" "$(( pasado % 60 ))" "$R" "$CY" "$R"
        ui_log "CORTADO $msg (${pasado}s)"
        return 130
    fi
    printf '    %s%s%s  %-52.52s %s%02d:%02d%s\n' \
        "$CG" "$G_OK" "$R" "$msg" \
        "$CD" "$(( pasado / 60 ))" "$(( pasado % 60 ))" "$R"
    return 0
}

# El mismo reloj, con otro nombre.
ui_spinner() { ui_reloj "$1" "$2"; }

# Corre un comando mostrando el reloj y deja su salida en UI_SALIDA.
# Devuelve el codigo del comando, o 130 si el operador corto la espera.
# Uso: ui_tarea "Etiqueta" comando argumentos...  (o el nombre de una funcion)
ui_tarea() {
    local etiqueta=$1; shift
    local temporal codigo pid
    temporal=$(mktemp) || { "$@"; return $?; }
    ( "$@" > "$temporal" 2>&1 ) &
    pid=$!
    # El reloj no cierra la linea: la marca sale del codigo del comando, y
    # una tarea que fallo no se muestra con la tilde de las que salieron bien.
    ui_reloj "$pid" "$etiqueta" 1
    wait "$pid" 2>/dev/null; codigo=$?
    UI_SALIDA=$(cat "$temporal")
    rm -f "$temporal"
    if [ "$UI_CANCELADO" -eq 1 ]; then
        printf '    %s%s%s  %-52.52s %s%02d:%02d%s  %scortado%s\n' \
            "$CY" "$G_AVISO" "$R" "$etiqueta" \
            "$CD" "$(( UI_SEGUNDOS / 60 ))" "$(( UI_SEGUNDOS % 60 ))" "$R" "$CY" "$R"
        ui_log "TAREA (cortada) $etiqueta"
        return 130
    fi
    if [ "$codigo" -eq 0 ]; then
        printf '    %s%s%s  %-52.52s %s%02d:%02d%s\n' "$CG" "$G_OK" "$R" \
            "$etiqueta" "$CD" "$(( UI_SEGUNDOS / 60 ))" "$(( UI_SEGUNDOS % 60 ))" "$R"
    else
        printf '    %s%s%s  %-52.52s %s%02d:%02d%s\n' "$CR" "$G_ERR" "$R" \
            "$etiqueta" "$CD" "$(( UI_SEGUNDOS / 60 ))" "$(( UI_SEGUNDOS % 60 ))" "$R"
    fi
    ui_log "TAREA ($codigo) $etiqueta"
    return "$codigo"
}

UI_SALIDA=''

# Espera una cantidad de segundos mostrando la barra. Para los arranques.
ui_esperar() {
    local segundos=$1 etiqueta=${2:-esperando} pasado=0
    while [ "$pasado" -lt "$segundos" ]; do
        ui_progreso "$pasado" "$segundos" "$etiqueta"
        sleep 1
        pasado=$(( pasado + 1 ))
    done
    ui_progreso "$segundos" "$segundos" "$etiqueta"
}

#----------------------------------------------------------------------- Menu
# Menu declarativo: se cargan las opciones y se pinta. Todos los scripts
# navegan igual porque todos usan estas cuatro funciones.
#
#   ui_menu_nuevo "TITULO"
#   ui_menu_op  tecla  etiqueta  [pista]  [tono]
#   ui_menu_hueco / ui_menu_grupo "texto"
#   ui_menu_leer  ->  deja la tecla elegida en UI_OPCION (normalizada a
#                     mayuscula) y devuelve 1 si la tecla no existe.
#
# Tonos: normal (se infiere), salir, aviso, riesgo.
ui_menu_nuevo() {
    UI_MENU_TITULO="$1"
    UI_MENU_FILAS=()
    UI_MENU_TECLAS=()
}

ui__tono_tecla() {
    case "$1" in
        X|V|0) printf 'salir' ;;
        [0-9]) printf 'normal' ;;
        *)     printf 'aviso' ;;
    esac
}

ui_menu_op() {
    local tecla=$1 etiqueta=$2 pista=${3:-} tono=${4:-}
    local mayus color marca=''
    mayus=$(printf '%s' "$tecla" | tr '[:lower:]' '[:upper:]')
    [ -n "$tono" ] || tono=$(ui__tono_tecla "$mayus")
    case "$tono" in
        salir)  color="$CR" ;;
        aviso)  color="$CY" ;;
        riesgo) color="$CR"; marca=" ${CR}${G_RIESGO}${R}" ;;
        *)      color="$CB" ;;
    esac
    local fila="   ${color}${mayus})${R}  ${CW}${etiqueta}${R}${marca}"
    [ -n "$pista" ] && fila="$fila  ${CD}(${pista})${R}"
    UI_MENU_FILAS+=("$fila")
    UI_MENU_TECLAS+=("$mayus")
}

ui_menu_hueco() { UI_MENU_FILAS+=(""); }

# Linea tenue debajo de una opcion. En los diagnosticos lleva el sintoma: en
# que caso sirve esa revision.
ui_menu_nota() { UI_MENU_FILAS+=("       ${CD}${1}${R}"); }

ui_menu_grupo() {
    UI_MENU_FILAS+=("")
    UI_MENU_FILAS+=("   ${CD}${1}${R}")
}

# Comando resumido de la opcion, debajo de la etiqueta. No es el comando
# entero: alcanza con que el operador vea si la opcion lee (cat, grep, ls) o
# si actua sobre el proceso (jstack, kill -3).
ui_menu_cmd() { UI_MENU_FILAS+=("       ${CM}\$ ${1}${R}"); }

# Encabezado de un bloque de opciones que cambian el servidor. Va en rojo.
# $1 = titulo   $2 = aclaracion (opcional)
ui_menu_grupo_riesgo() {
    UI_MENU_FILAS+=("")
    UI_MENU_FILAS+=("   ${CR}${G_RIESGO} ${1}${R}")
    [ -n "${2:-}" ] && UI_MENU_FILAS+=("   ${CD}${2}${R}")
}

# El marco se agranda hasta donde el terminal permita si alguna fila no entra;
# recien si tampoco asi entra, la fila se recorta. El ancho vuelve a su valor
# al terminar, asi un menu ancho no arrastra al resto de las pantallas.
ui_menu_pintar() {
    local f vis maximo=0 previo=$UI_ANCHO disponible
    for f in ${UI_MENU_FILAS[@]+"${UI_MENU_FILAS[@]}"}; do
        vis=$(ui__visible "$f")
        (( vis > maximo )) && maximo=$vis
    done
    vis=$(( ${#UI_MENU_TITULO} + 4 ))
    (( vis > maximo )) && maximo=$vis
    if (( maximo > UI_ANCHO )); then
        disponible=$(ui__ancho_disponible)
        UI_ANCHO=$(( maximo > disponible ? disponible : maximo ))
    fi

    ui_marco_top
    ui_marco_titulo "$UI_MENU_TITULO"
    ui_marco_sep
    ui_fila ""
    for f in ${UI_MENU_FILAS[@]+"${UI_MENU_FILAS[@]}"}; do
        ui_fila "$f"
    done
    ui_fila ""
    ui_marco_bot
    UI_ANCHO=$previo
}

# Lee y valida contra las teclas cargadas. Devuelve 1 si no es valida.
ui_menu_leer() {
    local sel t
    printf '    %sSeleccion: %s' "$CW" "$R"
    read -r sel || { printf '\n'; ui_salir 0; }
    UI_OPCION=$(printf '%s' "$sel" | tr -d '[:space:]' | tr '[:lower:]' '[:upper:]')
    for t in ${UI_MENU_TECLAS[@]+"${UI_MENU_TECLAS[@]}"}; do
        [ "$t" = "$UI_OPCION" ] && return 0
    done
    ui_error "Opcion invalida."
    ui_pausa
    return 1
}

#--------------------------------------------------------------------- Tablas
# Columnas declaradas como "TITULO:ancho"; ancho 0 = lo que sobre.
ui_tabla_def() {
    UI_TABLA_TIT=()
    UI_TABLA_ANCHO=()
    local c
    for c in "$@"; do
        UI_TABLA_TIT+=("${c%%:*}")
        UI_TABLA_ANCHO+=("${c##*:}")
    done
    ui__repartir_anchos
}

# El ancho declarado es el pedido; el efectivo sale del ancho de la terminal.
# Lo que no entra se descuenta de la columna mas ancha, de a una columna, hasta
# que la fila cabe en la pantalla.
ui__repartir_anchos() {
    UI_TABLA_REAL=()
    local n=${#UI_TABLA_TIT[@]} j elastica=-1 fijas=0 disponible mayor falta
    for j in "${!UI_TABLA_ANCHO[@]}"; do
        UI_TABLA_REAL[$j]=${UI_TABLA_ANCHO[$j]}
        if [ "${UI_TABLA_ANCHO[$j]}" -eq 0 ] 2>/dev/null; then
            elastica=$j
        else
            fijas=$(( fijas + UI_TABLA_ANCHO[j] ))
        fi
    done
    disponible=$(( UI_ANCHO + 2 - 3 * (n - 1) ))
    if [ "$elastica" -ge 0 ]; then
        falta=$(( UI_MIN_COL - (disponible - fijas) ))
    else
        falta=$(( fijas - disponible ))
    fi
    while [ "$falta" -gt 0 ]; do
        mayor=-1
        for j in "${!UI_TABLA_REAL[@]}"; do
            [ "$j" -eq "$elastica" ] && continue
            [ "${UI_TABLA_REAL[$j]}" -le "$UI_MIN_COL" ] && continue
            if [ "$mayor" -lt 0 ] || [ "${UI_TABLA_REAL[$j]}" -gt "${UI_TABLA_REAL[$mayor]}" ]; then
                mayor=$j
            fi
        done
        [ "$mayor" -lt 0 ] && break
        UI_TABLA_REAL[$mayor]=$(( UI_TABLA_REAL[mayor] - 1 ))
        falta=$(( falta - 1 ))
    done
    [ "$elastica" -ge 0 ] || return 0
    fijas=0
    for j in "${!UI_TABLA_REAL[@]}"; do
        [ "$j" -eq "$elastica" ] || fijas=$(( fijas + UI_TABLA_REAL[j] ))
    done
    UI_TABLA_REAL[$elastica]=$(( disponible - fijas ))
    [ "${UI_TABLA_REAL[$elastica]}" -lt "$UI_MIN_COL" ] && UI_TABLA_REAL[$elastica]=$UI_MIN_COL
    return 0
}

ui__ancho_col() {
    printf '%s' "${UI_TABLA_REAL[$1]}"
}

ui_tabla_encabezado() {
    local i linea='' sub='' a
    for i in "${!UI_TABLA_TIT[@]}"; do
        a=$(ui__ancho_col "$i")
        [ -n "$linea" ] && { linea="$linea   "; sub="$sub${CD}${M_FINA}${M_FINA}${M_FINA}${R}"; }
        linea="$linea${CD}$(printf '%-*.*s' "$a" "$a" "${UI_TABLA_TIT[$i]}")${R}"
        sub="$sub${CD}$(ui__repetir "$M_FINA" "$a")${R}"
    done
    printf '\n    %s\n    %s\n' "$linea" "$sub"
}

ui_tabla_fila() {
    local i linea='' a celda vis pad
    for i in "${!UI_TABLA_TIT[@]}"; do
        a=$(ui__ancho_col "$i")
        celda=${@:i+1:1}
        vis=$(ui__visible "$celda")
        if (( vis > a )); then
            # El corte cuenta caracteres visibles: la celda puede traer color.
            celda="$(ui__cortar "$celda" "$(( a - 1 ))")$G_CORTE"
            vis=$a
        fi
        pad=$(( a - vis ))
        [ -n "$linea" ] && linea="$linea   "
        linea="$linea${celda}$(printf '%*s' "$pad" '')"
    done
    printf '    %s\n' "$linea"
}


#----------------------------------------------------------- Entrada y control
ui_pausa() {
    printf '\n    %sEnter para continuar...%s' "$CD" "$R"
    read -r _ || printf '\n'
    return 0
}

# Confirmacion S / N / V.  0 = Si   1 = No   2 = Volver
ui_si_no() {
    local r
    while true; do
        printf '    %s%s%s  %s[S / N / V para volver]%s: ' "$CB" "$1" "$R" "$CD" "$R"
        read -r r || return 2
        case "$r" in
            s|S) ui_log "CONFIRMA SI  $1"; return 0 ;;
            n|N) ui_log "CONFIRMA NO  $1"; return 1 ;;
            v|V) return 2 ;;
            *) ui_aviso "Responder S, N o V." ;;
        esac
    done
}

# Confirmacion de una accion que no se deshace: hay que escribir la palabra.
# $1 = palabra   $2..= lineas de advertencia
ui_confirmar_riesgo() {
    local palabra=$1; shift
    local l r
    printf '\n'
    ui_marco_top
    ui_marco_titulo "ATENCION"
    ui_marco_sep
    ui_fila ""
    # Cada linea se parte por palabras al ancho del marco: ui_fila corta.
    local parte
    for l in "$@"; do
        while IFS= read -r parte; do
            ui_fila "   ${CY}${parte}${R}"
        done < <(printf '%s\n' "$l" | fold -s -w $(( UI_ANCHO - 4 )))
    done
    ui_fila ""
    ui_marco_bot
    printf '\n    %sEscriba %s%s%s para confirmar (vacio = cancelar): %s' \
        "$CW" "$CR" "$palabra" "$CW" "$R"
    read -r r || return 1
    if [ "$r" = "$palabra" ]; then
        ui_log "RIESGO CONFIRMADO $palabra"
        return 0
    fi
    ui_info "Cancelado."
    ui_log "RIESGO CANCELADO $palabra"
    return 1
}

# Lectura con valor por defecto. V vuelve (devuelve 1). Deja el valor en UI_VALOR.
ui_leer() {
    local etiqueta=$1 defecto=${2:-} r
    if [ -n "$defecto" ]; then
        printf '    %s%s%s %s[%s]%s %s(v = volver)%s: ' \
            "$CB" "$etiqueta" "$R" "$CW" "$defecto" "$R" "$CD" "$R"
    else
        printf '    %s%s%s %s(v = volver)%s: ' "$CB" "$etiqueta" "$R" "$CD" "$R"
    fi
    read -r r || return 1
    case "$r" in v|V) return 1 ;; esac
    UI_VALOR="${r:-$defecto}"
    [ -n "$UI_VALOR" ] || return 1
    return 0
}



#------------------------------------------------------------------- Resumen
# Cuadro de confirmacion previo a una maniobra. Los pares nombre/valor se
# pasan seguidos: ui_resumen "Sitio" "/var/www/cupcore" "Base" "CupCore"
ui_resumen() {
    ui_titulo "RESUMEN"
    while [ $# -ge 2 ]; do
        ui_dato "$1" "$2"
        shift 2
    done
    printf '\n'
}

#==============================================================================
# CupCore en el servidor
#==============================================================================
AQUI="$(cd "$(dirname "$0")" && pwd)"
SITIO="$AQUI/sitio"
SQL="$AQUI/base-de-datos"
CONF="$AQUI/configuracion"

DESTINO=/var/www/cupcore
CARPETA_LOG=/var/log/cupcore
CERTIFICADO=/etc/pki/tls/certs/cupcore.crt
CLAVE_CERTIFICADO=/etc/pki/tls/private/cupcore.key
CREDENCIALES=/root/cupcore-credenciales.txt
CONF_MARIADB=/etc/my.cnf.d/60-cupcore.cnf
RESPALDO=/opt/cupcore/respaldo
COPIAS=/var/backups/cupcore
PHP_MINIMA="8.3.36"
UI_LOG=/var/log/cupcore-instalacion.log

IP_ADMIN="${IP_ADMIN:-}"
NOMBRE_SERVIDOR="${NOMBRE_SERVIDOR:-$(hostname -f 2>/dev/null || hostname)}"
IP_SERVIDOR="$(hostname -I 2>/dev/null | awk '{print $1}')"
RECARGAR_BASE="${RECARGAR_BASE:-0}"

# Etapas en orden: clave, rotulo y comando resumido
ETAPAS=(paquetes base sitio apache firewall fail2ban respaldo suricata)
declare -A ROTULO=(
    [paquetes]="Paquetes: PHP 8.3, Apache, MariaDB"
    [base]="Base de datos"
    [sitio]="Sitio en $DESTINO"
    [apache]="Apache con HTTPS"
    [firewall]="Firewall (firewalld)"
    [fail2ban]="fail2ban"
    [respaldo]="Respaldo cifrado y firmado"
    [suricata]="Suricata (deteccion de intrusiones)"
)
declare -A COMANDO=(
    [paquetes]="dnf module enable php:8.3  ·  dnf install httpd php mariadb"
    [base]="mysql < BD_CupCore.sql  ·  ALTER USER de las 3 cuentas"
    [sitio]="copia en $COPIAS  ·  cp sitio  ·  restorecon"
    [apache]="openssl req si falta  ·  cp conf.d  ·  systemctl restart"
    [firewall]="firewall-cmd: http, https y ssh; sin 3306 ni cockpit"
    [fail2ban]="cp jail.local y filtro  ·  systemctl restart fail2ban"
    [respaldo]="claves en /etc/cupcore/claves  ·  cron miercoles 17:00"
    [suricata]="dnf install suricata  ·  suricata-update  ·  systemctl restart"
)

# Version corregida de PHP2Shell (CVE-2026-109618 y CVE-2026-109619) en cada rama
# con soporte; una rama fuera de la lista no se acepta.
php_al_dia() {
    php -r '$m = ["8.2" => "8.2.35", "8.3" => "8.3.36", "8.4" => "8.4.27", "8.5" => "8.5.12"];
        $r = PHP_MAJOR_VERSION . "." . PHP_MINOR_VERSION;
        exit(isset($m[$r]) && version_compare(PHP_VERSION, $m[$r], ">=") ? 0 : 1);' > /dev/null 2>&1
}
version_php() { php -r 'echo PHP_VERSION;' 2>/dev/null || printf 'no instalado'; }
base_existe() { mysql -N -e "show databases like 'CupCore'" 2>/dev/null | grep -q CupCore; }

#------------------------------------------------------------- Acciones
# hacer "Texto" comando...: reloj mientras corre, marca al terminar y salida
# completa en UI_LOG. Si falla, muestra las ultimas lineas de la salida.
hacer() {
    local texto=$1 codigo; shift
    printf '\n### %s  %s\n$ %s\n' "$(date '+%H:%M:%S')" "$texto" "$*" >> "${UI_LOG:-/dev/null}" 2>/dev/null
    if [ -t 1 ]; then
        ui_tarea "$texto" "$@"; codigo=$?
    else
        UI_SALIDA=$("$@" 2>&1); codigo=$?
        if [ "$codigo" -eq 0 ]; then ui_ok "$texto"; else ui_error "$texto"; fi
    fi
    printf '%s\n' "$UI_SALIDA" >> "${UI_LOG:-/dev/null}" 2>/dev/null
    if [ "$codigo" -ne 0 ] && [ "$codigo" -ne 130 ]; then
        printf '%s\n' "$UI_SALIDA" | grep -v '^\s*$' | tail -n 8 | while IFS= read -r l; do ui_detalle "$l"; done
    fi
    return "$codigo"
}

cargar_sql() { mysql < "$1"; }

modulo_php() {
    dnf module reset -y php && dnf module enable -y php:8.3
}

conf_mariadb() {
    printf '[mysqld]\nbind-address = 127.0.0.1\n' > "$CONF_MARIADB" && systemctl restart mariadb
}

claves_base() {
    # shellcheck source=/dev/null
    . "$CREDENCIALES"
    mysql <<SQL
ALTER USER 'cupcoreapp'@'localhost'      IDENTIFIED BY '$CLAVE_APP';
ALTER USER 'cupcoreadmin'@'localhost'    IDENTIFIED BY '$CLAVE_ADMIN';
ALTER USER 'cupcoreconsulta'@'localhost' IDENTIFIED BY '$CLAVE_CONSULTA';
SQL
}

guardar_sitio_anterior() {
    install -d -m 700 "$COPIAS"
    tar -C "$DESTINO" -czf "$COPIAS/sitio-$(date +%Y%m%d-%H%M%S).tar.gz" .
}

copiar_sitio() {
    # shellcheck source=/dev/null
    . "$CREDENCIALES"
    rm -rf "${DESTINO:?}"
    install -d -m 750 "$DESTINO"
    tar -C "$SITIO" -cf - . | tar -C "$DESTINO" -xf -
    sed -i -e "s|^define('DB_PASS'.*|define('DB_PASS',    '$CLAVE_APP');|" "$DESTINO/config/database.php"
}

permisos_sitio() {
    # root escribe; Apache y PHP-FPM (usuario apache) solo leen
    chown -R root:apache "$DESTINO"
    find "$DESTINO" -type d -exec chmod 750 {} +
    find "$DESTINO" -type f -exec chmod 640 {} +
}

registro_accesos() {
    install -d -o apache -g adm -m 750 "$CARPETA_LOG"
    touch "$CARPETA_LOG/acceso.log"
    chown apache:adm "$CARPETA_LOG/acceso.log"
    chmod 640 "$CARPETA_LOG/acceso.log"
    cp "$CONF/logrotate/cupcore" /etc/logrotate.d/cupcore
}

selinux_sitio() {
    # El sitio es de solo lectura; el registro de accesos admite escritura
    semanage fcontext -a -t httpd_sys_content_t "$DESTINO(/.*)?" 2>/dev/null \
        || semanage fcontext -m -t httpd_sys_content_t "$DESTINO(/.*)?"
    semanage fcontext -a -t httpd_log_t "$CARPETA_LOG(/.*)?" 2>/dev/null \
        || semanage fcontext -m -t httpd_log_t "$CARPETA_LOG(/.*)?"
    restorecon -R "$DESTINO" "$CARPETA_LOG"
}

generar_certificado() {
    openssl req -x509 -nodes -newkey rsa:2048 -sha256 -days 825 \
        -subj "/O=Grupo Nexo/CN=$NOMBRE_SERVIDOR" \
        -addext "subjectAltName=DNS:$NOMBRE_SERVIDOR${IP_SERVIDOR:+,IP:$IP_SERVIDOR}" \
        -keyout "$CLAVE_CERTIFICADO" -out "$CERTIFICADO" && chmod 600 "$CLAVE_CERTIFICADO"
}

conf_cupcore_apache() {
    sed -e "s|@DESTINO@|$DESTINO|g" -e "s|@CERTIFICADO@|$CERTIFICADO|g" \
        -e "s|@CLAVE_CERTIFICADO@|$CLAVE_CERTIFICADO|g" "$CONF/apache/cupcore.conf"
}

copiar_conf_web() {
    conf_cupcore_apache > /etc/httpd/conf.d/cupcore.conf
    cp "$CONF/apache/zz-cupcore-seguridad.conf" /etc/httpd/conf.d/
    cp "$CONF/php/99-cupcore.ini" /etc/php.d/
}

reiniciar_web() {
    systemctl enable httpd php-fpm && systemctl restart php-fpm httpd
}

reglas_firewall() {
    local zona
    zona="$(firewall-cmd --get-default-zone)"
    firewall-cmd -q --permanent --zone="$zona" --add-service=http --add-service=https
    firewall-cmd -q --permanent --zone="$zona" --remove-service=cockpit || true
    firewall-cmd -q --permanent --zone="$zona" --remove-service=dhcpv6-client || true
    firewall-cmd -q --permanent --zone="$zona" --remove-port=3306/tcp || true
    firewall-cmd -q --permanent --zone="$zona" --remove-service=mysql || true
    if [ -n "$IP_ADMIN" ]; then
        firewall-cmd -q --permanent --zone="$zona" --remove-service=ssh || true
        firewall-cmd -q --permanent --zone="$zona" \
            --add-rich-rule="rule family=ipv4 source address=$IP_ADMIN port port=22 protocol=tcp accept"
    else
        firewall-cmd -q --permanent --zone="$zona" --add-service=ssh
    fi
    firewall-cmd -q --reload
}

conf_fail2ban() {
    cp "$CONF/fail2ban/cupcore-login.conf" /etc/fail2ban/filter.d/
    sed -E "s|^ignoreip *=.*|&${IP_ADMIN:+ $IP_ADMIN}|" "$CONF/fail2ban/jail.local" > /etc/fail2ban/jail.local
    systemctl enable fail2ban && systemctl restart fail2ban
}

instalar_respaldo() {
    install -d -m 700 "$RESPALDO"
    install -m 700 "$AQUI"/respaldo/*.sh "$RESPALDO/"
    bash "$RESPALDO/generar-claves.sh"
}

programar_respaldo() {
    # Miercoles a las 17:00, el dia del respaldo de la base en la politica de respaldos
    printf '0 17 * * 3 root %s/respaldar-base.sh >> /var/log/cupcore-respaldo.log 2>&1\n' "$RESPALDO" \
        > /etc/cron.d/cupcore-respaldo
    chmod 644 /etc/cron.d/cupcore-respaldo
    systemctl enable --now crond
}

reglas_suricata() {
    local reglas=/var/lib/suricata/rules
    suricata-update || true
    install -d "$reglas"
    cp "$CONF/suricata/cupcore.rules" "$reglas/cupcore.rules"
    [ -f "$reglas/suricata.rules" ] || : > "$reglas/suricata.rules"
}

conf_suricata() {
    local yaml=/etc/suricata/suricata.yaml
    cp -n "$yaml" "$yaml.respaldo"
    sed -i -E "s|^(\s*HOME_NET:\s*).*|\1\"[$RED]\"|" "$yaml"
    sed -i -E "0,/^(\s*- interface:\s*).*/s||\1$INTERFAZ|" "$yaml"
    grep -q -- '- cupcore.rules' "$yaml" \
        || sed -i -E "s|^(\s*)- suricata.rules\s*$|&\n\1- cupcore.rules|" "$yaml"
    if [ -f /etc/sysconfig/suricata ]; then
        sed -i -E "s|^OPTIONS=.*|OPTIONS=\"-i $INTERFAZ --user suricata\"|" /etc/sysconfig/suricata
    fi
    suricata -T -c "$yaml"
}

reiniciar_suricata() { systemctl enable suricata && systemctl restart suricata; }

# Espera hasta 15 s a que un servicio quede activo
esperar_activo() {
    local i
    for i in $(seq 1 15); do
        systemctl is-active -q "$1" && return 0
        sleep 1
    done
    return 1
}

#--------------------------------------------------------------- Etapas
# Cada etapa devuelve distinto de 0 si algo fallo; la instalacion se detiene ahi.

etapa_paquetes() {
    hacer "EPEL y dnf-plugins-core" dnf install -y dnf-plugins-core epel-release || return 1
    hacer "Repositorio CRB" dnf config-manager --set-enabled crb || return 1
    if ! php_al_dia; then
        hacer "Modulo php:8.3 de AppStream" modulo_php || return 1
    fi
    hacer "Apache, PHP 8.3, MariaDB y herramientas (varios minutos)" \
        dnf install -y httpd mod_ssl \
        php php-cli php-common php-fpm php-pdo php-mysqlnd php-mbstring \
        mariadb-server mariadb firewalld openssl policycoreutils-python-utils \
        cronie logrotate tar python3 iproute || return 1
    if ! php_al_dia; then
        hacer "PHP de otra rama llevado a la 8.3" dnf distro-sync -y 'php*' || return 1
    fi
    hacer "fail2ban" dnf install -y fail2ban fail2ban-firewalld || return 1
    if ! php -m 2>/dev/null | grep -qx pdo_mysql; then
        ui_error "Falta la extension pdo_mysql de PHP."
        return 1
    fi
    if ! php_al_dia; then
        ui_error "PHP $(version_php) sin la correccion de PHP2Shell: se necesita $PHP_MINIMA o posterior"
        return 1
    fi
    ui_ok "PHP $(version_php), con la correccion de PHP2Shell"
    # MYSQLD_OPTS en systemd agrega opciones al arranque de MariaDB y puede impedirlo
    if systemctl show-environment | grep -q '^MYSQLD_OPTS='; then
        hacer "Variable MYSQLD_OPTS quitada de systemd" systemctl unset-environment MYSQLD_OPTS || return 1
    fi
    hacer "MariaDB y PHP-FPM en marcha" systemctl enable --now mariadb php-fpm || return 1
}

etapa_base() {
    local nueva=1
    hacer "MariaDB solo en 127.0.0.1" conf_mariadb || return 1
    if ! mysql -e 'select 1' > /dev/null 2>&1; then
        ui_error "MariaDB pide clave para root."
        ui_detalle "Crear /root/.my.cnf con permisos 600 y repetir la etapa:"
        ui_detalle "[client]  user=root  password=CLAVE-DE-ROOT"
        return 1
    fi
    base_existe && nueva=0
    hacer "Estructura de la base (crea lo que falta, conserva los datos)" cargar_sql "$SQL/BD_CupCore.sql" || return 1
    if [ "$nueva" = 1 ] || [ "$RECARGAR_BASE" = 1 ]; then
        hacer "Datos de prueba" cargar_sql "$SQL/CupCore_datos_ejemplo.sql" || return 1
    else
        ui_info "La base CupCore ya existe: se conservan sus datos."
    fi
    if [ ! -f "$CREDENCIALES" ]; then
        generar() { openssl rand -base64 18 | tr '+/' '_-'; }
        ( umask 077
          printf 'CLAVE_APP=%s\nCLAVE_ADMIN=%s\nCLAVE_CONSULTA=%s\n' \
              "$(generar)" "$(generar)" "$(generar)" > "$CREDENCIALES" )
        ui_ok "Claves nuevas para las cuentas de la base en $CREDENCIALES"
    fi
    hacer "Claves de cupcoreapp, cupcoreadmin y cupcoreconsulta" claves_base || return 1
}

etapa_sitio() {
    if [ ! -f "$CREDENCIALES" ]; then
        ui_error "Falta $CREDENCIALES: ejecutar antes la etapa Base de datos."
        return 1
    fi
    if [ -d "$DESTINO" ] && [ -n "$(ls -A "$DESTINO" 2>/dev/null)" ]; then
        hacer "Copia del sitio anterior en $COPIAS" guardar_sitio_anterior || return 1
    fi
    hacer "Sitio copiado a $DESTINO" copiar_sitio || return 1
    hacer "Permisos: root escribe, apache solo lee" permisos_sitio || return 1
    hacer "Registro de accesos en $CARPETA_LOG" registro_accesos || return 1
    if command -v semanage > /dev/null && selinuxenabled 2>/dev/null; then
        hacer "Etiquetas de SELinux" selinux_sitio || return 1
    else
        ui_info "SELinux desactivado: sin etiquetas."
    fi
}

etapa_apache() {
    if [ -f "$CERTIFICADO" ]; then
        ui_info "Certificado existente: $(openssl x509 -in "$CERTIFICADO" -noout -enddate 2>/dev/null | sed 's/notAfter=/vence /')"
    else
        hacer "Certificado autofirmado (RSA 2048, SHA-256)" generar_certificado || return 1
    fi
    hacer "Configuracion de Apache y PHP" copiar_conf_web || return 1
    hacer "Revision de la configuracion (apachectl configtest)" apachectl configtest || return 1
    hacer "Apache y PHP-FPM reiniciados" reiniciar_web || return 1
    if esperar_activo httpd; then
        ui_ok "Apache activo: https://${IP_SERVIDOR:-127.0.0.1}/"
    else
        ui_error "Apache no quedo activo: systemctl status httpd"
        return 1
    fi
}

etapa_firewall() {
    hacer "firewalld en marcha" systemctl enable --now firewalld || return 1
    hacer "Reglas: http, https y ssh${IP_ADMIN:+ (solo $IP_ADMIN)}; 3306 cerrado" reglas_firewall || return 1
    ui_dato "Servicios abiertos" "$(firewall-cmd --list-services 2>/dev/null)"
}

etapa_fail2ban() {
    hacer "Carceles sshd, cupcore-login y apache-badbots" conf_fail2ban || return 1
    sleep 3
    ui_dato "Carceles activas" "$(fail2ban-client status 2>/dev/null | sed -n 's/.*Jail list:\s*//p')"
}

etapa_respaldo() {
    hacer "Scripts y claves del respaldo" instalar_respaldo || return 1
    hacer "Respaldo programado: miercoles 17:00" programar_respaldo || return 1
    hacer "Primer respaldo cifrado y firmado" bash "$RESPALDO/respaldar-base.sh" || return 1
}

etapa_suricata() {
    INTERFAZ="${INTERFAZ:-$(ip -o route show default | awk '{for (i = 1; i < NF; i++) if ($i == "dev") { print $(i + 1); exit }}')}"
    RED="${RED:-$(ip -o -f inet addr show "$INTERFAZ" | awk '{print $4; exit}')}"
    RED="$(python3 -c 'import ipaddress, sys; print(ipaddress.ip_interface(sys.argv[1]).network)' "$RED")"
    ui_dato "Interfaz vigilada" "$INTERFAZ"
    ui_dato "Red propia" "$RED"
    hacer "Suricata" dnf install -y suricata || return 1
    hacer "Reglas publicas y reglas del proyecto" reglas_suricata || return 1
    hacer "Configuracion de Suricata (suricata -T)" conf_suricata || return 1
    hacer "Suricata en marcha" reiniciar_suricata || return 1
}

# ejecutar_etapas clave...: corre las etapas en orden y se detiene en la que falle
ejecutar_etapas() {
    local total=$# i=0 etapa inicio
    for etapa in "$@"; do
        i=$(( i + 1 ))
        printf '\n'
        ui_paso "$i" "$total" "${CW}${ROTULO[$etapa]}${R}"
        inicio=$SECONDS
        if ! "etapa_$etapa"; then
            printf '\n'
            ui_error "Se detuvo en la etapa ${ROTULO[$etapa]}."
            ui_detalle "Salida completa: $UI_LOG"
            ui_detalle "Corregido el problema, se sigue desde ahi con la opcion 6 o con:"
            ui_detalle "sudo PASOS=$(printf '%s\n' "$@" | sed -n "${i},\$p" | paste -sd, -) bash $0"
            return 1
        fi
        ui_detalle "${ROTULO[$etapa]}: lista en $(( SECONDS - inicio )) s"
    done
    return 0
}

resumen_final() {
    ui_titulo "LISTO"
    ui_dato "Sitio" "https://${IP_SERVIDOR:-IP-DEL-SERVIDOR}/  (certificado autofirmado)"
    ui_dato "Ingreso" "admin@cupcore.com / CupCore2026\$"
    ui_dato "PHP" "$(version_php)"
    ui_dato "Claves de la base" "$CREDENCIALES"
    ui_dato "Respaldos" "/backup/mysql  (claves en /etc/cupcore/claves)"
    ui_dato "Alertas IDS" "/var/log/suricata/fast.log"
    ui_dato "Registro" "$UI_LOG"
}

#------------------------------------------------------------- Consultas
estado_servicio() {
    local s=$1 activo habilitado
    activo=$(systemctl is-active "$s" 2>/dev/null)
    habilitado=$(systemctl is-enabled "$s" 2>/dev/null)
    case "$activo" in
        active) ui_tabla_fila "$s" "${CG}${G_OK} activo${R}" "${habilitado:-}" ;;
        *)      ui_tabla_fila "$s" "${CR}${G_ERR} ${activo:-sin instalar}${R}" "${habilitado:-no instalado}" ;;
    esac
}

ver_estado() {
    local s ultimo
    ui_titulo "ESTADO DEL SERVIDOR"
    ui_tabla_def "SERVICIO:12" "ESTADO:16" "ARRANQUE:0"
    ui_tabla_encabezado
    for s in httpd php-fpm mariadb firewalld fail2ban suricata crond; do
        estado_servicio "$s"
    done
    printf '\n'
    if command -v php > /dev/null; then
        if php_al_dia; then ui_ok "PHP $(version_php), con la correccion de PHP2Shell"; else ui_error "PHP $(version_php) sin la correccion de PHP2Shell: opcion 5 o etapa Paquetes"; fi
    else
        ui_aviso "PHP no instalado"
    fi
    if base_existe; then
        ui_ok "Base CupCore: $(mysql -N -e "select count(*) from information_schema.tables where table_schema='CupCore'") tablas, $(mysql -N -e 'select count(*) from CupCore.Usuario' 2>/dev/null) usuarios"
    else
        ui_aviso "Base CupCore: no existe"
    fi
    if ss -tln | grep -q ':3306 '; then
        if ss -tln | grep ':3306 ' | grep -vq '127.0.0.1:3306'; then
            ui_error "MariaDB escucha fuera de 127.0.0.1"
        else
            ui_ok "MariaDB escucha solo en 127.0.0.1:3306"
        fi
    fi
    if [ -f "$CERTIFICADO" ]; then
        ui_ok "Certificado: $(openssl x509 -in "$CERTIFICADO" -noout -enddate | sed 's/notAfter=/vence /')"
    else
        ui_aviso "Certificado: no generado"
    fi
    command -v getenforce > /dev/null && ui_info "SELinux: $(getenforce)"
    ultimo=$(ls -t /backup/mysql/*.enc 2>/dev/null | head -1)
    if [ -n "$ultimo" ]; then
        ui_ok "Ultimo respaldo: $(basename "$ultimo")  ($(du -h "$ultimo" | cut -f1))"
    else
        ui_aviso "Sin respaldos en /backup/mysql"
    fi
    ui_info "Disco libre en /: $(df -h / | awk 'NR==2 {print $4 " de " $2}')"
}

# Compara un archivo instalado con el del paquete
comparar_archivo() {
    local nombre=$1 paquete=$2 instalado=$3
    if [ ! -f "$instalado" ]; then
        ui_tabla_fila "$nombre" "${CY}${G_AVISO} falta${R}" "$instalado"
        DIFERENCIAS=$(( DIFERENCIAS + 1 ))
    elif cmp -s "$paquete" "$instalado"; then
        ui_tabla_fila "$nombre" "${CG}${G_OK} igual${R}" "$instalado"
    else
        ui_tabla_fila "$nombre" "${CY}${G_AVISO} distinto${R}" "$instalado"
        DIFERENCIAS=$(( DIFERENCIAS + 1 ))
    fi
}

comparar() {
    local distintos faltan sobran tablas esperadas temporal
    DIFERENCIAS=0
    ui_titulo "INSTALADO CONTRA LA VERSION FINAL"
    ui_tabla_def "ELEMENTO:20" "ESTADO:12" "DETALLE:0"
    ui_tabla_encabezado
    # Sitio: config/database.php difiere solo en la clave, que pone el instalador
    if [ -d "$DESTINO" ]; then
        distintos=$(LC_ALL=C diff -rq "$SITIO" "$DESTINO" 2>/dev/null | grep -v 'config/database.php' | grep -c ' differ$')
        faltan=$(LC_ALL=C diff -rq "$SITIO" "$DESTINO" 2>/dev/null | grep -c "^Only in $SITIO")
        sobran=$(LC_ALL=C diff -rq "$SITIO" "$DESTINO" 2>/dev/null | grep -c "^Only in $DESTINO")
        if [ $(( distintos + faltan + sobran )) -eq 0 ]; then
            ui_tabla_fila "Sitio" "${CG}${G_OK} igual${R}" "$DESTINO"
        else
            ui_tabla_fila "Sitio" "${CY}${G_AVISO} distinto${R}" "$distintos cambiados, $faltan faltan, $sobran de mas"
            DIFERENCIAS=$(( DIFERENCIAS + 1 ))
        fi
    else
        ui_tabla_fila "Sitio" "${CY}${G_AVISO} falta${R}" "$DESTINO"
        DIFERENCIAS=$(( DIFERENCIAS + 1 ))
    fi
    # Base: tablas del paquete contra las de CupCore
    esperadas=$(grep -ciE '^create table' "$SQL/BD_CupCore.sql")
    if base_existe; then
        tablas=$(mysql -N -e "select count(*) from information_schema.tables where table_schema='CupCore' and table_type='BASE TABLE'")
        if [ "$tablas" -ge "$esperadas" ]; then
            ui_tabla_fila "Base CupCore" "${CG}${G_OK} completa${R}" "$tablas de $esperadas tablas"
        else
            ui_tabla_fila "Base CupCore" "${CY}${G_AVISO} incompleta${R}" "$tablas de $esperadas tablas"
            DIFERENCIAS=$(( DIFERENCIAS + 1 ))
        fi
    else
        ui_tabla_fila "Base CupCore" "${CY}${G_AVISO} falta${R}" "0 de $esperadas tablas"
        DIFERENCIAS=$(( DIFERENCIAS + 1 ))
    fi
    # PHP
    if php_al_dia; then
        ui_tabla_fila "PHP: version" "${CG}${G_OK} al dia${R}" "$(version_php)"
    else
        ui_tabla_fila "PHP: version" "${CR}${G_ERR} vulnerable${R}" "$(version_php); la etapa Paquetes instala $PHP_MINIMA"
        DIFERENCIAS=$(( DIFERENCIAS + 1 ))
    fi
    # Configuracion
    temporal=$(mktemp)
    conf_cupcore_apache > "$temporal"
    comparar_archivo "Apache: sitio" "$temporal" /etc/httpd/conf.d/cupcore.conf
    rm -f "$temporal"
    comparar_archivo "Apache: cabeceras" "$CONF/apache/zz-cupcore-seguridad.conf" /etc/httpd/conf.d/zz-cupcore-seguridad.conf
    comparar_archivo "PHP: configuracion" "$CONF/php/99-cupcore.ini" /etc/php.d/99-cupcore.ini
    comparar_archivo "fail2ban: filtro" "$CONF/fail2ban/cupcore-login.conf" /etc/fail2ban/filter.d/cupcore-login.conf
    comparar_archivo "logrotate" "$CONF/logrotate/cupcore" /etc/logrotate.d/cupcore
    comparar_archivo "Suricata: reglas" "$CONF/suricata/cupcore.rules" /var/lib/suricata/rules/cupcore.rules
    comparar_archivo "Respaldo" "$AQUI/respaldo/respaldar-base.sh" "$RESPALDO/respaldar-base.sh"
    printf '\n'
    if [ "$DIFERENCIAS" -eq 0 ]; then
        ui_ok "El servidor tiene la version final."
    else
        ui_aviso "Elementos distintos de la version final o sin instalar: $DIFERENCIAS"
        ui_detalle "La opcion 5 los instala o los reemplaza; la base conserva sus datos."
    fi
}

#---------------------------------------------------------------- Pruebas
PRUEBAS_OK=0
PRUEBAS_ERROR=0
probar() {  # probar "Descripcion" condicion(0 = correcta)
    if [ "$2" -eq 0 ]; then
        PRUEBAS_OK=$(( PRUEBAS_OK + 1 )); ui_ok "$1"
    else
        PRUEBAS_ERROR=$(( PRUEBAS_ERROR + 1 )); ui_error "$1"
    fi
}

pruebas() {
    local url=https://127.0.0.1 cab cookies token destino
    PRUEBAS_OK=0; PRUEBAS_ERROR=0
    cookies=$(mktemp)
    ui_titulo "PRUEBAS DEL SITIO"
    ui_bloque "HTTPS"
    [ "$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1/)" = 301 ]
    probar "El puerto 80 redirige a HTTPS" $?
    [ "$(curl -sk -o /dev/null -w '%{http_code}' "$url/index.php?ruta=login")" = 200 ]
    probar "La pantalla de ingreso responde por HTTPS" $?
    cab=$(curl -skI "$url/index.php?ruta=login")
    grep -qi '^strict-transport-security' <<< "$cab"; probar "Cabecera Strict-Transport-Security" $?
    grep -qi '^content-security-policy' <<< "$cab";   probar "Cabecera Content-Security-Policy" $?
    grep -qi '^x-content-type-options: nosniff' <<< "$cab"; probar "Cabecera X-Content-Type-Options" $?
    ! grep -qiE '^server:.*[0-9]|^x-powered-by' <<< "$cab"; probar "Apache y PHP no informan su version" $?
    grep -qiE '^set-cookie:.*secure.*httponly|^set-cookie:.*httponly.*secure' <<< "$cab"; probar "Cookie de sesion con Secure y HttpOnly" $?
    ui_bloque "Archivos protegidos"
    [ "$(curl -sk -o /dev/null -w '%{http_code}' "$url/config/database.php")" = 403 ]; probar "La carpeta config no se sirve" $?
    [ "$(curl -sk -o /dev/null -w '%{http_code}' "$url/.htaccess")" = 403 ];          probar "El archivo .htaccess no se descarga" $?
    [ "$(curl -sk -o /dev/null -w '%{http_code}' "$url/css/")" = 403 ];               probar "Las carpetas no listan su contenido" $?
    ui_bloque "Aplicacion y base"
    grep -qi 'torneo' < <(curl -sk "$url/index.php?ruta=torneos"); probar "El listado de torneos responde" $?
    token=$(curl -sk -c "$cookies" -b "$cookies" "$url/index.php?ruta=login" | grep -o 'name="tokenCsrf" value="[^"]*"' | head -1 | cut -d'"' -f4)
    destino=$(curl -sk -c "$cookies" -b "$cookies" -o /dev/null -w '%{redirect_url}' \
        --data-urlencode "tokenCsrf=$token" --data-urlencode "correo=admin@cupcore.com" \
        --data-urlencode 'contrasena=CupCore2026$' "$url/index.php?ruta=login")
    grep -q 'admin\|clave' <<< "$destino"; probar "Ingreso del administrador de prueba" $?
    ! ss -tln | grep ':3306 ' | grep -vq '127.0.0.1:3306'; probar "MariaDB escucha solo en 127.0.0.1" $?
    ! mysql -N -e "show grants for 'cupcoreapp'@'localhost'" 2>/dev/null | grep -q 'ALL PRIVILEGES'
    probar "La cuenta del sitio no tiene todos los permisos" $?
    ui_bloque "Servidor"
    php_al_dia; probar "PHP $(version_php) con la correccion de PHP2Shell" $?
    fail2ban-client status cupcore-login > /dev/null 2>&1; probar "Carcel cupcore-login de fail2ban activa" $?
    systemctl is-active -q firewalld 2>/dev/null; probar "Firewall activo" $?
    systemctl is-active -q suricata 2>/dev/null; probar "Suricata activo" $?
    rm -f "$cookies"
    printf '\n'
    ui_dato "RESULTADO" "$PRUEBAS_OK correctas, $PRUEBAS_ERROR con error"
    ui_detalle "Prueba completa (74 comprobaciones): pruebas/pruebas_owasp.sh del paquete de la entrega."
    ui_log "PRUEBAS $PRUEBAS_OK correctas, $PRUEBAS_ERROR con error"
}

ver_registros() {
    local archivo
    for archivo in "$CARPETA_LOG/acceso.log" /var/log/httpd/cupcore_error_log \
                   /var/log/fail2ban.log /var/log/suricata/fast.log; do
        ui_titulo "$archivo"
        if [ -f "$archivo" ]; then
            tail -n 12 "$archivo" | cut -c1-150 | sed 's/^/    /'
        else
            ui_aviso "No existe todavia."
        fi
    done
}

#----------------------------------------------------------- Acciones del menu
instalar_todo() {
    ui_titulo "INSTALAR O ACTUALIZAR A LA VERSION FINAL"
    if [ -d "$DESTINO" ] || base_existe; then
        ui_info "Hay una instalacion anterior:"
        ui_detalle "el sitio y la configuracion se reemplazan por los del paquete;"
        ui_detalle "el sitio anterior queda en $COPIAS;"
        ui_detalle "la base, sus datos, las claves y el certificado se conservan."
    else
        ui_info "Servidor sin CupCore: se instala todo desde cero."
    fi
    ui_detalle "Tarda varios minutos; la salida completa queda en $UI_LOG"
    printf '\n'
    ui_si_no "Instalar" || return
    ejecutar_etapas "${ETAPAS[@]}" && resumen_final
}

menu_etapas() {
    local i etapa
    while true; do
        ui_pantalla "Servidor" "Una etapa"
        ui_menu_nuevo "UNA ETAPA POR SEPARADO"
        i=0
        for etapa in "${ETAPAS[@]}"; do
            i=$(( i + 1 ))
            ui_menu_op "$i" "${ROTULO[$etapa]}"
            ui_menu_cmd "${COMANDO[$etapa]}"
        done
        ui_menu_hueco
        ui_menu_op X "Volver"
        ui_menu_pintar
        ui_detalle "Cada etapa se puede repetir: conserva la base, las claves y el certificado."
        ui_menu_leer || continue
        [ "$UI_OPCION" = X ] && return
        etapa=${ETAPAS[$(( UI_OPCION - 1 ))]}
        ejecutar_etapas "$etapa"
        ui_pausa
    done
}

recargar_base() {
    ui_confirmar_riesgo "RECARGAR" \
        "Borra los usuarios, torneos, equipos y resultados de la base CupCore y carga los datos de prueba." \
        "Antes se guarda un respaldo cifrado en /backup/mysql si la etapa Respaldo esta instalada." || return
    if [ -x "$RESPALDO/respaldar-base.sh" ]; then
        hacer "Respaldo antes de recargar" bash "$RESPALDO/respaldar-base.sh" || return
    fi
    RECARGAR_BASE=1 ejecutar_etapas base
}

reiniciar_servicios() {
    local s
    ui_titulo "REINICIO DE SERVICIOS"
    for s in mariadb php-fpm httpd; do
        hacer "Reinicio de $s" systemctl restart "$s" || continue
        if esperar_activo "$s"; then ui_ok "$s activo"; else ui_error "$s no quedo activo"; fi
    done
}

respaldar_ahora() {
    ui_titulo "RESPALDO DE LA BASE"
    if [ ! -x "$RESPALDO/respaldar-base.sh" ]; then
        ui_aviso "El respaldo no esta instalado: etapa Respaldo (opcion 6)."
        return
    fi
    hacer "Respaldo cifrado y firmado" bash "$RESPALDO/respaldar-base.sh" || return
    ls -lt /backup/mysql 2>/dev/null | sed -n 2,4p | sed 's/^/    /'
}

contexto() {
    ui_chip_reset
    ui_chip "equipo" "$(hostname -s)"
    ui_chip "PHP" "$(version_php)"
    if [ -d "$DESTINO" ]; then ui_chip "sitio" "instalado"; else ui_chip "sitio" "sin instalar"; fi
}

menu_principal() {
    while true; do
        contexto
        ui_pantalla "Servidor" "Menu principal"
        ui_menu_nuevo "CUPCORE EN EL SERVIDOR"
        ui_menu_grupo "Consultar"
        ui_menu_op 1 "Estado del servidor" "servicios, PHP, base, certificado"
        ui_menu_cmd "systemctl is-active  ·  php -v  ·  ss -tln  ·  openssl x509"
        ui_menu_op 2 "Comparar con la version final" "que hay instalado y que cambia"
        ui_menu_cmd "diff -rq sitio  ·  tablas de CupCore  ·  cmp de la conf"
        ui_menu_op 3 "Pruebas del sitio" "HTTPS, cabeceras, ingreso, base"
        ui_menu_cmd "curl a https://127.0.0.1  ·  mysql -e  ·  fail2ban-client"
        ui_menu_op 4 "Registros" "ultimas lineas"
        ui_menu_cmd "tail -n 12 de acceso, Apache, fail2ban y Suricata"
        ui_menu_grupo "Instalar y actualizar"
        ui_menu_op 5 "Instalar o actualizar todo" "deja la version final"
        ui_menu_cmd "las 8 etapas: dnf install  ·  cp sitio y conf  ·  restart"
        ui_menu_op 6 "Una etapa por separado"
        ui_menu_cmd "la etapa elegida"
        ui_menu_grupo "Servicios y respaldo"
        ui_menu_op 7 "Reiniciar los servicios"
        ui_menu_cmd "systemctl restart mariadb php-fpm httpd"
        ui_menu_op 8 "Respaldar la base ahora"
        ui_menu_cmd "respaldar-base.sh: mariadb-dump, AES-256 y firma RSA"
        ui_menu_grupo_riesgo "Borra datos"
        ui_menu_op 9 "Reemplazar la base por los datos de prueba" "" riesgo
        ui_menu_cmd "respaldo  ·  BD_CupCore.sql y CupCore_datos_ejemplo.sql"
        ui_menu_hueco
        ui_menu_op X "Salir"
        ui_menu_pintar
        ui_menu_leer || continue
        case "$UI_OPCION" in
            1) ver_estado ;;
            2) comparar ;;
            3) pruebas ;;
            4) ver_registros ;;
            5) instalar_todo ;;
            6) menu_etapas; continue ;;
            7) reiniciar_servicios ;;
            8) respaldar_ahora ;;
            9) recargar_base ;;
            X) ui_salir 0 ;;
        esac
        ui_pausa
    done
}

main() {
    if [ "$(id -u)" -ne 0 ]; then
        echo "Ejecutar como root: sudo bash $0"
        exit 1
    fi
    ui_init "CUPCORE  ·  SERVIDOR" "cupcore"
    # Con PASOS o sin terminal corre las etapas sin menu
    if [ -n "${PASOS:-}" ] || [ "${1:-}" = "--todo" ] || [ ! -t 0 ]; then
        local lista
        IFS=',' read -r -a lista <<< "${PASOS:-$(IFS=,; printf '%s' "${ETAPAS[*]}")}"
        ui_caja "$UI_TITULO"
        ejecutar_etapas "${lista[@]}" || exit 1
        resumen_final
        exit 0
    fi
    menu_principal
}

main "$@"
