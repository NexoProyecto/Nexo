<?php
require_once __DIR__ . '/ConexionBD.php';

/**
 * Participantes y equipos: tablas Participante, Vincula, Equipo e Integra.
 * Cada equipo tiene un participante que lo representa en los torneos (Equipo.IdParticipante),
 * con el mismo nombre y el mismo perfil que el equipo
 */
class GestorParticipantes
{
    private PDO $bd;

    public function __construct(?PDO $conexion = null)
    {
        $this->bd = $conexion ?? ConexionBD::obtener();
    }

    public function listarParticipantes(): array
    {
        $sql = "select Participante.IdParticipante     as id,
                       Participante.NombreParticipante as nombre,
                       Participante.Alias              as alias,
                       Participante.FechaNacimiento    as fecha_nacimiento,
                       Participante.PerfilPublico      as perfil_publico,
                       Usuario.Email                   as correo,
                       (select count(*) from Inscripcion
                         where Inscripcion.IdParticipante = Participante.IdParticipante) as inscripciones
                from Participante
                left join Vincula on Participante.IdParticipante = Vincula.IdParticipante
                left join Usuario on Vincula.IdUsuario = Usuario.IdUsuario
                order by Participante.NombreParticipante";

        return $this->bd->query($sql)->fetchAll();
    }

    public function obtenerParticipante(int $id): ?array
    {
        $stmt = $this->bd->prepare(
            "select Participante.IdParticipante     as id,
                    Participante.NombreParticipante as nombre,
                    Participante.Alias              as alias,
                    Participante.FechaNacimiento    as fecha_nacimiento,
                    Participante.PerfilPublico      as perfil_publico
             from Participante
             where Participante.IdParticipante = :id"
        );
        $stmt->execute([':id' => $id]);

        $fila = $stmt->fetch();

        return $fila ?: null;
    }

    /** Participante vinculado a una cuenta de usuario, o null si la cuenta no tiene */
    public function participanteDeUsuario(int $idUsuario): ?array
    {
        $stmt = $this->bd->prepare(
            "select Participante.IdParticipante     as id,
                    Participante.NombreParticipante as nombre,
                    Participante.Alias              as alias,
                    Participante.FechaNacimiento    as fecha_nacimiento,
                    Participante.PerfilPublico      as perfil_publico
             from Participante
             inner join Vincula on Participante.IdParticipante = Vincula.IdParticipante
             where Vincula.IdUsuario = :usuario"
        );
        $stmt->execute([':usuario' => $idUsuario]);

        $fila = $stmt->fetch();

        return $fila ?: null;
    }

    /** Alta. Con $idUsuario, el participante queda vinculado a esa cuenta */
    public function crearParticipante(string $nombre, ?string $alias, ?string $fechaNacimiento,
                                      bool $perfilPublico, ?int $idUsuario = null): int
    {
        // Dentro de una transacción en curso (alta de un equipo) se suma a ella
        $propia = !$this->bd->inTransaction();
        if ($propia) {
            $this->bd->beginTransaction();
        }

        try {
            $stmt = $this->bd->prepare(
                "insert into Participante (NombreParticipante, Alias, FechaNacimiento, PerfilPublico)
                 values (:nombre, :alias, :nacimiento, :publico)"
            );
            $stmt->execute([
                ':nombre'     => $nombre,
                ':alias'      => $alias,
                ':nacimiento' => $fechaNacimiento,
                ':publico'    => $perfilPublico ? 1 : 0,
            ]);

            $id = (int) $this->bd->lastInsertId();

            if ($idUsuario !== null) {
                $stmt = $this->bd->prepare(
                    "insert into Vincula (IdParticipante, IdUsuario) values (:participante, :usuario)"
                );
                $stmt->execute([':participante' => $id, ':usuario' => $idUsuario]);
            }

            if ($propia) {
                $this->bd->commit();
            }
        } catch (Throwable $e) {
            if ($propia) {
                $this->bd->rollBack();
            }
            throw $e;
        }

        return $id;
    }

    public function modificarParticipante(int $id, string $nombre, ?string $alias,
                                          ?string $fechaNacimiento, bool $perfilPublico): void
    {
        $stmt = $this->bd->prepare(
            "update Participante
             set NombreParticipante = :nombre, Alias = :alias,
                 FechaNacimiento = :nacimiento, PerfilPublico = :publico
             where IdParticipante = :id"
        );
        $stmt->execute([
            ':nombre'     => $nombre,
            ':alias'      => $alias,
            ':nacimiento' => $fechaNacimiento,
            ':publico'    => $perfilPublico ? 1 : 0,
            ':id'         => $id,
        ]);
    }

    /** Borra el participante. Devuelve false si tiene inscripciones (FK RESTRICT) */
    /**
     * Baja de un participante. Si tiene cuenta, la cuenta pasa a INACTIVO en la misma
     * transacción, así no vuelve a ingresar. Con inscripciones (FK RESTRICT) el participante
     * se conserva para los resultados. Devuelve 'eliminado', 'eliminado-cuenta',
     * 'cuenta' (solo se desactivó la cuenta) o 'no' (no existe o tiene inscripciones sin cuenta)
     */
    public function eliminarParticipante(int $id): string
    {
        $this->bd->beginTransaction();

        try {
            $stmt = $this->bd->prepare("select IdUsuario from Vincula where IdParticipante = :id");
            $stmt->execute([':id' => $id]);
            $idUsuario = $stmt->fetchColumn();

            if ($idUsuario !== false) {
                $stmt = $this->bd->prepare("update Usuario set Estado = 'INACTIVO' where IdUsuario = :usuario");
                $stmt->execute([':usuario' => $idUsuario]);
            }

            $this->bd->exec("savepoint baja");
            try {
                $stmt = $this->bd->prepare("delete from Participante where IdParticipante = :id");
                $stmt->execute([':id' => $id]);
                $borrado = $stmt->rowCount() > 0;
            } catch (PDOException $e) {
                $this->bd->exec("rollback to savepoint baja");
                $borrado = false;
            }

            $this->bd->commit();
        } catch (Throwable $e) {
            $this->bd->rollBack();
            throw $e;
        }

        if ($idUsuario === false) {
            return $borrado ? 'eliminado' : 'no';
        }

        return $borrado ? 'eliminado-cuenta' : 'cuenta';
    }

    public function listarEquipos(): array
    {
        $sql = "select Equipo.IdEquipo      as id,
                       Equipo.NombreEquipo  as nombre,
                       Equipo.PerfilPublico as perfil_publico,
                       Equipo.FechaCreacion as fecha_creacion,
                       (select count(*) from Integra
                         where Integra.IdEquipo = Equipo.IdEquipo) as integrantes,
                       (select count(*) from Inscripcion
                         where Inscripcion.IdParticipante = Equipo.IdParticipante) as torneos
                from Equipo
                order by Equipo.NombreEquipo";

        return $this->bd->query($sql)->fetchAll();
    }

    public function obtenerEquipo(int $id): ?array
    {
        $stmt = $this->bd->prepare(
            "select Equipo.IdEquipo      as id,
                    Equipo.NombreEquipo  as nombre,
                    Equipo.PerfilPublico as perfil_publico,
                    Equipo.FechaCreacion as fecha_creacion,
                    Equipo.IdParticipante as id_representante
             from Equipo
             where Equipo.IdEquipo = :id"
        );
        $stmt->execute([':id' => $id]);

        $fila = $stmt->fetch();

        return $fila ?: null;
    }

    public function listarIntegrantes(int $idEquipo): array
    {
        $stmt = $this->bd->prepare(
            "select Participante.IdParticipante     as id,
                    Participante.NombreParticipante as nombre,
                    Participante.Alias              as alias,
                    Participante.PerfilPublico      as perfil_publico,
                    Integra.FechaIngreso            as fecha_ingreso
             from Integra
             inner join Participante on Integra.IdParticipante = Participante.IdParticipante
             where Integra.IdEquipo = :equipo
             order by Participante.NombreParticipante"
        );
        $stmt->execute([':equipo' => $idEquipo]);

        return $stmt->fetchAll();
    }

    public function equiposDeParticipante(int $idParticipante): array
    {
        $stmt = $this->bd->prepare(
            "select Equipo.IdEquipo      as id,
                    Equipo.NombreEquipo  as nombre,
                    Equipo.PerfilPublico as perfil_publico
             from Integra
             inner join Equipo on Integra.IdEquipo = Equipo.IdEquipo
             where Integra.IdParticipante = :participante
             order by Equipo.NombreEquipo"
        );
        $stmt->execute([':participante' => $idParticipante]);

        return $stmt->fetchAll();
    }

    /** Equipo con ese nombre, sin distinguir mayúsculas ni tildes (intercalación de la base) */
    public function buscarEquipoPorNombre(string $nombre): ?array
    {
        $stmt = $this->bd->prepare("select Equipo.IdEquipo from Equipo where Equipo.NombreEquipo = :nombre");
        $stmt->execute([':nombre' => $nombre]);
        $id = $stmt->fetchColumn();

        return $id === false ? null : $this->obtenerEquipo((int) $id);
    }

    /** ¿El participante integra el equipo? */
    public function integra(int $idEquipo, int $idParticipante): bool
    {
        $stmt = $this->bd->prepare(
            "select count(*) from Integra where IdEquipo = :equipo and IdParticipante = :participante"
        );
        $stmt->execute([':equipo' => $idEquipo, ':participante' => $idParticipante]);

        return (int) $stmt->fetchColumn() > 0;
    }

    /**
     * Equipos de un participante, con la fecha de ingreso, los integrantes y los torneos en
     * los que figura el equipo
     */
    public function misEquipos(int $idParticipante): array
    {
        $stmt = $this->bd->prepare(
            "select Equipo.IdEquipo       as id,
                    Equipo.NombreEquipo   as nombre,
                    Equipo.PerfilPublico  as perfil_publico,
                    Integra.FechaIngreso  as fecha_ingreso,
                    (select group_concat(Otro.NombreParticipante order by Otro.NombreParticipante
                                         separator ', ')
                       from Integra Todos
                       inner join Participante Otro on Todos.IdParticipante = Otro.IdParticipante
                      where Todos.IdEquipo = Equipo.IdEquipo) as integrantes,
                    (select group_concat(concat(Torneo.NombreTorneo, ' (',
                                                lower(Inscripcion.EstadoInscripcion), ')')
                                         order by Torneo.FechaInicio desc separator ', ')
                       from Inscripcion
                       inner join Torneo on Inscripcion.IdTorneo = Torneo.IdTorneo
                      where Inscripcion.IdParticipante = Equipo.IdParticipante) as torneos
             from Integra
             inner join Equipo on Integra.IdEquipo = Equipo.IdEquipo
             where Integra.IdParticipante = :participante
             order by Equipo.NombreEquipo"
        );
        $stmt->execute([':participante' => $idParticipante]);

        return $stmt->fetchAll();
    }

    /**
     * Alta del equipo y de su representante, en una sola transacción.
     * Devuelve el identificador del equipo, o null si el nombre ya existe (uqEquipoNombreEquipo)
     */
    public function crearEquipo(string $nombre, bool $perfilPublico): ?int
    {
        $propia = !$this->bd->inTransaction();
        if ($propia) {
            $this->bd->beginTransaction();
        }

        try {
            $representante = $this->crearParticipante($nombre, null, null, $perfilPublico);
            $stmt = $this->bd->prepare(
                "insert into Equipo (NombreEquipo, PerfilPublico, FechaCreacion, IdParticipante)
                 values (:nombre, :publico, curdate(), :representante)"
            );
            $stmt->execute([
                ':nombre'        => $nombre,
                ':publico'       => $perfilPublico ? 1 : 0,
                ':representante' => $representante,
            ]);
            $id = (int) $this->bd->lastInsertId();
        } catch (PDOException $e) {
            if ($propia) {
                $this->bd->rollBack();
                return null;
            }
            throw $e;
        }

        if ($propia) {
            $this->bd->commit();
        }

        return $id;
    }

    /** Cambia el nombre y el perfil del equipo y, con ellos, los de su representante */
    public function modificarEquipo(int $id, string $nombre, bool $perfilPublico): bool
    {
        try {
            $stmt = $this->bd->prepare(
                "update Equipo set NombreEquipo = :nombre, PerfilPublico = :publico where IdEquipo = :id"
            );
            $stmt->execute([':nombre' => $nombre, ':publico' => $perfilPublico ? 1 : 0, ':id' => $id]);
        } catch (PDOException $e) {
            return false;
        }

        $stmt = $this->bd->prepare(
            "update Participante
             inner join Equipo on Equipo.IdParticipante = Participante.IdParticipante
             set Participante.NombreParticipante = :nombre, Participante.PerfilPublico = :publico
             where Equipo.IdEquipo = :id"
        );
        $stmt->execute([':nombre' => $nombre, ':publico' => $perfilPublico ? 1 : 0, ':id' => $id]);

        return true;
    }

    /**
     * Representante del equipo. Si no tiene (se borró desde la lista de participantes), lo
     * crea con el nombre y el perfil del equipo
     */
    public function representante(int $idEquipo): ?int
    {
        $equipo = $this->obtenerEquipo($idEquipo);
        if ($equipo === null) {
            return null;
        }
        if ($equipo['id_representante'] !== null) {
            return (int) $equipo['id_representante'];
        }

        $id   = $this->crearParticipante($equipo['nombre'], null, null, (int) $equipo['perfil_publico'] === 1);
        $stmt = $this->bd->prepare("update Equipo set IdParticipante = :representante where IdEquipo = :id");
        $stmt->execute([':representante' => $id, ':id' => $idEquipo]);

        return $id;
    }

    /**
     * Borra las solicitudes del equipo y el equipo; por la FK en cascada, sus filas de Integra.
     * El representante se borra si no tiene inscripciones; si las tiene, queda para que los
     * torneos jugados conserven sus resultados
     */
    public function eliminarEquipo(int $id): void
    {
        $equipo = $this->obtenerEquipo($id);

        $stmt = $this->bd->prepare("delete from SolicitudEquipo where IdEquipo = :id");
        $stmt->execute([':id' => $id]);
        $stmt = $this->bd->prepare("delete from Equipo where IdEquipo = :id");
        $stmt->execute([':id' => $id]);

        if ($equipo !== null && $equipo['id_representante'] !== null) {
            $this->eliminarParticipante((int) $equipo['id_representante']);
        }
    }

    /** Devuelve false si el participante ya integra el equipo o alguno de los dos no existe */
    public function agregarIntegrante(int $idEquipo, int $idParticipante): bool
    {
        try {
            $stmt = $this->bd->prepare(
                "insert into Integra (IdParticipante, IdEquipo, FechaIngreso)
                 values (:participante, :equipo, curdate())"
            );
            $stmt->execute([':participante' => $idParticipante, ':equipo' => $idEquipo]);
        } catch (PDOException $e) {
            return false;
        }

        return true;
    }

    public function quitarIntegrante(int $idEquipo, int $idParticipante): void
    {
        $stmt = $this->bd->prepare(
            "delete from Integra where IdEquipo = :equipo and IdParticipante = :participante"
        );
        $stmt->execute([':equipo' => $idEquipo, ':participante' => $idParticipante]);
    }
}
