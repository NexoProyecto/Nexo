<?php
require_once __DIR__ . '/ConexionBD.php';

/** Torneos: alta, configuración, estado y consultas públicas */
class GestorTorneos
{
    /** Módulo: código => texto */
    private const MODULO = "case ModuloCompetencia.NombreModulo
                                when 'LIGA'         then 'Liga'
                                when 'ELIMINATORIA' then 'Eliminación directa'
                                else 'Sistema suizo'
                            end";

    /** Estado: código => texto */
    private const ESTADO = "case Torneo.Estado
                                when 'SOLICITADO' then 'Solicitado'
                                when 'RECHAZADO'  then 'Rechazado'
                                when 'BORRADOR'   then 'Borrador'
                                when 'ABIERTO'    then 'Inscripciones'
                                when 'EN CURSO'   then 'En curso'
                                when 'FINALIZADO' then 'Finalizado'
                                when 'CERRADO'    then 'Cerrado'
                                else 'Cancelado'
                            end";

    /** Tipo de torneo: código => texto */
    private const DISCIPLINA = "case TipoTorneo.NombreTipo
                                    when 'DEPORTIVO' then 'Deportivo'
                                    when 'MENTAL'    then 'Mental'
                                    else 'Electrónico'
                                end";

    /** Columnas y tablas comunes a los listados */
    private const SELECT_BASE = "
        select Torneo.IdTorneo     as id,
               Torneo.NombreTorneo as nombre,
               Torneo.FechaInicio  as fecha_inicio,
               Torneo.FechaFin     as fecha_fin,
               Torneo.Estado       as estado_codigo,
               " . self::ESTADO . " as estado,
               Torneo.IdTipoTorneo as id_tipo,
               " . self::DISCIPLINA . " as disciplina,
               ModuloCompetencia.NombreModulo as modulo_codigo,
               " . self::MODULO . " as modulo,
               Configura.ReglasEspecificas as reglas,
               Torneo.IdUsuario    as id_organizador,
               concat(Usuario.Nombre, ' ', Usuario.Apellido) as organizador,
               (select count(*) from Inscripcion
                 where Inscripcion.IdTorneo = Torneo.IdTorneo
                   and Inscripcion.EstadoInscripcion = 'ACEPTADA') as inscriptos
        from Torneo
        inner join TipoTorneo        on Torneo.IdTipoTorneo  = TipoTorneo.IdTipoTorneo
        inner join Usuario           on Torneo.IdUsuario     = Usuario.IdUsuario
        inner join Configura         on Torneo.IdTorneo      = Configura.IdTorneo
                                    and Configura.Habilitado = 1
        inner join ModuloCompetencia on Configura.IdModulo   = ModuloCompetencia.IdModulo";

    public const MODULOS = ['LIGA', 'ELIMINATORIA', 'SUIZO'];

    /** Estados que no se muestran al público */
    public const NO_PUBLICOS = ['SOLICITADO', 'RECHAZADO', 'BORRADOR'];
    private const NO_PUBLICOS_SQL = "('SOLICITADO', 'RECHAZADO', 'BORRADOR')";

    /**
     * Imagen de cada juego: se busca la palabra en el nombre del torneo.
     * El orden importa: "futbol 7" va antes que "futbol" y "tenis de mesa" antes que cualquier otra.
     */
    private const IMAGEN_DEL_JUEGO = [
        '/\bfutbol 7\b/'                       => 'copa-invierno.webp',
        '/\b(futbol|soccer)\b/'                => 'futbol.jpg',
        '/\b(tenis de mesa|ping ?pong)\b/'     => 'pingpong.jpg',
        '/\b(handball|balonmano)\b/'           => 'handball.jpg',
        '/\b(voley|voleibol|volleyball)\b/'    => 'voleibol.jpg',
        '/\b(basquet|basquetbol|basket|baloncesto)\b/' => 'basquetbol.jpg',
        '/\b(league of legends|lol)\b/'        => 'league-of-legends.jpg',
        '/\brocket league\b/'                  => 'rocket-league.jpg',
        '/\bvalorant\b/'                       => 'valorant.jpg',
        '/\b(counter|cs2|csgo)\b/'             => 'counter.webp',
        '/\b(ajedrez|chess)\b/'                => 'ajedrez.jpg',
        '/\bdamas\b/'                          => 'damas.jpg',
        '/\bgo\b/'                             => 'go.jpg',
        '/\btruco\b/'                          => 'truco.jpg',
        '/\b(poker|cartas|naipes)\b/'      => 'cartas.jpg',
    ];

    /** Si el nombre no dice el juego, se usa una imagen general del tipo de torneo */
    private const IMAGEN_DEL_TIPO = [
        'Deportivo'   => 'futbol.jpg',
        'Electrónico' => 'esports.jpg',
        'Mental'      => 'ajedrez.jpg',
    ];

    /** Ruta de la imagen de portada de un torneo, según su nombre o su tipo */
    public static function imagenDeTorneo(string $nombre, string $disciplina): string
    {
        // Minúsculas y sin tildes, para que "Fútbol" y "futbol" den lo mismo
        $texto = strtr(mb_strtolower($nombre), [
            'á' => 'a', 'é' => 'e', 'í' => 'i',
            'ó' => 'o', 'ú' => 'u', 'ü' => 'u',
        ]);

        foreach (self::IMAGEN_DEL_JUEGO as $patron => $imagen) {
            if (preg_match($patron, $texto)) {
                return 'img/' . $imagen;
            }
        }

        return 'img/' . (self::IMAGEN_DEL_TIPO[$disciplina] ?? 'ajedrez.jpg');
    }

    private PDO $bd;

    public function __construct(?PDO $conexion = null)
    {
        $this->bd = $conexion ?? ConexionBD::obtener();
    }

    /** Torneos publicados (sin los solicitados, rechazados ni en borrador), con filtros por nombre y módulo */
    public function listarTorneos(string $busqueda = '', string $modulo = ''): array
    {
        $sql = self::SELECT_BASE . " where Torneo.Estado not in " . self::NO_PUBLICOS_SQL;

        $parametros = [];

        if ($busqueda !== '') {
            $sql .= " and Torneo.NombreTorneo like :busqueda";
            $parametros[':busqueda'] = '%' . $busqueda . '%';
        }

        if ($modulo !== '' && $modulo !== 'Todos') {
            $sql .= " and " . self::MODULO . " = :modulo";
            $parametros[':modulo'] = $modulo;
        }

        $sql .= " order by Torneo.FechaInicio desc, Torneo.IdTorneo desc";

        $stmt = $this->bd->prepare($sql);
        $stmt->execute($parametros);

        return $stmt->fetchAll();
    }

    /** Torneos de la portada: en curso y con inscripciones abiertas */
    public function listarTorneosPortada(int $limite = 3): array
    {
        $sql = self::SELECT_BASE . "
                where Torneo.Estado in ('EN CURSO', 'ABIERTO')
                order by Torneo.FechaInicio desc
                limit :limite";

        $stmt = $this->bd->prepare($sql);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    /** Torneos que creó un organizador o en los que fue aceptado como organizador; sin argumento, todos */
    public function listarDeOrganizador(?int $idUsuario = null): array
    {
        $sql = self::SELECT_BASE;
        $parametros = [];

        if ($idUsuario !== null) {
            $sql .= " where Torneo.IdUsuario = :creador
                         or exists (select 1 from Organiza
                                    where Organiza.IdTorneo = Torneo.IdTorneo
                                      and Organiza.IdUsuario = :organizador
                                      and Organiza.EstadoOrganiza = 'ACEPTADA')";
            $parametros[':creador']     = $idUsuario;
            $parametros[':organizador'] = $idUsuario;
        }

        $sql .= " order by Torneo.FechaInicio desc, Torneo.IdTorneo desc";

        $stmt = $this->bd->prepare($sql);
        $stmt->execute($parametros);

        return $stmt->fetchAll();
    }

    public function listarEnCurso(): array
    {
        return $this->bd->query(self::SELECT_BASE . " where Torneo.Estado = 'EN CURSO'
                                                     order by Torneo.FechaInicio desc")->fetchAll();
    }

    public function listarCerrados(): array
    {
        return $this->bd->query(self::SELECT_BASE . " where Torneo.Estado = 'CERRADO'
                                                     order by Torneo.FechaInicio desc")->fetchAll();
    }

    public function obtener(int $id): ?array
    {
        $stmt = $this->bd->prepare(self::SELECT_BASE . " where Torneo.IdTorneo = :id");
        $stmt->execute([':id' => $id]);

        $fila = $stmt->fetch();

        return $fila ?: null;
    }

    public function listarTipos(): array
    {
        $sql = "select TipoTorneo.IdTipoTorneo as id,
                       " . self::DISCIPLINA . " as nombre
                from TipoTorneo
                order by TipoTorneo.IdTipoTorneo";

        return $this->bd->query($sql)->fetchAll();
    }

    /**
     * Alta con su módulo de competencia: BORRADOR si lo crea el administrador, SOLICITADO si
     * lo pide un organizador. Devuelve el identificador
     */
    public function crear(string $nombre, string $fechaInicio, ?string $fechaFin, int $idTipo,
                          string $modulo, ?string $reglas, int $idUsuario, string $estado = 'BORRADOR'): int
    {
        if (!in_array($estado, ['BORRADOR', 'SOLICITADO'], true)) {
            throw new InvalidArgumentException('Estado inicial no válido: ' . $estado);
        }

        $this->bd->beginTransaction();

        try {
            $stmt = $this->bd->prepare(
                "insert into Torneo (NombreTorneo, FechaInicio, FechaFin, Estado, IdTipoTorneo, IdUsuario)
                 values (:nombre, :inicio, :fin, :estado, :tipo, :usuario)"
            );
            $stmt->execute([
                ':estado'  => $estado,
                ':nombre'  => $nombre,
                ':inicio'  => $fechaInicio,
                ':fin'     => $fechaFin,
                ':tipo'    => $idTipo,
                ':usuario' => $idUsuario,
            ]);

            $id = (int) $this->bd->lastInsertId();
            $this->habilitarModulo($id, $modulo, $reglas);

            $this->bd->commit();
        } catch (Throwable $e) {
            $this->bd->rollBack();
            throw $e;
        }

        return $id;
    }

    /** Cambia los datos de un torneo que todavía no empezó */
    public function modificar(int $id, string $nombre, string $fechaInicio, ?string $fechaFin,
                              int $idTipo, string $modulo, ?string $reglas): void
    {
        $this->bd->beginTransaction();

        try {
            $stmt = $this->bd->prepare(
                "update Torneo
                 set NombreTorneo = :nombre, FechaInicio = :inicio, FechaFin = :fin, IdTipoTorneo = :tipo
                 where IdTorneo = :id and Estado in ('BORRADOR', 'ABIERTO')"
            );
            $stmt->execute([
                ':nombre' => $nombre,
                ':inicio' => $fechaInicio,
                ':fin'    => $fechaFin,
                ':tipo'   => $idTipo,
                ':id'     => $id,
            ]);

            $this->habilitarModulo($id, $modulo, $reglas);

            $this->bd->commit();
        } catch (Throwable $e) {
            $this->bd->rollBack();
            throw $e;
        }
    }

    /** Deja habilitado un solo módulo en Configura y deshabilita los demás */
    private function habilitarModulo(int $idTorneo, string $modulo, ?string $reglas): void
    {
        $stmt = $this->bd->prepare("update Configura set Habilitado = 0 where IdTorneo = :torneo");
        $stmt->execute([':torneo' => $idTorneo]);

        $stmt = $this->bd->prepare(
            "insert into Configura (IdTorneo, IdModulo, ReglasEspecificas, Habilitado)
             select :torneo, ModuloCompetencia.IdModulo, :reglas, 1
             from ModuloCompetencia
             where ModuloCompetencia.NombreModulo = :modulo
             on duplicate key update ReglasEspecificas = values(ReglasEspecificas), Habilitado = 1"
        );
        $stmt->execute([':torneo' => $idTorneo, ':reglas' => $reglas, ':modulo' => $modulo]);
    }

    /** Torneos que pidieron los organizadores y esperan la decisión del administrador */
    public function listarSolicitados(): array
    {
        $stmt = $this->bd->query(self::SELECT_BASE . "
            where Torneo.Estado = 'SOLICITADO'
            order by Torneo.IdTorneo");

        return $stmt->fetchAll();
    }

    /** El administrador acepta (pasa a BORRADOR) o rechaza (RECHAZADO) un torneo solicitado */
    public function resolverSolicitud(int $id, bool $aprobar): bool
    {
        $stmt = $this->bd->prepare(
            "update Torneo set Estado = :estado
             where IdTorneo = :id and Estado = 'SOLICITADO'"
        );
        $stmt->execute([
            ':estado' => $aprobar ? 'BORRADOR' : 'RECHAZADO',
            ':id'     => $id,
        ]);

        return $stmt->rowCount() > 0;
    }

    /** Publica (BORRADOR a ABIERTO) o cancela un torneo que no terminó */
    public function cambiarEstado(int $id, string $estado): bool
    {
        $desde = [
            'ABIERTO'   => "('BORRADOR')",
            'CANCELADO' => "('BORRADOR', 'ABIERTO', 'EN CURSO')",
        ];

        if (!isset($desde[$estado])) {
            return false;
        }

        $stmt = $this->bd->prepare(
            "update Torneo set Estado = :estado where IdTorneo = :id and Estado in " . $desde[$estado]
        );
        $stmt->execute([':estado' => $estado, ':id' => $id]);

        return $stmt->rowCount() > 0;
    }

    /**
     * Cierra un torneo publicado: guarda el estado que tenía y deja de admitir cambios.
     * Un borrador no se cierra (se cancela)
     */
    public function cerrar(int $id): bool
    {
        // MariaDB asigna en orden: EstadoPrevio toma el estado anterior al cambio
        $stmt = $this->bd->prepare(
            "update Torneo set EstadoPrevio = Estado, Estado = 'CERRADO'
             where IdTorneo = :id and Estado in ('ABIERTO', 'EN CURSO', 'FINALIZADO', 'CANCELADO')"
        );
        $stmt->execute([':id' => $id]);

        return $stmt->rowCount() > 0;
    }


    /** Partidos sin resultado de los torneos en curso */
    public function listarProximosPartidos(?int $idTorneo = null): array
    {
        $sql = "select Enfrentamiento.IdEnfrentamiento as id,
                       date(Enfrentamiento.FechaHora)  as fecha,
                       time(Enfrentamiento.FechaHora)  as hora,
                       Torneo.IdTorneo                 as id_torneo,
                       Torneo.NombreTorneo             as torneo,
                       concat('Ronda ', Enfrentamiento.NumeroRonda) as ronda,
                       PartLocal.NombreParticipante  as local,
                       PartVisita.NombreParticipante as visitante
                from Enfrentamiento
                inner join Torneo on Enfrentamiento.IdTorneo = Torneo.IdTorneo
                inner join Inscripcion  InsLocal   on Enfrentamiento.IdInscripcionLocal
                                                    = InsLocal.IdInscripcion
                inner join Participante PartLocal  on InsLocal.IdParticipante
                                                    = PartLocal.IdParticipante
                inner join Inscripcion  InsVisita  on Enfrentamiento.IdInscripcionVisitante
                                                    = InsVisita.IdInscripcion
                inner join Participante PartVisita on InsVisita.IdParticipante
                                                    = PartVisita.IdParticipante
                where Enfrentamiento.EstadoPartido = 'PROGRAMADO'
                  and Torneo.Estado = 'EN CURSO'";

        $parametros = [];
        if ($idTorneo !== null) {
            $sql .= " and Torneo.IdTorneo = :torneo";
            $parametros[':torneo'] = $idTorneo;
        }

        $sql .= " order by Enfrentamiento.FechaHora, Enfrentamiento.IdEnfrentamiento limit 60";

        $stmt = $this->bd->prepare($sql);
        $stmt->execute($parametros);

        return $stmt->fetchAll();
    }

    /** Resultados oficiales: los que el organizador validó */
    public function listarResultados(int $limite = 40): array
    {
        $sql = "select date(Enfrentamiento.FechaHora) as fecha,
                       Torneo.IdTorneo                as id_torneo,
                       Torneo.NombreTorneo            as torneo,
                       PartLocal.NombreParticipante   as local,
                       PartVisita.NombreParticipante  as visitante,
                       Resultado.PuntuacionLocal      as puntos_local,
                       Resultado.PuntuacionVisitante  as puntos_visitante
                from Resultado
                inner join Enfrentamiento on Resultado.IdEnfrentamiento
                                           = Enfrentamiento.IdEnfrentamiento
                inner join Torneo on Enfrentamiento.IdTorneo = Torneo.IdTorneo
                inner join Inscripcion  InsLocal   on Enfrentamiento.IdInscripcionLocal
                                                    = InsLocal.IdInscripcion
                inner join Participante PartLocal  on InsLocal.IdParticipante
                                                    = PartLocal.IdParticipante
                inner join Inscripcion  InsVisita  on Enfrentamiento.IdInscripcionVisitante
                                                    = InsVisita.IdInscripcion
                inner join Participante PartVisita on InsVisita.IdParticipante
                                                    = PartVisita.IdParticipante
                where Resultado.Validado = 1
                  and Torneo.Estado in ('EN CURSO', 'FINALIZADO')
                order by Enfrentamiento.FechaHora desc, Enfrentamiento.IdEnfrentamiento desc
                limit :limite";

        $stmt = $this->bd->prepare($sql);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    /** Tabla de posiciones de un torneo */
    public function listarPosiciones(int $torneoId): array
    {
        $sql = "select TablaPosiciones.PartidosJugados  as jugados,
                       TablaPosiciones.Victorias        as ganados,
                       TablaPosiciones.Empates          as empatados,
                       TablaPosiciones.Derrotas         as perdidos,
                       TablaPosiciones.PuntosAcumulados as puntos,
                       Participante.IdParticipante      as id_participante,
                       Participante.NombreParticipante  as participante,
                       Participante.PerfilPublico       as perfil_publico
                from TablaPosiciones
                inner join Inscripcion  on TablaPosiciones.IdInscripcion
                                         = Inscripcion.IdInscripcion
                inner join Participante on Inscripcion.IdParticipante
                                         = Participante.IdParticipante
                where TablaPosiciones.IdTorneo = :torneo
                order by TablaPosiciones.PuntosAcumulados desc,
                         TablaPosiciones.Victorias desc,
                         TablaPosiciones.Derrotas,
                         Participante.NombreParticipante";

        $stmt = $this->bd->prepare($sql);
        $stmt->execute([':torneo' => $torneoId]);

        return $stmt->fetchAll();
    }

    /** Torneo de liga en curso con más partidos jugados, para la tabla de la portada */
    public function torneoDestacado(): ?array
    {
        $sql = self::SELECT_BASE . "
                where Torneo.Estado = 'EN CURSO'
                  and ModuloCompetencia.NombreModulo = 'LIGA'
                order by (select count(*) from Enfrentamiento
                           where Enfrentamiento.IdTorneo = Torneo.IdTorneo
                             and Enfrentamiento.EstadoPartido = 'JUGADO') desc,
                         Torneo.IdTorneo
                limit 1";

        $fila = $this->bd->query($sql)->fetch();

        return $fila ?: null;
    }

    /** Totales de la portada */
    public function estadisticas(): array
    {
        return [
            'torneos'       => $this->contar("select count(*) from Torneo where Estado not in " . self::NO_PUBLICOS_SQL),
            'participantes' => $this->contar("select count(*) from Inscripcion
                                              where EstadoInscripcion = 'ACEPTADA'"),
            'proximos'      => $this->contar("select count(*) from Torneo where Estado = 'ABIERTO'"),
            'partidos'      => $this->contar("select count(*) from Enfrentamiento
                                              inner join Torneo on Enfrentamiento.IdTorneo = Torneo.IdTorneo
                                              where Enfrentamiento.EstadoPartido = 'PROGRAMADO'
                                                and Torneo.Estado = 'EN CURSO'"),
        ];
    }

    /** Reporte general: cantidad de torneos por estado y por módulo */
    public function reporte(): array
    {
        $porEstado = $this->bd->query(
            "select " . self::ESTADO . " as nombre, count(*) as cantidad
             from Torneo
             group by Torneo.Estado
             order by count(*) desc"
        )->fetchAll();

        $porModulo = $this->bd->query(
            "select " . self::MODULO . " as nombre, count(*) as cantidad
             from Configura
             inner join ModuloCompetencia on Configura.IdModulo = ModuloCompetencia.IdModulo
             where Configura.Habilitado = 1
             group by ModuloCompetencia.NombreModulo
             order by count(*) desc"
        )->fetchAll();

        return [
            'por_estado' => $porEstado,
            'por_modulo' => $porModulo,
            'usuarios'   => $this->contar("select count(*) from Usuario where Estado = 'ACTIVO'"),
            'jugados'    => $this->contar("select count(*) from Enfrentamiento where EstadoPartido = 'JUGADO'"),
            'sin_validar' => $this->contar("select count(*) from Resultado where Validado = 0"),
        ];
    }

    private function contar(string $sql): int
    {
        return (int) $this->bd->query($sql)->fetchColumn();
    }
}
