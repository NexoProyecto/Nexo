<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Vista: gestión de un torneo ($torneo, $tipos, $inscripciones, $participantes, $rondas, $posiciones, $organizadores, $esAdministrador, $pedidosEquipos, $tokenCsrf, $aviso)
$titulo = 'Gestión · ' . $torneo['nombre'];
$activo = 'organizador';
require __DIR__ . '/parciales/cabecera.php';

$estado    = $torneo['estado_codigo'];
$editable  = in_array($estado, ['BORRADOR', 'ABIERTO'], true);
$aceptadas = 0;
foreach ($inscripciones as $inscripcion) {
    if ($inscripcion['estado_codigo'] === 'ACEPTADA') {
        $aceptadas++;
    }
}

/** Campos ocultos de todo formulario de esta pantalla */
$ocultos = '<input type="hidden" name="tokenCsrf" value="' . e($tokenCsrf) . '">'
         . '<input type="hidden" name="torneo" value="' . (int) $torneo['id'] . '">';
?>
        <header class="encabezado">
            <h1><?= e($torneo['nombre']) ?></h1>
            <span class="etiqueta <?= clase_de_modulo($torneo['modulo']) ?>"><?= e($torneo['modulo']) ?></span>
            <p>
                <?= e($torneo['disciplina']) ?> · Estado: <strong><?= e($torneo['estado']) ?></strong> ·
                <?= fecha_corta($torneo['fecha_inicio']) ?> - <?= fecha_corta($torneo['fecha_fin']) ?> ·
                Organiza: <?= e($torneo['organizador']) ?>
            </p>
        </header>

        <?php if (!empty($aviso)): ?>
            <div class="aviso-rol" id="aviso"><?= e($aviso) ?></div>
        <?php endif; ?>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Estado del torneo</h2>
                <a href="index.php?ruta=organizador">‹ Volver a los torneos</a>
            </div>
            <div class="acciones">
                <?php if ($estado === 'BORRADOR'): ?>
                <form class="form-linea" action="index.php?ruta=gestion/publicar" method="POST">
                    <?= $ocultos ?>
                    <button type="submit" class="boton">Publicar y abrir inscripciones</button>
                </form>
                <?php endif; ?>
                <?php if ($estado === 'ABIERTO'): ?>
                <form class="form-linea" action="index.php?ruta=gestion/iniciar" method="POST"
                      data-confirmar="¿Iniciar el torneo? Se cierran las inscripciones y se generan los enfrentamientos con las <?= $aceptadas ?> inscripciones aceptadas." data-boton="Iniciar torneo">
                    <?= $ocultos ?>
                    <button type="submit" class="boton">Iniciar torneo y generar rondas</button>
                </form>
                <?php endif; ?>
                <?php if ($estado === 'EN CURSO'): ?>
                <form class="form-linea" action="index.php?ruta=gestion/cerrar-ronda" method="POST"
                      data-confirmar="¿Cerrar la ronda en curso? Sus resultados dejan de modificarse." data-boton="Cerrar ronda">
                    <?= $ocultos ?>
                    <button type="submit" class="boton">Cerrar la ronda en curso</button>
                </form>
                <?php endif; ?>
                <?php if (in_array($estado, ['BORRADOR', 'ABIERTO', 'EN CURSO'], true)): ?>
                <form class="form-linea" action="index.php?ruta=gestion/cancelar" method="POST"
                      data-confirmar="¿Cancelar el torneo <?= e($torneo['nombre']) ?>?"
                      data-aviso="Esta acción no se puede deshacer." data-boton="Cancelar torneo">
                    <?= $ocultos ?>
                    <button type="submit" class="boton-borde">Cancelar torneo</button>
                </form>
                <?php endif; ?>
                <?php if (in_array($estado, ['ABIERTO', 'EN CURSO', 'FINALIZADO', 'CANCELADO'], true)): ?>
                <form class="form-linea" action="index.php?ruta=gestion/cerrar" method="POST"
                      data-confirmar="¿Cerrar el torneo <?= e($torneo['nombre']) ?>? Deja de admitir cambios y ningún organizador lo administra."
                      data-aviso="Esta acción no se puede deshacer desde la gestión del torneo. La reapertura la pide un organizador desde su panel y la resuelve el administrador."
                      data-boton="Cerrar torneo">
                    <?= $ocultos ?>
                    <button type="submit" class="boton-borde">Cerrar torneo</button>
                </form>
                <?php endif; ?>
                <?php if ($estado === 'CERRADO' && $esAdministrador): ?>
                <a class="boton" href="index.php?ruta=admin#cerrados">Reabrir desde el panel de administración</a>
                <?php endif; ?>
                <?php if ($estado !== 'BORRADOR'): ?>
                <a class="boton-borde" href="index.php?ruta=torneo&amp;id=<?= (int) $torneo['id'] ?>">Ver página pública</a>
                <?php endif; ?>
            </div>
            <p class="ayuda-campo">
                <?php if ($estado === 'BORRADOR'): ?>
                    En borrador el torneo no figura en la consulta pública.
                <?php elseif ($estado === 'ABIERTO'): ?>
                    Inscripciones aceptadas: <?= $aceptadas ?>. Para iniciar hacen falta al menos dos.
                <?php elseif ($estado === 'EN CURSO'): ?>
                    La ronda se cierra con todos sus resultados cargados y validados.
                <?php elseif ($estado === 'CERRADO'): ?>
                    Torneo cerrado: no admite cambios. Al reabrirlo vuelve al estado que tenía.
                <?php endif; ?>
            </p>
        </section>

        <?php if ($editable): ?>
        <section class="seccion" id="organizadores">
            <div class="titulo-seccion">
                <h2>Organizadores</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Organizador</th><th>Correo</th><th>Estado</th><th>Acción</th></tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?= e($torneo['organizador']) ?></td>
                            <td></td>
                            <td>Creó el torneo</td>
                            <td></td>
                        </tr>
                        <?php foreach ($organizadores as $o): ?>
                        <tr>
                            <td><?= e($o['nombre']) ?></td>
                            <td><?= e($o['correo']) ?></td>
                            <td><?= e($o['estado']) ?></td>
                            <td>
                                <?php if ($o['estado_codigo'] === 'PENDIENTE' && $estado !== 'CERRADO'): ?>
                                <?php foreach (['ACEPTADA' => 'Aceptar', 'RECHAZADA' => 'Rechazar'] as $codigo => $texto): ?>
                                <form class="form-linea" action="index.php?ruta=gestion/organizador" method="POST">
                                    <?= $ocultos ?>
                                    <input type="hidden" name="usuario" value="<?= (int) $o['id_usuario'] ?>">
                                    <input type="hidden" name="estado" value="<?= $codigo ?>">
                                    <button type="submit" class="boton-borde"><?= $texto ?></button>
                                </form>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="seccion" id="datos">
            <div class="titulo-seccion">
                <h2>Datos y configuración</h2>
            </div>
            <form class="formulario" id="form-torneo" action="index.php?ruta=gestion/modificar" method="POST" novalidate>
                <?= $ocultos ?>
                <?php require __DIR__ . '/parciales/form-torneo.php'; ?>
                <button type="submit" class="boton">Guardar datos</button>
            </form>
        </section>
        <?php endif; ?>

        <section class="seccion" id="inscripciones">
            <div class="titulo-seccion">
                <h2>Inscripciones (<?= count($inscripciones) ?>)</h2>
            </div>
            <?php if (count($pedidosEquipos) > 0): ?>
            <h3 class="titulo-ronda" id="pedidos-equipos">Equipos que pidieron la inscripción (<?= count($pedidosEquipos) ?>)</h3>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Equipo</th><th>Pedido por</th><th>Desde</th><th>Resolver</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pedidosEquipos as $g): ?>
                        <tr>
                            <td><?= e($g['equipo']) ?></td>
                            <td><?= e(implode(', ', $g['solicitantes'])) ?></td>
                            <td><?= fecha_corta($g['desde']) ?></td>
                            <td>
                                <form class="form-linea" action="index.php?ruta=gestion/equipo" method="POST">
                                    <?= $ocultos ?>
                                    <input type="hidden" name="ids" value="<?= e(implode(',', $g['ids'])) ?>">
                                    <button type="submit" name="accion" value="APROBAR" class="boton">Inscribir</button>
                                    <button type="submit" name="accion" value="RECHAZAR" class="boton-borde">Rechazar</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
            <?php if ($estado === 'ABIERTO'): ?>
            <form class="formulario" action="index.php?ruta=gestion/inscribir" method="POST">
                <?= $ocultos ?>
                <label>Participante o equipo
                    <select name="participante" required>
                        <option value="">Elegir de la lista</option>
                        <?php foreach ($participantes as $p): ?>
                        <option value="<?= (int) $p['id'] ?>"><?= e($p['nombre']) ?><?= $p['alias'] ? ' (' . e($p['alias']) . ')' : '' ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <button type="submit" class="boton">Inscribir</button>
                <p class="ayuda-campo"><?php if ($esAdministrador): ?>Los participantes se dan de alta en <a class="enlace" href="index.php?ruta=participantes">Personas</a>.<?php else: ?>Los participantes nuevos los da de alta el administrador.<?php endif; ?></p>
            </form>
            <?php endif; ?>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Participante</th><th>Fecha</th><th>Estado</th><th>Acción</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($inscripciones as $i): ?>
                        <tr>
                            <td><?= e($i['participante']) ?></td>
                            <td><?= fecha_corta($i['fecha']) ?></td>
                            <td><?= e($i['estado']) ?></td>
                            <td>
                                <?php if ($estado === 'ABIERTO'): ?>
                                <div class="acciones">
                                    <?php foreach (['ACEPTADA' => 'Aceptar', 'RECHAZADA' => 'Rechazar'] as $codigo => $texto): ?>
                                    <?php if ($i['estado_codigo'] === $codigo) { continue; } ?>
                                    <form class="form-linea" action="index.php?ruta=gestion/inscripcion" method="POST">
                                        <?= $ocultos ?>
                                        <input type="hidden" name="inscripcion" value="<?= (int) $i['id'] ?>">
                                        <input type="hidden" name="estado" value="<?= $codigo ?>">
                                        <button type="submit" class="boton-borde"><?= $texto ?></button>
                                    </form>
                                    <?php endforeach; ?>
                                </div>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($inscripciones) === 0): ?>
                        <tr><td colspan="4" class="celda-vacia">Sin inscripciones.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <?php if (count($rondas) > 0): ?>
        <section class="seccion" id="rondas">
            <div class="titulo-seccion">
                <h2>Rondas y resultados</h2>
            </div>
            <?php foreach ($rondas as $ronda): ?>
            <?php $enCurso = $ronda['estado_codigo'] === 'EN CURSO' && $estado === 'EN CURSO'; ?>
            <h3 class="titulo-ronda">
                Ronda <?= (int) $ronda['numero'] ?> · <?= fecha_corta($ronda['fecha']) ?>
                <span class="estado estado-<?= e(strtolower(str_replace(' ', '-', $ronda['estado_codigo']))) ?>"><?= e($ronda['estado']) ?></span>
            </h3>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Hora</th><th>Local</th><th>Visitante</th><th>Resultado</th><th>Situación</th><th>Acción</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ronda['partidos'] as $partido): ?>
                        <?php
                        $conResultado = $partido['ganador'] !== null;
                        $validado     = (int) ($partido['validado'] ?? 0) === 1;
                        ?>
                        <tr>
                            <td><?= hora_corta($partido['fecha_hora']) ?></td>
                            <td><?= e($partido['local']) ?></td>
                            <td><?= e($partido['visitante']) ?></td>
                            <td>
                                <?php if ($enCurso && (!$validado || $esAdministrador)): ?>
                                <form class="form-linea form-resultado" action="index.php?ruta=gestion/resultado" method="POST">
                                    <?= $ocultos ?>
                                    <input type="hidden" name="partido" value="<?= (int) $partido['id'] ?>">
                                    <input class="campo campo-corto" type="number" name="local" min="0" max="999" value="<?= $conResultado ? (int) $partido['puntos_local'] : '' ?>" aria-label="Puntos de <?= e($partido['local']) ?>" required>
                                    <span>-</span>
                                    <input class="campo campo-corto" type="number" name="visitante" min="0" max="999" value="<?= $conResultado ? (int) $partido['puntos_visitante'] : '' ?>" aria-label="Puntos de <?= e($partido['visitante']) ?>" required>
                                    <button type="submit" class="boton-borde"><?= $conResultado ? 'Corregir' : 'Guardar' ?></button>
                                </form>
                                <?php elseif ($conResultado): ?>
                                    <strong><?= (int) $partido['puntos_local'] ?> - <?= (int) $partido['puntos_visitante'] ?></strong>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                            <td><?= $validado ? 'Validado' : ($conResultado ? 'Sin validar' : 'Sin resultado') ?></td>
                            <td>
                                <?php if ($enCurso && $conResultado && !$validado): ?>
                                <form class="form-linea" action="index.php?ruta=gestion/validar" method="POST">
                                    <?= $ocultos ?>
                                    <input type="hidden" name="partido" value="<?= (int) $partido['id'] ?>">
                                    <button type="submit" class="boton">Validar</button>
                                </form>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($ronda['partidos']) === 0): ?>
                        <tr><td colspan="6" class="celda-vacia">Ronda sin partidos.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php endforeach; ?>
        </section>

        <section class="seccion" id="reporte">
            <div class="titulo-seccion">
                <h2>Posiciones</h2>
            </div>
            <?php require __DIR__ . '/parciales/posiciones.php'; ?>
        </section>
        <?php endif; ?>

<?php
$scripts = ['js/validaciones.js'];
require __DIR__ . '/parciales/pie.php';
