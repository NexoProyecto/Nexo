<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Parcial: inicio del documento y menú. Recibe $titulo y $activo (ruta del menú que se resalta)
require_once __DIR__ . '/funciones.php';

$rolDeSesion = $_SESSION['usuario']['rol'] ?? '';

$enlaces = [
    ['inicio', '⌂', 'Inicio'],
    ['torneos', '♛', 'Torneos'],
    ['calendario', '▦', 'Calendario'],
];

if ($rolDeSesion === 'Administrador general') {
    $enlaces[] = ['admin', '⚙︎', 'Admin'];
    $enlaces[] = ['organizador', '✎', 'Gestión'];
    $enlaces[] = ['participantes', '☻', 'Personas'];
} elseif ($rolDeSesion === 'Organizador de torneo') {
    $enlaces[] = ['organizador', '✎', 'Gestión'];
} elseif ($rolDeSesion === 'Participante') {
    $enlaces[] = ['participante', '★', 'Mi panel'];
    $enlaces[] = ['mis-equipos', '⚑', 'Mis equipos'];
}

if ($rolDeSesion === '') {
    $enlaces[] = ['login', '⇥', 'Ingresar'];
} else {
    $enlaces[] = ['clave', '⚿', 'Contraseña'];
    $enlaces[] = ['salir', '⇤', 'Salir'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CupCore | <?= e($titulo) ?></title>
    <link rel="icon" type="image/png" href="img/favicon.png">
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/validaciones.css">
    <link rel="stylesheet" href="css/gestion.css">
    <link rel="stylesheet" href="css/tema.css">
</head>
<body>

    <nav class="menu">
        <div class="logo"><img src="img/logo.png" alt="Logo de CupCore" class="logo-img"> CupCore</div>
        <ul>
            <?php foreach ($enlaces as [$ruta, $icono, $texto]): ?>
            <li><a href="index.php?ruta=<?= $ruta ?>"<?= $ruta === $activo ? ' class="activo"' : '' ?>><span class="icono"><?= $icono ?></span> <?= $texto ?></a></li>
            <?php endforeach; ?>
        </ul>
    </nav>

    <main>
