<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Vista: gestión de participantes y equipos ($participantes, $equipos, $equipo, $integrantes, $solicitudes, $tokenCsrf, $aviso)
$titulo = 'Participantes y equipos';
$activo = 'participantes';
require __DIR__ . '/parciales/cabecera.php';

$token = '<input type="hidden" name="tokenCsrf" value="' . e($tokenCsrf) . '">';
$pendientes = count($solicitudes['INTEGRAR']) + count($solicitudes['INSCRIBIR']);
?>
        <header class="encabezado">
            <h1>Participantes y equipos</h1>
            <p>Personas y equipos que se inscriben en los torneos, y los pedidos de los participantes sobre sus equipos.</p>
        </header>

        <?php if (!empty($aviso)): ?>
            <div class="aviso-rol" id="aviso"><?= e($aviso) ?></div>
        <?php endif; ?>

        <section class="seccion" id="solicitudes">
            <div class="titulo-seccion">
                <h2>Solicitudes de equipos (<?= $pendientes ?>)</h2>
            </div>
            <?php if ($pendientes === 0): ?>
                <p class="texto-vacio">No hay solicitudes pendientes.</p>
            <?php endif; ?>

            <?php if (count($solicitudes['INTEGRAR']) > 0): ?>
            <h3 class="titulo-ronda">Para integrar un equipo</h3>
            <p class="ayuda-campo">Los pedidos iguales aparecen en una sola fila y se resuelven juntos. Para unir pedidos de equipos nuevos con nombres distintos: marcarlos en «Unir», escribir el nombre válido abajo y aprobar.</p>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Unir</th><th>Equipo</th><th>Pedido por</th><th>Desde</th><th>Resolver</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($solicitudes['INTEGRAR'] as $g): ?>
                        <?php $ids = implode(',', $g['ids']); ?>
                        <tr>
                            <td>
                                <input type="checkbox" name="ids[]" value="<?= e($ids) ?>" form="form-unir"
                                       aria-label="Unir este pedido">
                            </td>
                            <td><?= $g['id_equipo'] !== null ? e($g['equipo']) : 'Nuevo: ' . e(implode(' / ', $g['nombres'])) ?></td>
                            <td><?= e(implode(', ', $g['solicitantes'])) ?></td>
                            <td><?= fecha_corta($g['desde']) ?></td>
                            <td>
                                <form class="form-linea" action="index.php?ruta=equipos/solicitudes" method="POST">
                                    <?= $token ?>
                                    <input type="hidden" name="ids[]" value="<?= e($ids) ?>">
                                    <?php if ($g['id_equipo'] === null): ?>
                                    <input class="campo" type="text" name="nombre" minlength="2" maxlength="80"
                                           value="<?= e($g['nombres'][0]) ?>" aria-label="Nombre validado del equipo">
                                    <label class="casilla">
                                        <input type="checkbox" name="publico" value="1" checked> Público
                                    </label>
                                    <?php endif; ?>
                                    <button type="submit" name="accion" value="APROBAR" class="boton">Aprobar</button>
                                    <button type="submit" name="accion" value="RECHAZAR" class="boton-borde">Rechazar</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <form class="form-linea" id="form-unir" action="index.php?ruta=equipos/solicitudes" method="POST">
                <?= $token ?>
                <input class="campo" type="text" name="nombre" minlength="2" maxlength="80" required
                       placeholder="Nombre del equipo" aria-label="Nombre del equipo para los pedidos marcados">
                <label class="casilla">
                    <input type="checkbox" name="publico" value="1" checked> Público
                </label>
                <button type="submit" name="accion" value="APROBAR" class="boton">Aprobar las marcadas en un equipo</button>
            </form>
            <?php endif; ?>

            <?php if (count($solicitudes['INSCRIBIR']) > 0): ?>
            <h3 class="titulo-ronda">Para inscribir un equipo en un torneo</h3>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Equipo</th><th>Torneo</th><th>Pedido por</th><th>Desde</th><th>Resolver</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($solicitudes['INSCRIBIR'] as $g): ?>
                        <tr>
                            <td><?= e($g['equipo']) ?></td>
                            <td><?= e($g['torneo']) ?></td>
                            <td><?= e(implode(', ', $g['solicitantes'])) ?></td>
                            <td><?= fecha_corta($g['desde']) ?></td>
                            <td>
                                <form class="form-linea" action="index.php?ruta=equipos/solicitudes" method="POST">
                                    <?= $token ?>
                                    <input type="hidden" name="ids[]" value="<?= e(implode(',', $g['ids'])) ?>">
                                    <button type="submit" name="accion" value="APROBAR" class="boton">Inscribir</button>
                                    <button type="submit" name="accion" value="RECHAZAR" class="boton-borde">Rechazar</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </section>

        <section class="seccion" id="equipos">
            <div class="titulo-seccion">
                <h2>Equipos (<?= count($equipos) ?>)</h2>
                <a href="#nuevo-equipo">+ Nuevo equipo</a>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Equipo</th><th>Perfil</th><th>Integrantes</th><th>Torneos</th><th>Creado</th><th>Acción</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($equipos as $eq): ?>
                        <tr>
                            <td><?= e($eq['nombre']) ?></td>
                            <td><?= (int) $eq['perfil_publico'] === 1 ? 'Público' : 'Privado' ?></td>
                            <td><?= (int) $eq['integrantes'] ?></td>
                            <td><?= (int) $eq['torneos'] ?></td>
                            <td><?= fecha_corta($eq['fecha_creacion']) ?></td>
                            <td><a class="boton-borde" href="index.php?ruta=participantes&amp;equipo=<?= (int) $eq['id'] ?>#equipo">Abrir</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <?php if ($equipo !== null): ?>
        <section class="seccion" id="equipo">
            <div class="titulo-seccion">
                <h2>Equipo: <?= e($equipo['nombre']) ?></h2>
            </div>
            <form class="formulario" action="index.php?ruta=equipos/modificar" method="POST">
                <?= $token ?>
                <input type="hidden" name="id" value="<?= (int) $equipo['id'] ?>">
                <label>Nombre del equipo
                    <input type="text" name="nombre" minlength="2" maxlength="80" value="<?= e($equipo['nombre']) ?>" required>
                </label>
                <label class="casilla">
                    <input type="checkbox" name="publico" value="1" <?= (int) $equipo['perfil_publico'] === 1 ? 'checked' : '' ?>>
                    Perfil público
                </label>
                <button type="submit" class="boton">Guardar equipo</button>
            </form>

            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Integrante</th><th>Alias</th><th>Ingreso</th><th>Acción</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($integrantes as $i): ?>
                        <tr>
                            <td><?= e($i['nombre']) ?></td>
                            <td><?= e($i['alias'] ?? '—') ?></td>
                            <td><?= fecha_corta($i['fecha_ingreso']) ?></td>
                            <td>
                                <form class="form-linea" action="index.php?ruta=equipos/quitar" method="POST">
                                    <?= $token ?>
                                    <input type="hidden" name="equipo" value="<?= (int) $equipo['id'] ?>">
                                    <input type="hidden" name="participante" value="<?= (int) $i['id'] ?>">
                                    <button type="submit" class="boton-borde">Quitar</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($integrantes) === 0): ?>
                        <tr><td colspan="4" class="celda-vacia">Equipo sin integrantes.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="acciones">
                <form class="form-linea" action="index.php?ruta=equipos/integrante" method="POST">
                    <?= $token ?>
                    <input type="hidden" name="equipo" value="<?= (int) $equipo['id'] ?>">
                    <select class="campo" name="participante" aria-label="Participante que se agrega" required>
                        <option value="">Elegir participante</option>
                        <?php foreach ($participantes as $p): ?>
                        <option value="<?= (int) $p['id'] ?>"><?= e($p['nombre']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="boton">Agregar integrante</button>
                </form>
                <form class="form-linea" action="index.php?ruta=equipos/eliminar" method="POST"
                      data-confirmar="¿Eliminar el equipo <?= e($equipo['nombre']) ?>?"
                      data-aviso="Esta acción no se puede deshacer." data-boton="Eliminar">
                    <?= $token ?>
                    <input type="hidden" name="id" value="<?= (int) $equipo['id'] ?>">
                    <button type="submit" class="boton-borde">Eliminar equipo</button>
                </form>
            </div>
        </section>
        <?php endif; ?>

        <section class="seccion" id="nuevo-equipo">
            <div class="titulo-seccion">
                <h2>Nuevo equipo</h2>
            </div>
            <form class="formulario" action="index.php?ruta=equipos/crear" method="POST">
                <?= $token ?>
                <label>Nombre del equipo
                    <input type="text" name="nombre" minlength="2" maxlength="80" placeholder="Ej: Los Halcones" required>
                </label>
                <label class="casilla">
                    <input type="checkbox" name="publico" value="1" checked>
                    Perfil público
                </label>
                <button type="submit" class="boton">Crear equipo</button>
                <p class="ayuda-campo">El equipo se inscribe en los torneos con su propio nombre; los integrantes se agregan después de crearlo.</p>
            </form>
        </section>

        <section class="seccion" id="participantes">
            <div class="titulo-seccion">
                <h2>Participantes (<?= count($participantes) ?>)</h2>
                <a href="#nuevo-participante">+ Nuevo participante</a>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Nombre, alias, nacimiento y perfil</th><th>Cuenta</th><th>Torneos</th><th>Baja</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($participantes as $p): ?>
                        <tr>
                            <td>
                                <form class="form-linea" action="index.php?ruta=participantes/modificar" method="POST">
                                    <?= $token ?>
                                    <input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                                    <input class="campo" type="text" name="nombre" minlength="2" maxlength="80" value="<?= e($p['nombre']) ?>" aria-label="Nombre" required>
                                    <input class="campo campo-medio" type="text" name="alias" maxlength="40" value="<?= e($p['alias']) ?>" placeholder="Alias" aria-label="Alias">
                                    <input class="campo" type="date" name="nacimiento" value="<?= e($p['fecha_nacimiento']) ?>" aria-label="Fecha de nacimiento">
                                    <label class="casilla">
                                        <input type="checkbox" name="publico" value="1" <?= (int) $p['perfil_publico'] === 1 ? 'checked' : '' ?>>
                                        Público
                                    </label>
                                    <button type="submit" class="boton-borde">Guardar</button>
                                </form>
                            </td>
                            <td><?= e($p['correo'] ?? '—') ?></td>
                            <td><?= (int) $p['inscripciones'] ?></td>
                            <td>
                                <form class="form-baja" action="index.php?ruta=participantes/eliminar" method="POST"
                                      data-confirmar="¿Eliminar a <?= e($p['nombre']) ?>?"
                                      data-aviso="<?= $p['correo'] ? 'También se da de baja su cuenta (' . e($p['correo']) . '): ya no puede ingresar. ' : '' ?>Esta acción no se puede deshacer." data-boton="Eliminar">
                                    <?= $token ?>
                                    <input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                                    <button type="submit" class="boton-borde">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="seccion" id="nuevo-participante">
            <div class="titulo-seccion">
                <h2>Nuevo participante</h2>
            </div>
            <form class="formulario" id="form-participante" action="index.php?ruta=participantes/crear" method="POST" novalidate>
                <?= $token ?>
                <label>Nombre del participante
                    <input type="text" name="nombre" minlength="2" maxlength="80" placeholder="Ej: Camila Pérez" required>
                </label>
                <span class="mensaje-error" id="error-nombre"></span>
                <label>Alias (opcional)
                    <input type="text" name="alias" maxlength="40" placeholder="Ej: Cami">
                </label>
                <label>Fecha de nacimiento (opcional)
                    <input type="date" name="nacimiento">
                </label>
                <label class="casilla">
                    <input type="checkbox" name="publico" value="1">
                    Perfil público
                </label>
                <button type="submit" class="boton">Crear participante</button>
            </form>
        </section>

<?php
$scripts = ['js/validaciones.js'];
require __DIR__ . '/parciales/pie.php';
