<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Vista: panel del organizador ($torneos, $tipos, $paraUnirse, $reaperturas, $tokenCsrf, $aviso)
$titulo = 'Gestión de torneos';
$activo = 'organizador';
require __DIR__ . '/parciales/cabecera.php';

$esAdmin = $_SESSION['usuario']['rol'] === 'Administrador general';
?>
        <header class="encabezado">
            <h1>Gestión de torneos</h1>
            <p><?= $esAdmin ? 'Alta de torneos, organizadores, inscripciones, rondas y resultados.' : 'Solicitud de torneos y gestión de los torneos a cargo: organizadores, inscripciones, rondas y resultados.' ?></p>
        </header>

        <div class="aviso-rol">
            Sesión iniciada como: <strong><?= e($_SESSION['usuario']['nombre']) ?></strong>
            (<?= e($_SESSION['usuario']['rol']) ?>)
        </div>

        <?php if (!empty($aviso)): ?>
            <div class="aviso-rol" id="aviso"><?= e($aviso) ?></div>
        <?php endif; ?>

        <section class="seccion" id="mis-torneos">
            <div class="titulo-seccion">
                <h2>Torneos a cargo (<?= count($torneos) ?>)</h2>
                <a href="#nuevo-torneo"><?= $esAdmin ? '+ Nuevo torneo' : '+ Solicitar torneo' ?></a>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Torneo</th><th>Módulo</th><th>Estado</th><th>Inicio</th><th>Inscriptos</th><th>Organizador</th><th>Acción</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($torneos as $t): ?>
                        <tr>
                            <td><?= e($t['nombre']) ?></td>
                            <td><?= e($t['modulo']) ?></td>
                            <td><?= e($t['estado']) ?></td>
                            <td><?= fecha_corta($t['fecha_inicio']) ?></td>
                            <td><?= (int) $t['inscriptos'] ?></td>
                            <td><?= e($t['organizador']) ?></td>
                            <td>
                                <?php if ($t['estado_codigo'] === 'SOLICITADO' && !$esAdmin): ?>
                                    Esperando la aprobación del administrador
                                <?php elseif ($t['estado_codigo'] === 'RECHAZADO' && !$esAdmin): ?>
                                    Rechazado por el administrador
                                <?php elseif ($t['estado_codigo'] === 'CERRADO' && !$esAdmin): ?>
                                    <?php if (isset($reaperturas[$t['id']])): ?>
                                        Cerrado · reapertura pedida
                                    <?php else: ?>
                                    <form class="form-linea" action="index.php?ruta=organizador/reapertura" method="POST">
                                        <input type="hidden" name="tokenCsrf" value="<?= e($tokenCsrf) ?>">
                                        <input type="hidden" name="torneo" value="<?= (int) $t['id'] ?>">
                                        <input type="text" name="motivo" minlength="5" maxlength="300" placeholder="Motivo" aria-label="Motivo de la reapertura" required>
                                        <button type="submit" class="boton-borde">Pedir reapertura</button>
                                    </form>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a class="boton-borde" href="index.php?ruta=gestion&amp;id=<?= (int) $t['id'] ?>">Gestionar</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($torneos) === 0): ?>
                        <tr><td colspan="7" class="celda-vacia">Sin torneos a cargo.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <?php if (!empty($paraUnirse)): ?>
        <section class="seccion" id="unirse">
            <div class="titulo-seccion">
                <h2>Sumarse como organizador (<?= count($paraUnirse) ?>)</h2>
            </div>
            <p class="ayuda-campo">Torneos publicados de otros organizadores. El pedido lo acepta o lo rechaza un organizador del torneo.</p>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Torneo</th><th>Estado</th><th>Inicio</th><th>Organizador</th><th>Pedido</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($paraUnirse as $t): ?>
                        <tr>
                            <td><?= e($t['nombre']) ?></td>
                            <td><?= e($t['estado']) ?></td>
                            <td><?= fecha_corta($t['fecha_inicio']) ?></td>
                            <td><?= e($t['organizador']) ?></td>
                            <td>
                                <?php if ($t['pedido'] === 'PENDIENTE'): ?>
                                    Pendiente
                                <?php else: ?>
                                <form class="form-linea" action="index.php?ruta=organizador/unirse" method="POST">
                                    <input type="hidden" name="tokenCsrf" value="<?= e($tokenCsrf) ?>">
                                    <input type="hidden" name="torneo" value="<?= (int) $t['id'] ?>">
                                    <button type="submit" class="boton-borde"><?= $t['pedido'] === 'RECHAZADA' ? 'Rechazado · pedir de nuevo' : 'Pedir sumarme' ?></button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
        <?php endif; ?>

        <section class="seccion" id="nuevo-torneo">
            <div class="titulo-seccion">
                <h2><?= $esAdmin ? 'Nuevo torneo' : 'Solicitar un torneo' ?></h2>
            </div>
            <form class="formulario" id="form-torneo" action="index.php?ruta=organizador/crear" method="POST" novalidate>
                <input type="hidden" name="tokenCsrf" value="<?= e($tokenCsrf) ?>">
                <?php require __DIR__ . '/parciales/form-torneo.php'; ?>
                <?php if ($esAdmin): ?>
                <p class="ayuda-campo">El torneo se crea en borrador. Al publicarlo figura en la consulta pública y se abren las inscripciones.</p>
                <button type="submit" class="boton">Crear torneo</button>
                <?php else: ?>
                <p class="ayuda-campo">El administrador revisa la solicitud desde su panel. Si la acepta, el torneo queda en borrador y a cargo de quien lo pidió; al publicarlo se abren las inscripciones.</p>
                <button type="submit" class="boton">Solicitar torneo</button>
                <?php endif; ?>
            </form>
        </section>

<?php
$scripts = ['js/validaciones.js'];
require __DIR__ . '/parciales/pie.php';
