<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Vista: error no previsto ($sinServicio). No depende de la base ni de la sesión
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CupCore | Error</title>
    <link rel="icon" type="image/png" href="img/favicon.png">
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/validaciones.css">
</head>
<body>
    <main>
        <header class="encabezado">
            <h1>No se pudo completar la operación</h1>
            <?php if (!empty($sinServicio)): ?>
                <p>La base de datos no responde. Volver a intentar en unos minutos.</p>
            <?php else: ?>
                <p>Ocurrió un error inesperado. Volver al inicio e intentar de nuevo.</p>
            <?php endif; ?>
        </header>
        <div class="aviso-rol aviso-error">
            Si el problema continúa, avisar al administrador del sistema.
        </div>
        <section class="seccion">
            <a href="index.php?ruta=inicio" class="boton">Volver al inicio</a>
        </section>
    </main>
</body>
</html>
