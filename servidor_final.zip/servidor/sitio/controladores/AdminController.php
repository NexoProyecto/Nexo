<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../modelos/GestorUsuarios.php';
require_once __DIR__ . '/../modelos/GestorAuditoria.php';
require_once __DIR__ . '/../modelos/GestorTorneos.php';
require_once __DIR__ . '/../modelos/GestorSolicitudes.php';
require_once __DIR__ . '/../modelos/GestorReaperturas.php';

/** Panel del administrador general: solicitudes de cuenta y de torneo, torneos en curso y cerrados, usuarios, reporte y auditoría */
class AdminController extends ControladorBase
{
    private const ROLES = ['Administrador general', 'Organizador de torneo', 'Participante'];

    public function index(): void
    {
        $this->requiereRol('Administrador general');

        $gestor      = new GestorUsuarios();
        $solicitudes = new GestorSolicitudes();
        $torneos     = new GestorTorneos();

        $this->renderizarVista('admin', [
            'usuario'     => $_SESSION['usuario'],
            'solicitudes' => $solicitudes->listarPendientes(),
            'resueltas'   => $solicitudes->listarResueltas(10),
            'solicitados' => $torneos->listarSolicitados(),
            'enCurso'     => $torneos->listarEnCurso(),
            'cerrados'    => $torneos->listarCerrados(),
            'reaperturas' => (new GestorReaperturas())->pendientesPorTorneo(),
            'usuarios'    => $gestor->listarUsuarios(),
            'roles'     => self::ROLES,
            'reporte'   => $torneos->reporte(),
            'auditoria' => (new GestorAuditoria())->ultimas(50),
            'tokenCsrf' => SesionSegura::tokenCsrf(),
            'aviso'     => $_SESSION['aviso'] ?? '',
        ]);
        unset($_SESSION['aviso']);
    }

    /** Alta (POST) */
    public function crearUsuario(): void
    {
        $this->requiereRol('Administrador general');

        if (!SesionSegura::tokenCsrfValido($_POST['tokenCsrf'] ?? null)) {
            $_SESSION['aviso'] = 'La página expiró. Recargar e intentar de nuevo.';
            $this->redirigir('admin');
        }

        $validador  = new Validador();
        $nombre     = $validador->nombrePersona('nombre', $_POST['nombre'] ?? '', 2, 60);
        $correo     = $validador->email('correo', $_POST['correo'] ?? '');
        $contrasena = $validador->clave('contrasena', $_POST['contrasena'] ?? '');
        $rol        = $validador->opcion('rol', $_POST['rol'] ?? 'Participante', self::ROLES);

        if ($validador->hayErrores()) {
            $_SESSION['aviso'] = 'No se pudo crear el usuario: '
                . implode(' ', $validador->errores());
            $this->redirigir('admin');
        }

        $gestor = new GestorUsuarios();
        $creado = $gestor->crearUsuario($nombre, $correo, $contrasena, $rol);

        if ($creado) {
            $this->auditar('ALTA', 'Usuario');
        }

        $_SESSION['aviso'] = $creado
            ? 'Usuario creado. La contraseña es provisional: el sistema pide cambiarla en el primer ingreso.'
            : 'No se pudo crear el usuario: el correo ya está registrado.';

        $this->redirigir('admin');
    }

    /** Baja (POST) */
    public function eliminarUsuario(): void
    {
        $this->requiereRol('Administrador general');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST'
            || !SesionSegura::tokenCsrfValido($_POST['tokenCsrf'] ?? null)) {
            $_SESSION['aviso'] = 'Acción no autorizada.';
            $this->redirigir('admin');
        }

        $validador = new Validador();
        $id = $validador->entero('id', $_POST['id'] ?? '');

        if ($id === null) {
            $_SESSION['aviso'] = 'El identificador del usuario no es válido.';
            $this->redirigir('admin');
        }

        // Cuenta en uso
        if ((string) $id === (string) $_SESSION['usuario']['id']) {
            $_SESSION['aviso'] = 'La cuenta en uso no se puede dar de baja.';
            $this->redirigir('admin');
        }

        $gestor = new GestorUsuarios();
        $gestor->eliminarUsuario((string) $id);
        $this->auditar('BAJA', 'Usuario');
        $_SESSION['aviso'] = 'Usuario dado de baja.';

        $this->redirigir('admin');
    }

    /** Cambio de rol y de estado (POST) */
    public function modificarUsuario(): void
    {
        $this->requiereRol(self::ADMINISTRADOR);
        $this->exigirFormulario('admin');

        $validador = new Validador();
        $id     = $validador->entero('id', $_POST['id'] ?? '');
        $rol    = $validador->opcion('rol', $_POST['rol'] ?? '', self::ROLES);
        $estado = $validador->opcion('estado', $_POST['estado'] ?? '', ['Activo', 'Inactivo']);

        if ($validador->hayErrores()) {
            $this->avisar('No se pudo modificar el usuario: ' . self::textoDeErrores($validador));
            $this->redirigir('admin');
        }

        // La cuenta en uso conserva su rol y su estado: el sistema no queda sin administrador
        if ($id === $this->idUsuario()) {
            $this->avisar('La cuenta en uso no cambia su propio rol ni su estado.');
            $this->redirigir('admin');
        }

        if ((new GestorUsuarios())->modificarUsuario((string) $id, $rol, $estado)) {
            $this->auditar('MODIFICACION', 'Usuario');
            $this->avisar('Usuario modificado.');
        } else {
            $this->avisar('El usuario no existe.');
        }

        $this->redirigir('admin');
    }

    /** Alta de la cuenta pedida, con el rol tentativo o el que elige el administrador (POST) */
    public function aprobarSolicitud(): void
    {
        $this->requiereRol(self::ADMINISTRADOR);
        $this->exigirFormulario('admin');

        $validador = new Validador();
        $id  = $validador->entero('solicitud', $_POST['solicitud'] ?? '');
        $rol = $validador->opcion('rol', $_POST['rol'] ?? '', self::ROLES);

        if ($validador->hayErrores()) {
            $this->avisar('No se aprobó la solicitud: ' . self::textoDeErrores($validador));
            $this->redirigir('admin#solicitudes');
        }

        $idUsuario = (new GestorSolicitudes())->aprobar($id, $rol, $this->idUsuario());
        if ($idUsuario === null) {
            $this->avisar('No se aprobó: la solicitud ya está resuelta o el correo ya tiene una cuenta.');
            $this->redirigir('admin#solicitudes');
        }

        $this->auditar('ALTA', 'Usuario');
        $this->auditar('MODIFICACION', 'SolicitudCuenta');
        $this->avisar('Solicitud aprobada: cuenta creada con el rol ' . $rol . '.');
        $this->redirigir('admin#solicitudes');
    }

    public function rechazarSolicitud(): void
    {
        $this->requiereRol(self::ADMINISTRADOR);
        $this->exigirFormulario('admin');

        $id = (new Validador())->entero('solicitud', $_POST['solicitud'] ?? '');
        if ($id !== null && (new GestorSolicitudes())->rechazar($id, $this->idUsuario())) {
            $this->auditar('MODIFICACION', 'SolicitudCuenta');
            $this->avisar('Solicitud rechazada.');
        } else {
            $this->avisar('La solicitud no existe o ya está resuelta.');
        }

        $this->redirigir('admin#solicitudes');
    }

    /** Cierra un torneo en curso desde el panel (POST) */
    public function cerrarTorneo(): void
    {
        $this->requiereRol(self::ADMINISTRADOR);
        $this->exigirFormulario('admin');

        $id = (new Validador())->entero('torneo', $_POST['torneo'] ?? '');
        if ($id !== null && (new GestorTorneos())->cerrar($id)) {
            $this->auditar('MODIFICACION', 'Torneo');
            $this->avisar('Torneo cerrado. Figura entre los torneos cerrados.');
        } else {
            $this->avisar('El torneo no existe o no se puede cerrar.');
        }

        $this->redirigir('admin#cerrados');
    }

    /** Devuelve un torneo cerrado al estado que tenía y aprueba su pedido de reapertura (POST) */
    public function reabrirTorneo(): void
    {
        $this->requiereRol(self::ADMINISTRADOR);
        $this->exigirFormulario('admin');

        $id = (new Validador())->entero('torneo', $_POST['torneo'] ?? '');
        if ($id !== null && (new GestorReaperturas())->reabrir($id, $this->idUsuario())) {
            $this->auditar('MODIFICACION', 'Torneo');
            $this->avisar('Torneo reabierto: vuelve al estado que tenía al cerrarse.');
        } else {
            $this->avisar('El torneo no existe o no está cerrado.');
        }

        $this->redirigir('admin#cerrados');
    }

    /** Acepta un torneo solicitado por un organizador: queda en borrador, a su cargo (POST) */
    public function aprobarTorneo(): void
    {
        $this->resolverTorneo(true);
    }

    /** Rechaza un torneo solicitado por un organizador (POST) */
    public function rechazarTorneo(): void
    {
        $this->resolverTorneo(false);
    }

    private function resolverTorneo(bool $aprobar): void
    {
        $this->requiereRol(self::ADMINISTRADOR);
        $this->exigirFormulario('admin');

        $id = (new Validador())->entero('torneo', $_POST['torneo'] ?? '');
        if ($id !== null && (new GestorTorneos())->resolverSolicitud($id, $aprobar)) {
            $this->auditar('MODIFICACION', 'Torneo');
            $this->avisar($aprobar
                ? 'Torneo aceptado: queda en borrador y lo gestiona el organizador que lo pidió.'
                : 'Solicitud de torneo rechazada.');
        } else {
            $this->avisar('El torneo no existe o ya no está solicitado.');
        }

        $this->redirigir('admin#torneos-solicitados');
    }

    /** Rechaza el pedido de reapertura: el torneo sigue cerrado (POST) */
    public function rechazarReapertura(): void
    {
        $this->requiereRol(self::ADMINISTRADOR);
        $this->exigirFormulario('admin');

        $id = (new Validador())->entero('torneo', $_POST['torneo'] ?? '');
        if ($id !== null && (new GestorReaperturas())->rechazar($id, $this->idUsuario())) {
            $this->auditar('MODIFICACION', 'SolicitudReapertura');
            $this->avisar('Pedido de reapertura rechazado: el torneo sigue cerrado.');
        } else {
            $this->avisar('El torneo no tiene un pedido de reapertura pendiente.');
        }

        $this->redirigir('admin#cerrados');
    }
}
