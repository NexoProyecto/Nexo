<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../modelos/GestorTorneos.php';
require_once __DIR__ . '/../modelos/GestorOrganizadores.php';
require_once __DIR__ . '/../modelos/GestorReaperturas.php';

/** Panel del organizador: sus torneos, la solicitud de uno nuevo, los pedidos para sumarse a otros y los de reapertura. El administrador ve todos y crea torneos sin solicitud */
class OrganizadorController extends ControladorBase
{
    public function index(): void
    {
        $this->requiereAlguno([self::ORGANIZADOR, self::ADMINISTRADOR]);

        $gestor = new GestorTorneos();

        $this->renderizarVista('organizador', [
            'torneos'   => $gestor->listarDeOrganizador($this->esAdministrador() ? null : $this->idUsuario()),
            'tipos'     => $gestor->listarTipos(),
            'paraUnirse' => $this->esAdministrador() ? [] : (new GestorOrganizadores())->torneosParaUnirse($this->idUsuario()),
            'reaperturas' => (new GestorReaperturas())->pendientesPorTorneo(),
            'tokenCsrf' => SesionSegura::tokenCsrf(),
            'aviso'     => $this->tomarAviso(),
        ]);
    }

    /**
     * Alta de un torneo (POST). El administrador lo crea en borrador; el organizador lo
     * solicita y queda SOLICITADO hasta que el administrador lo acepta o lo rechaza
     */
    public function crearTorneo(): void
    {
        $this->requiereAlguno([self::ORGANIZADOR, self::ADMINISTRADOR]);
        $this->exigirFormulario('organizador');

        $administrador = $this->esAdministrador();
        $datos = self::datosDeTorneo(new GestorTorneos(), $errores);
        if ($datos === null) {
            $this->avisar(($administrador ? 'No se pudo crear el torneo: ' : 'No se envió la solicitud: ') . $errores);
            $this->redirigir('organizador');
        }

        $estado = $administrador ? 'BORRADOR' : 'SOLICITADO';
        $id = (new GestorTorneos())->crear(
            ...array_merge($datos, [$this->idUsuario(), $estado])
        );
        $this->auditar('ALTA', 'Torneo');

        if (!$administrador) {
            $this->avisar('Solicitud enviada. El administrador acepta o rechaza el torneo'
                . ' desde su panel.');
            $this->redirigir('organizador');
        }

        $this->avisar('Torneo creado en borrador. Al publicarlo se abren las inscripciones.');
        $this->redirigir('gestion&id=' . $id);
    }

    /** Pide sumarse como organizador a un torneo de otro organizador (POST) */
    public function solicitarUnirse(): void
    {
        $this->requiereRol(self::ORGANIZADOR);
        $this->exigirFormulario('organizador');

        $idTorneo = (new Validador())->entero('torneo', $_POST['torneo'] ?? '');
        if ($idTorneo !== null && (new GestorOrganizadores())->solicitar($idTorneo, $this->idUsuario())) {
            $this->auditar('ALTA', 'Organiza');
            $this->avisar('Pedido enviado. Un organizador del torneo lo acepta o lo rechaza.');
        } else {
            $this->avisar('No se envió: el torneo no admite pedidos o ya hay uno pendiente.');
        }

        $this->redirigir('organizador#unirse');
    }

    /** Pide al administrador reabrir un torneo cerrado del que es organizador (POST) */
    public function solicitarReapertura(): void
    {
        $this->requiereRol(self::ORGANIZADOR);
        $this->exigirFormulario('organizador');

        $validador = new Validador();
        $idTorneo  = $validador->entero('torneo', $_POST['torneo'] ?? '');
        $motivo    = $validador->texto('motivo', $_POST['motivo'] ?? '', 5, 300);

        if ($validador->hayErrores()) {
            $this->avisar('No se envió: falta el torneo o el motivo (entre 5 y 300 caracteres).');
            $this->redirigir('organizador');
        }

        if ((new GestorReaperturas())->solicitar($idTorneo, $this->idUsuario(), $motivo)) {
            $this->auditar('ALTA', 'SolicitudReapertura');
            $this->avisar('Pedido de reapertura enviado. El administrador lo resuelve desde su panel.');
        } else {
            $this->avisar('No se envió: el torneo no está cerrado, está a cargo de otro organizador o ya tiene un pedido pendiente.');
        }

        $this->redirigir('organizador');
    }

    /**
     * Valida los campos del formulario de torneo. Devuelve los argumentos de
     * GestorTorneos::crear() y modificar(), o null con el detalle en $errores.
     */
    public static function datosDeTorneo(GestorTorneos $gestor, ?string &$errores): ?array
    {
        $validador = new Validador();

        $nombre = $validador->texto('nombre', $_POST['nombre'] ?? '', 3, 100);
        $inicio = $validador->fecha('inicio', $_POST['inicio'] ?? '');
        $tipo   = $validador->opcion('tipo', $_POST['tipo'] ?? '',
                                     array_map('strval', array_column($gestor->listarTipos(), 'id')));
        $modulo = $validador->opcion('modulo', $_POST['modulo'] ?? '', GestorTorneos::MODULOS);

        $fin = trim((string) ($_POST['fin'] ?? ''));
        $fin = $fin === '' ? null : $validador->fecha('fin', $fin);

        $reglas = trim((string) ($_POST['reglas'] ?? ''));
        $reglas = $reglas === '' ? null : $validador->texto('reglas', $reglas, 1, 500);

        if (!$validador->hayErrores() && $fin !== null && $fin < $inicio) {
            $errores = 'La fecha de fin no puede ser anterior a la de inicio.';
            return null;
        }

        if ($validador->hayErrores()) {
            $errores = self::textoDeErrores($validador);
            return null;
        }

        return [$nombre, $inicio, $fin, (int) $tipo, $modulo, $reglas];
    }
}
