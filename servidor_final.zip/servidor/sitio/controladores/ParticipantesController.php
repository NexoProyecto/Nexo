<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../modelos/GestorParticipantes.php';
require_once __DIR__ . '/../modelos/GestorSolicitudesEquipo.php';
require_once __DIR__ . '/../modelos/GestorOrganizadores.php';

/**
 * Gestión de participantes, equipos y solicitudes de equipo: solo el administrador.
 * El organizador inscribe y resuelve los pedidos de inscripción desde la gestión de su torneo
 */
class ParticipantesController extends ControladorBase
{
    public function index(): void
    {
        $this->requiereRol(self::ADMINISTRADOR);

        $gestor  = new GestorParticipantes();
        $equipos = $gestor->listarEquipos();

        // Equipo abierto en pantalla, con sus integrantes
        $idEquipo = filter_var($_GET['equipo'] ?? '', FILTER_VALIDATE_INT);
        $equipo   = $idEquipo ? $gestor->obtenerEquipo($idEquipo) : null;

        $this->renderizarVista('participantes', [
            'participantes' => $gestor->listarParticipantes(),
            'equipos'       => $equipos,
            'equipo'        => $equipo,
            'integrantes'   => $equipo ? $gestor->listarIntegrantes($idEquipo) : [],
            'solicitudes'   => (new GestorSolicitudesEquipo())->pendientesAgrupados(null),
            'tokenCsrf'     => SesionSegura::tokenCsrf(),
            'aviso'         => $this->tomarAviso(),
        ]);
    }

    public function crear(): void
    {
        $this->formulario();

        $datos = $this->datosDeParticipante($errores);
        if ($datos === null) {
            $this->volver('No se pudo crear el participante: ' . $errores);
        }

        (new GestorParticipantes())->crearParticipante(...$datos);
        $this->auditar('ALTA', 'Participante');
        $this->volver('Participante creado.');
    }

    public function modificar(): void
    {
        $this->formulario();

        $id    = (new Validador())->entero('id', $_POST['id'] ?? '');
        $datos = $this->datosDeParticipante($errores);
        if ($id === null || $datos === null) {
            $this->volver('No se pudo guardar el participante: ' . ($errores ?? 'identificador no válido.'));
        }

        (new GestorParticipantes())->modificarParticipante($id, ...$datos);
        $this->auditar('MODIFICACION', 'Participante');
        $this->volver('Participante guardado.');
    }

    public function eliminar(): void
    {
        $this->formulario();

        $id        = (new Validador())->entero('id', $_POST['id'] ?? '');
        $resultado = $id === null ? 'no' : (new GestorParticipantes())->eliminarParticipante($id);

        if (in_array($resultado, ['cuenta', 'eliminado-cuenta'], true)) {
            $this->auditar('MODIFICACION', 'Usuario');
        }
        if (in_array($resultado, ['eliminado', 'eliminado-cuenta'], true)) {
            $this->auditar('BAJA', 'Participante');
        }

        $this->volver([
            'eliminado'        => 'Participante eliminado.',
            'eliminado-cuenta' => 'Participante eliminado y su cuenta dada de baja: ya no puede ingresar.',
            'cuenta'           => 'Cuenta dada de baja: ya no puede ingresar. El participante tiene inscripciones'
                                . ' en torneos y se conserva en los resultados.',
            'no'               => 'El participante tiene inscripciones en torneos y no se elimina.',
        ][$resultado]);
    }

    public function crearEquipo(): void
    {
        $this->formulario();

        $nombre = (new Validador())->texto('nombre', $_POST['nombre'] ?? '', 2, 80);
        if ($nombre === null) {
            $this->volver('El nombre del equipo lleva entre 2 y 80 caracteres, sin símbolos.');
        }

        if ((new GestorParticipantes())->crearEquipo($nombre, isset($_POST['publico']))) {
            $this->auditar('ALTA', 'Equipo');
            $this->volver('Equipo creado.');
        }

        $this->volver('Ya existe un equipo con ese nombre.');
    }

    public function modificarEquipo(): void
    {
        $this->formulario();

        $validador = new Validador();
        $id     = $validador->entero('id', $_POST['id'] ?? '');
        $nombre = $validador->texto('nombre', $_POST['nombre'] ?? '', 2, 80);
        if ($validador->hayErrores()) {
            $this->volver('No se pudo guardar el equipo: ' . self::textoDeErrores($validador));
        }

        if ((new GestorParticipantes())->modificarEquipo($id, $nombre, isset($_POST['publico']))) {
            $this->auditar('MODIFICACION', 'Equipo');
            $this->volver('Equipo guardado.', $id);
        }

        $this->volver('Ya existe un equipo con ese nombre.', $id);
    }

    public function eliminarEquipo(): void
    {
        $this->formulario();

        $id = (new Validador())->entero('id', $_POST['id'] ?? '');
        if ($id !== null) {
            (new GestorParticipantes())->eliminarEquipo($id);
            $this->auditar('BAJA', 'Equipo');
        }

        $this->volver('Equipo eliminado.');
    }

    public function agregarIntegrante(): void
    {
        $this->formulario();

        $validador    = new Validador();
        $equipo       = $validador->entero('equipo', $_POST['equipo'] ?? '');
        $participante = $validador->entero('participante', $_POST['participante'] ?? '');
        if ($validador->hayErrores()) {
            $this->volver('Hay que elegir un participante de la lista.', $equipo);
        }

        if ((new GestorParticipantes())->agregarIntegrante($equipo, $participante)) {
            $this->auditar('ALTA', 'Integra');
            $this->volver('Integrante agregado.', $equipo);
        }

        $this->volver('El participante ya integra el equipo.', $equipo);
    }

    public function quitarIntegrante(): void
    {
        $this->formulario();

        $validador    = new Validador();
        $equipo       = $validador->entero('equipo', $_POST['equipo'] ?? '');
        $participante = $validador->entero('participante', $_POST['participante'] ?? '');
        if (!$validador->hayErrores()) {
            (new GestorParticipantes())->quitarIntegrante($equipo, $participante);
            $this->auditar('BAJA', 'Integra');
        }

        $this->volver('Integrante quitado.', $equipo);
    }

    /**
     * Resuelve un grupo de solicitudes de equipo: aprobar o rechazar. Los pedidos para
     * integrar marcados juntos se aprueban en un mismo equipo, con el nombre validado
     */
    public function resolverSolicitudes(): void
    {
        $this->formulario();

        $validador = new Validador();
        $accion = $validador->opcion('accion', $_POST['accion'] ?? '', ['APROBAR', 'RECHAZAR']);
        $ids    = $_POST['ids'] ?? [];
        $ids    = is_array($ids) ? $ids : [];
        // Cada casilla trae los pedidos de su grupo, separados por coma
        $ids    = array_filter(array_map('intval', explode(',', implode(',', array_map('strval', $ids)))));

        $nombre = trim((string) ($_POST['nombre'] ?? ''));
        $nombre = $nombre === '' ? null : $validador->texto('nombre', $nombre, 2, 80);

        $gestor      = new GestorSolicitudesEquipo();
        $solicitudes = $validador->hayErrores() ? [] : $gestor->pendientesPorId($ids);
        if (count($solicitudes) === 0) {
            $this->volver('Hay que marcar al menos una solicitud pendiente. El nombre lleva entre 2 y 80 caracteres.');
        }

        $tipos = array_unique(array_column($solicitudes, 'tipo'));
        if (count($tipos) > 1) {
            $this->volver('Las solicitudes para integrar y las de inscripción se resuelven por separado.');
        }

        if ($tipos[0] === 'INSCRIBIR') {
            $this->resolverInscripciones($gestor, $solicitudes, $accion);
        }

        if ($accion === 'RECHAZAR') {
            $gestor->rechazar(array_column($solicitudes, 'id'), $this->idUsuario());
            $this->auditar('MODIFICACION', 'SolicitudEquipo');
            $this->volver(count($solicitudes) === 1 ? 'Solicitud rechazada.' : 'Solicitudes rechazadas.');
        }

        $idEquipo = $gestor->aprobarIntegrar($solicitudes, $nombre, isset($_POST['publico']), $this->idUsuario());
        if ($idEquipo === null) {
            $this->volver('Los pedidos son de equipos distintos: escribir el nombre del equipo en el que quedan.');
        }

        $this->auditar('MODIFICACION', 'SolicitudEquipo');
        $this->auditar('ALTA', 'Integra');
        $this->volver('Solicitudes aprobadas: los participantes integran el equipo.', $idEquipo);
    }

    /** Pedidos de inscripción del mismo equipo en el mismo torneo, que el usuario organiza */
    private function resolverInscripciones(GestorSolicitudesEquipo $gestor, array $solicitudes, string $accion): void
    {
        $claves = array_unique(array_map(fn ($s) => $s['id_equipo'] . '-' . $s['id_torneo'], $solicitudes));
        if (count($claves) > 1) {
            $this->volver('Solo se resuelven juntos los pedidos del mismo equipo para el mismo torneo.');
        }

        $idTorneo = (int) $solicitudes[0]['id_torneo'];
        if (!$this->esAdministrador()
            && !(new GestorOrganizadores())->esOrganizador($idTorneo, $this->idUsuario())) {
            $this->volver('El torneo está a cargo de otro organizador.');
        }

        if ($accion === 'RECHAZAR') {
            $gestor->rechazar(array_column($solicitudes, 'id'), $this->idUsuario());
            $this->auditar('MODIFICACION', 'SolicitudEquipo');
            $this->volver('Pedido de inscripción rechazado.');
        }

        if (!$gestor->aprobarInscribir($solicitudes, $this->idUsuario())) {
            $this->volver('El torneo ya no tiene inscripciones abiertas.');
        }

        $this->auditar('MODIFICACION', 'SolicitudEquipo');
        $this->auditar('ALTA', 'Inscripcion');
        $this->volver('Equipo inscripto en ' . $solicitudes[0]['torneo'] . '.');
    }

    private function formulario(): void
    {
        $this->requiereRol(self::ADMINISTRADOR);
        $this->exigirFormulario('participantes');
    }

    /** Campos del formulario de participante, en el orden de GestorParticipantes::crearParticipante() */
    private function datosDeParticipante(?string &$errores): ?array
    {
        $validador = new Validador();

        $nombre = $validador->nombrePersona('nombre', $_POST['nombre'] ?? '', 2, 80);

        $alias = trim((string) ($_POST['alias'] ?? ''));
        $alias = $alias === '' ? null : $validador->texto('alias', $alias, 2, 40);

        $nacimiento = trim((string) ($_POST['nacimiento'] ?? ''));
        $nacimiento = $nacimiento === '' ? null : $validador->fecha('nacimiento', $nacimiento);

        if (!$validador->hayErrores() && $nacimiento !== null && $nacimiento > date('Y-m-d')) {
            $errores = 'La fecha de nacimiento no puede ser posterior a hoy.';
            return null;
        }

        if ($validador->hayErrores()) {
            $errores = self::textoDeErrores($validador);
            return null;
        }

        return [$nombre, $alias, $nacimiento, isset($_POST['publico'])];
    }

    private function volver(string $mensaje, ?int $idEquipo = null): void
    {
        $this->avisar($mensaje);
        $this->redirigir('participantes' . ($idEquipo ? '&equipo=' . $idEquipo . '#equipo' : ''));
    }
}
