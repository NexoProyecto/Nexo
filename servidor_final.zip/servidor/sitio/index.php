<?php
/** Punto de entrada: sesión, rutas (index.php?ruta=...) y manejo de errores */

/** Las vistas responden solo cuando las carga un controlador */
const CUPCORE = true;

require_once __DIR__ . '/seguridad/SesionSegura.php';
require_once __DIR__ . '/modelos/GestorUsuarios.php';

/** Todo error no previsto termina en la misma pantalla; el detalle queda en el registro del servidor */
set_exception_handler(function (Throwable $error): void {
    error_log('CupCore: ' . get_class($error) . ': ' . $error->getMessage()
        . ' en ' . $error->getFile() . ':' . $error->getLine());

    if (!headers_sent()) {
        http_response_code($error instanceof PDOException ? 503 : 500);
    }
    $sinServicio = $error instanceof PDOException;
    require __DIR__ . '/vistas/error.php';
});

SesionSegura::iniciar();

// Sesión vencida por inactividad o por duración máxima.
// Solo aplica con una cuenta iniciada: un visitante sin sesión no tiene nada que cerrar
if (isset($_SESSION['usuario']) && SesionSegura::vencida()) {
    SesionSegura::cerrar();
    SesionSegura::iniciar();
    $_SESSION['aviso'] = 'Sesión cerrada por inactividad.';
    header('Location: index.php?ruta=login');
    exit;
}
SesionSegura::marcarActividad();

// Cuenta dada de baja, inactiva o con otro rol
if (isset($_SESSION['usuario'])) {
    $cuenta = (new GestorUsuarios())->buscarPorCorreo($_SESSION['usuario']['correo']);
    if ($cuenta === null || $cuenta->getEstado() !== 'Activo'
        || $cuenta->getId() !== (string) $_SESSION['usuario']['id']
        || $cuenta->getRol() !== $_SESSION['usuario']['rol']) {
        SesionSegura::cerrar();
        SesionSegura::iniciar();
        $_SESSION['aviso'] = 'La cuenta no está habilitada.';
        header('Location: index.php?ruta=login');
        exit;
    }
}

$rutas = [
    // Consulta pública
    ''                       => ['InicioController', 'index'],
    'inicio'                 => ['InicioController', 'index'],
    'torneos'                => ['TorneoController', 'index'],
    'torneo'                 => ['TorneoController', 'detalle'],
    'calendario'             => ['CalendarioController', 'index'],
    'perfil'                 => ['PerfilController', 'index'],
    'api/torneos'            => ['ApiController', 'torneos'],
    'api/posiciones'         => ['ApiController', 'posiciones'],

    // Ingreso
    'login'                  => ['LoginController', 'index'],
    'salir'                  => ['SalirController', 'index'],
    'clave'                  => ['ClaveController', 'index'],
    'solicitud'              => ['SolicitudController', 'index'],

    // Administrador general
    'admin'                  => ['AdminController', 'index'],
    'admin/crear'            => ['AdminController', 'crearUsuario'],
    'admin/modificar'        => ['AdminController', 'modificarUsuario'],
    'admin/eliminar'         => ['AdminController', 'eliminarUsuario'],
    'admin/aprobar'          => ['AdminController', 'aprobarSolicitud'],
    'admin/rechazar'         => ['AdminController', 'rechazarSolicitud'],
    'admin/reabrir'          => ['AdminController', 'reabrirTorneo'],
    'admin/cerrar'           => ['AdminController', 'cerrarTorneo'],
    'admin/rechazar-reapertura' => ['AdminController', 'rechazarReapertura'],
    'admin/aprobar-torneo'   => ['AdminController', 'aprobarTorneo'],
    'admin/rechazar-torneo'  => ['AdminController', 'rechazarTorneo'],

    // Organizador (y administrador): torneos
    'organizador'            => ['OrganizadorController', 'index'],
    'organizador/crear'      => ['OrganizadorController', 'crearTorneo'],
    'organizador/unirse'     => ['OrganizadorController', 'solicitarUnirse'],
    'organizador/reapertura' => ['OrganizadorController', 'solicitarReapertura'],
    'gestion'                => ['GestionController', 'index'],
    'gestion/modificar'      => ['GestionController', 'modificar'],
    'gestion/publicar'       => ['GestionController', 'publicar'],
    'gestion/cancelar'       => ['GestionController', 'cancelar'],
    'gestion/cerrar'         => ['GestionController', 'cerrar'],
    'gestion/organizador'    => ['GestionController', 'resolverOrganizador'],
    'gestion/inscribir'      => ['GestionController', 'inscribir'],
    'gestion/inscripcion'    => ['GestionController', 'resolverInscripcion'],
    'gestion/equipo'         => ['GestionController', 'resolverEquipo'],
    'gestion/iniciar'        => ['GestionController', 'iniciar'],
    'gestion/resultado'      => ['GestionController', 'cargarResultado'],
    'gestion/validar'        => ['GestionController', 'validarResultado'],
    'gestion/cerrar-ronda'   => ['GestionController', 'cerrarRonda'],

    // Administrador: participantes y equipos
    'participantes'          => ['ParticipantesController', 'index'],
    'participantes/crear'    => ['ParticipantesController', 'crear'],
    'participantes/modificar' => ['ParticipantesController', 'modificar'],
    'participantes/eliminar' => ['ParticipantesController', 'eliminar'],
    'equipos/crear'          => ['ParticipantesController', 'crearEquipo'],
    'equipos/modificar'      => ['ParticipantesController', 'modificarEquipo'],
    'equipos/eliminar'       => ['ParticipantesController', 'eliminarEquipo'],
    'equipos/integrante'     => ['ParticipantesController', 'agregarIntegrante'],
    'equipos/quitar'         => ['ParticipantesController', 'quitarIntegrante'],
    'equipos/solicitudes'    => ['ParticipantesController', 'resolverSolicitudes'],

    // Participante
    'participante'           => ['ParticipanteController', 'index'],
    'participante/inscribir' => ['ParticipanteController', 'inscribir'],
    'participante/perfil'    => ['ParticipanteController', 'guardarPerfil'],
    'mis-equipos'            => ['MisEquiposController', 'index'],
    'mis-equipos/integrar'   => ['MisEquiposController', 'integrar'],
    'mis-equipos/inscribir'  => ['MisEquiposController', 'inscribir'],
];

$ruta = $_GET['ruta'] ?? '';
$ruta = is_string($ruta) ? trim($ruta, '/') : '';

// Ruta desconocida
if (!isset($rutas[$ruta])) {
    header('Location: index.php?ruta=inicio');
    exit;
}

// Cambio de contraseña obligatorio
if (!empty($_SESSION['debeCambiarClave']) && !in_array($ruta, ['clave', 'salir'], true)) {
    header('Location: index.php?ruta=clave');
    exit;
}

[$nombreControlador, $accion] = $rutas[$ruta];

require_once __DIR__ . '/controladores/' . $nombreControlador . '.php';

$controlador = new $nombreControlador();
$controlador->$accion();
