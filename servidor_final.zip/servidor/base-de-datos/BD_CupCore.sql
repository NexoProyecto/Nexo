--  CupCore - Sistema de Gestion Deportiva Modular

CREATE DATABASE IF NOT EXISTS CupCore
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE CupCore;

--  ROL
CREATE TABLE IF NOT EXISTS Rol (
    IdRol       INT             NOT NULL AUTO_INCREMENT,
    NombreRol   VARCHAR(20)     NOT NULL,
    PRIMARY KEY (IdRol),
    CONSTRAINT uqRolNombreRol   UNIQUE (NombreRol),
    -- RNE3
    CONSTRAINT chkRolNombreRol  CHECK (NombreRol IN
        ('ADMINISTRADOR','ORGANIZADOR','PARTICIPANTE'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


--  USUARIO
CREATE TABLE IF NOT EXISTS Usuario (
    IdUsuario   INT             NOT NULL AUTO_INCREMENT,
    Nombre      VARCHAR(50)     NOT NULL,
    Apellido    VARCHAR(50)     NOT NULL,
    Email       VARCHAR(120)    NOT NULL,
    Password    VARCHAR(255)    NOT NULL,   -- se guarda el hash
    Estado      VARCHAR(10)     NOT NULL DEFAULT 'ACTIVO',
    FechaAlta   DATE            NOT NULL,
    FechaClave  DATE            NOT NULL DEFAULT (CURDATE()),   -- ultimo cambio de contrasena
    CambioObligatorio TINYINT(1) NOT NULL DEFAULT 0,            -- 1: contrasena provisional
    IdRol       INT             NOT NULL,
    PRIMARY KEY (IdUsuario),
    -- RNE1
    CONSTRAINT uqUsuarioEmail   UNIQUE (Email),
    CONSTRAINT chkUsuarioEmail  CHECK (Email LIKE '%_@_%._%'),
    -- RNE2
    CONSTRAINT chkUsuarioEstado CHECK (Estado IN ('ACTIVO','INACTIVO')),
    CONSTRAINT fkUsuarioIdRol   FOREIGN KEY (IdRol)
        REFERENCES Rol (IdRol) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


--  Columnas de la politica de contrasenas en una base ya creada
ALTER TABLE Usuario
    ADD COLUMN IF NOT EXISTS FechaClave DATE NOT NULL DEFAULT (CURDATE()) AFTER FechaAlta,
    ADD COLUMN IF NOT EXISTS CambioObligatorio TINYINT(1) NOT NULL DEFAULT 0 AFTER FechaClave;


--  HISTORIAL DE CONTRASENAS
CREATE TABLE IF NOT EXISTS HistorialClave (
    IdHistorial INT             NOT NULL AUTO_INCREMENT,
    Password    VARCHAR(255)    NOT NULL,   -- se guarda el hash
    FechaCambio DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    IdUsuario   INT             NOT NULL,
    PRIMARY KEY (IdHistorial),
    CONSTRAINT fkHistorialClaveIdUsuario FOREIGN KEY (IdUsuario)
        REFERENCES Usuario (IdUsuario) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--  SOLICITUD DE CUENTA
--  Pedido de cuenta desde la pantalla de ingreso; lo resuelve un administrador
CREATE TABLE IF NOT EXISTS SolicitudCuenta (
    IdSolicitud         INT             NOT NULL AUTO_INCREMENT,
    Nombre              VARCHAR(50)     NOT NULL,
    Apellido            VARCHAR(50)     NOT NULL,
    Email               VARCHAR(120)    NOT NULL,
    Password            VARCHAR(255)        NULL,   -- hash; se borra al resolver
    Motivo              VARCHAR(300)        NULL,
    EstadoSolicitud     VARCHAR(10)     NOT NULL DEFAULT 'PENDIENTE',
    FechaSolicitud      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaResolucion     DATETIME            NULL,
    IdRolTentativo      INT             NOT NULL,
    IdUsuarioResuelve   INT                 NULL,
    IdUsuarioCreado     INT                 NULL,
    PRIMARY KEY (IdSolicitud),
    CONSTRAINT chkSolicitudCuentaEmail  CHECK (Email LIKE '%_@_%._%'),
    -- RNE17
    CONSTRAINT chkSolicitudCuentaEstado CHECK (EstadoSolicitud IN
        ('PENDIENTE','APROBADA','RECHAZADA')),
    -- RNE18: la pendiente conserva el hash; la resuelta tiene fecha y no tiene hash
    CONSTRAINT chkSolicitudCuentaResolucion CHECK (
        (EstadoSolicitud = 'PENDIENTE' AND Password IS NOT NULL AND FechaResolucion IS NULL)
        OR (EstadoSolicitud <> 'PENDIENTE' AND Password IS NULL AND FechaResolucion IS NOT NULL)),
    CONSTRAINT fkSolicitudCuentaIdRol FOREIGN KEY (IdRolTentativo)
        REFERENCES Rol (IdRol) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fkSolicitudCuentaResuelve FOREIGN KEY (IdUsuarioResuelve)
        REFERENCES Usuario (IdUsuario) ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fkSolicitudCuentaCreado FOREIGN KEY (IdUsuarioCreado)
        REFERENCES Usuario (IdUsuario) ON UPDATE CASCADE ON DELETE SET NULL,
    INDEX idxSolicitudCuentaEstado (EstadoSolicitud, Email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- AUDITORIAREGISTRO
CREATE TABLE IF NOT EXISTS AuditoriaRegistro (
    IdAuditoria     INT             NOT NULL AUTO_INCREMENT,
    AccionRealizada VARCHAR(20)     NOT NULL,
    TablaAfectada   VARCHAR(50)     NOT NULL,
    FechaHora       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    IpOrigen        VARCHAR(45)     NOT NULL,
    IdUsuario       INT             NOT NULL,
    PRIMARY KEY (IdAuditoria),
    CONSTRAINT chkAuditoriaRegistroAccion CHECK (AccionRealizada IN
        ('ALTA','MODIFICACION','BAJA','LOGIN','LOGOUT')),
    CONSTRAINT fkAuditoriaRegistroIdUsuario FOREIGN KEY (IdUsuario)
        REFERENCES Usuario (IdUsuario) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--  El registro de auditoria no admite cambios ni borrados
CREATE OR REPLACE TRIGGER trgAuditoriaRegistroSinCambios
    BEFORE UPDATE ON AuditoriaRegistro FOR EACH ROW
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El registro de auditoria no se modifica';

CREATE OR REPLACE TRIGGER trgAuditoriaRegistroSinBorrados
    BEFORE DELETE ON AuditoriaRegistro FOR EACH ROW
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El registro de auditoria no se borra';


-- PARTICIPANTE
CREATE TABLE IF NOT EXISTS Participante (
    IdParticipante      INT         NOT NULL AUTO_INCREMENT,
    NombreParticipante  VARCHAR(80) NOT NULL,
    Alias               VARCHAR(40)     NULL,
    FechaNacimiento     DATE            NULL,
    PerfilPublico       BOOLEAN     NOT NULL DEFAULT FALSE,
    PRIMARY KEY (IdParticipante)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- VINCULA
CREATE TABLE IF NOT EXISTS Vincula (
    IdParticipante  INT     NOT NULL,
    IdUsuario       INT     NOT NULL,
    PRIMARY KEY (IdParticipante),
    CONSTRAINT uqVinculaIdUsuario   UNIQUE (IdUsuario),
    CONSTRAINT fkVinculaIdParticipante FOREIGN KEY (IdParticipante)
        REFERENCES Participante (IdParticipante)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fkVinculaIdUsuario   FOREIGN KEY (IdUsuario)
        REFERENCES Usuario (IdUsuario) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- EQUIPO
-- IdParticipante: participante que representa al equipo en los torneos. Inscribir al
-- equipo es inscribir a su representante
CREATE TABLE IF NOT EXISTS Equipo (
    IdEquipo        INT         NOT NULL AUTO_INCREMENT,
    NombreEquipo    VARCHAR(80) NOT NULL,
    PerfilPublico   BOOLEAN     NOT NULL DEFAULT FALSE,
    FechaCreacion   DATE        NOT NULL,
    IdParticipante  INT             NULL,
    PRIMARY KEY (IdEquipo),
    CONSTRAINT uqEquipoNombreEquipo UNIQUE (NombreEquipo),
    -- RNE23: un participante representa a un solo equipo
    CONSTRAINT uqEquipoIdParticipante UNIQUE (IdParticipante),
    CONSTRAINT fkEquipoIdParticipante FOREIGN KEY (IdParticipante)
        REFERENCES Participante (IdParticipante)
        ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--  Representante del equipo en una base ya creada
ALTER TABLE Equipo
    ADD COLUMN IF NOT EXISTS IdParticipante INT NULL AFTER FechaCreacion,
    ADD UNIQUE INDEX IF NOT EXISTS uqEquipoIdParticipante (IdParticipante),
    ADD CONSTRAINT fkEquipoIdParticipante FOREIGN KEY IF NOT EXISTS (IdParticipante)
        REFERENCES Participante (IdParticipante)
        ON UPDATE CASCADE ON DELETE SET NULL;

--  En una base con datos, cada equipo toma como representante al participante sin cuenta
--  que lleva su mismo nombre
UPDATE Equipo
SET IdParticipante = (
    SELECT MIN(Participante.IdParticipante) FROM Participante
    WHERE Participante.NombreParticipante = Equipo.NombreEquipo
      AND NOT EXISTS (SELECT 1 FROM Vincula WHERE Vincula.IdParticipante = Participante.IdParticipante))
WHERE IdParticipante IS NULL;

-- INTEGRA
CREATE TABLE IF NOT EXISTS Integra (
    IdParticipante  INT     NOT NULL,
    IdEquipo        INT     NOT NULL,
    FechaIngreso    DATE    NOT NULL,
    PRIMARY KEY (IdParticipante, IdEquipo),
    CONSTRAINT fkIntegraIdParticipante FOREIGN KEY (IdParticipante)
        REFERENCES Participante (IdParticipante)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fkIntegraIdEquipo    FOREIGN KEY (IdEquipo)
        REFERENCES Equipo (IdEquipo) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TIPOTORNEO
CREATE TABLE IF NOT EXISTS TipoTorneo (
    IdTipoTorneo    INT             NOT NULL AUTO_INCREMENT,
    NombreTipo      VARCHAR(40)     NOT NULL,
    Descripcion     VARCHAR(200)        NULL,
    PRIMARY KEY (IdTipoTorneo),
    CONSTRAINT uqTipoTorneoNombreTipo UNIQUE (NombreTipo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- MODULOCOMPETENCIA
CREATE TABLE IF NOT EXISTS ModuloCompetencia (
    IdModulo        INT             NOT NULL AUTO_INCREMENT,
    NombreModulo    VARCHAR(30)     NOT NULL,
    Descripcion     VARCHAR(200)        NULL,
    PRIMARY KEY (IdModulo),
    CONSTRAINT uqModuloCompetenciaNombre UNIQUE (NombreModulo),
    -- RNE4
    CONSTRAINT chkModuloCompetenciaNombre CHECK (NombreModulo IN
        ('LIGA','ELIMINATORIA','SUIZO'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TORNEO
CREATE TABLE IF NOT EXISTS Torneo (
    IdTorneo        INT             NOT NULL AUTO_INCREMENT,
    NombreTorneo    VARCHAR(100)    NOT NULL,
    FechaInicio     DATE            NOT NULL,
    FechaFin        DATE                NULL,
    Estado          VARCHAR(12)     NOT NULL DEFAULT 'BORRADOR',
    EstadoPrevio    VARCHAR(12)         NULL,   -- estado al cerrarse; lo restituye la reapertura
    IdTipoTorneo    INT             NOT NULL,
    IdUsuario       INT             NOT NULL,   -- organizador que lo creo o lo solicito
    PRIMARY KEY (IdTorneo),
    -- RNE5: el torneo que pide un organizador queda SOLICITADO hasta que el
    -- administrador lo pasa a BORRADOR o a RECHAZADO
    CONSTRAINT chkTorneoEstado      CHECK (Estado IN
        ('SOLICITADO','RECHAZADO','BORRADOR','ABIERTO','EN CURSO','FINALIZADO','CANCELADO','CERRADO')),
    -- RNE16: un torneo cerrado guarda el estado que tenia (nunca borrador); los demas no
    CONSTRAINT chkTorneoEstadoPrevio CHECK (
        (Estado = 'CERRADO' AND EstadoPrevio IN
            ('ABIERTO','EN CURSO','FINALIZADO','CANCELADO'))
        OR (Estado <> 'CERRADO' AND EstadoPrevio IS NULL)),
    -- RNE6
    CONSTRAINT chkTorneoFechas      CHECK (FechaFin IS NULL
                                           OR FechaFin >= FechaInicio),
    CONSTRAINT fkTorneoIdTipoTorneo FOREIGN KEY (IdTipoTorneo)
        REFERENCES TipoTorneo (IdTipoTorneo)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fkTorneoIdUsuario    FOREIGN KEY (IdUsuario)
        REFERENCES Usuario (IdUsuario) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--  Columnas del cierre en una base ya creada
ALTER TABLE Torneo
    ADD COLUMN IF NOT EXISTS EstadoPrevio VARCHAR(12) NULL AFTER Estado,
    DROP CONSTRAINT IF EXISTS chkTorneoEstado,
    DROP CONSTRAINT IF EXISTS chkTorneoEstadoPrevio;
ALTER TABLE Torneo
    ADD CONSTRAINT chkTorneoEstado CHECK (Estado IN
        ('SOLICITADO','RECHAZADO','BORRADOR','ABIERTO','EN CURSO','FINALIZADO','CANCELADO','CERRADO')),
    ADD CONSTRAINT chkTorneoEstadoPrevio CHECK (
        (Estado = 'CERRADO' AND EstadoPrevio IN
            ('ABIERTO','EN CURSO','FINALIZADO','CANCELADO'))
        OR (Estado <> 'CERRADO' AND EstadoPrevio IS NULL));

-- ORGANIZA
-- Relacion N a N entre Usuario y Torneo: organizadores que se suman a un torneo ajeno.
-- El organizador que crea el torneo figura en Torneo.IdUsuario
CREATE TABLE IF NOT EXISTS Organiza (
    IdTorneo            INT         NOT NULL,
    IdUsuario           INT         NOT NULL,
    EstadoOrganiza      VARCHAR(10) NOT NULL DEFAULT 'PENDIENTE',
    FechaSolicitud      DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaResolucion     DATETIME        NULL,
    IdUsuarioResuelve   INT             NULL,
    PRIMARY KEY (IdTorneo, IdUsuario),
    -- RNE19
    CONSTRAINT chkOrganizaEstado CHECK (EstadoOrganiza IN
        ('PENDIENTE','ACEPTADA','RECHAZADA')),
    CONSTRAINT chkOrganizaResolucion CHECK (
        (EstadoOrganiza = 'PENDIENTE') = (FechaResolucion IS NULL)),
    CONSTRAINT fkOrganizaIdTorneo FOREIGN KEY (IdTorneo)
        REFERENCES Torneo (IdTorneo) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fkOrganizaIdUsuario FOREIGN KEY (IdUsuario)
        REFERENCES Usuario (IdUsuario) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fkOrganizaResuelve FOREIGN KEY (IdUsuarioResuelve)
        REFERENCES Usuario (IdUsuario) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- SOLICITUDREAPERTURA
-- Pedido de un organizador para reabrir un torneo cerrado; lo resuelve un administrador
CREATE TABLE IF NOT EXISTS SolicitudReapertura (
    IdSolicitudReapertura INT          NOT NULL AUTO_INCREMENT,
    IdTorneo              INT          NOT NULL,
    IdUsuarioSolicita     INT          NOT NULL,
    Motivo                VARCHAR(300) NOT NULL,
    EstadoSolicitud       VARCHAR(10)  NOT NULL DEFAULT 'PENDIENTE',
    FechaSolicitud        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaResolucion       DATETIME         NULL,
    IdUsuarioResuelve     INT              NULL,
    -- Toma el IdTorneo solo mientras la solicitud esta pendiente: la clave unica
    -- admite una sola solicitud pendiente por torneo
    TorneoPendiente       INT AS (CASE WHEN EstadoSolicitud = 'PENDIENTE'
                                 THEN IdTorneo END) PERSISTENT,
    PRIMARY KEY (IdSolicitudReapertura),
    -- RNE20
    CONSTRAINT chkReaperturaEstado CHECK (EstadoSolicitud IN
        ('PENDIENTE','APROBADA','RECHAZADA')),
    -- RNE21: la pendiente no tiene resolucion; la resuelta tiene fecha
    CONSTRAINT chkReaperturaResolucion CHECK (
        (EstadoSolicitud = 'PENDIENTE') = (FechaResolucion IS NULL)),
    -- RNE22: una sola solicitud pendiente por torneo
    CONSTRAINT uqReaperturaPendiente UNIQUE (TorneoPendiente),
    -- ON UPDATE RESTRICT: MariaDB no admite una columna calculada sobre una clave con ON UPDATE CASCADE
    CONSTRAINT fkReaperturaIdTorneo FOREIGN KEY (IdTorneo)
        REFERENCES Torneo (IdTorneo) ON UPDATE RESTRICT ON DELETE CASCADE,
    CONSTRAINT fkReaperturaSolicita FOREIGN KEY (IdUsuarioSolicita)
        REFERENCES Usuario (IdUsuario) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fkReaperturaResuelve FOREIGN KEY (IdUsuarioResuelve)
        REFERENCES Usuario (IdUsuario) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- CONFIGURA
CREATE TABLE IF NOT EXISTS Configura (
    IdTorneo            INT             NOT NULL,
    IdModulo            INT             NOT NULL,
    ReglasEspecificas   VARCHAR(500)        NULL,
    Habilitado          BOOLEAN         NOT NULL DEFAULT TRUE,
    PRIMARY KEY (IdTorneo, IdModulo),
    CONSTRAINT fkConfiguraIdTorneo  FOREIGN KEY (IdTorneo)
        REFERENCES Torneo (IdTorneo) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fkConfiguraIdModulo  FOREIGN KEY (IdModulo)
        REFERENCES ModuloCompetencia (IdModulo)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- RONDA
CREATE TABLE IF NOT EXISTS Ronda (
    IdTorneo        INT         NOT NULL,
    NumeroRonda     INT         NOT NULL,
    EstadoRonda     VARCHAR(10) NOT NULL DEFAULT 'PENDIENTE',
    FechaProgramada DATE            NULL,
    PRIMARY KEY (IdTorneo, NumeroRonda),
    -- RNE9
    CONSTRAINT chkRondaNumeroRonda  CHECK (NumeroRonda > 0),
    -- RNE10
    CONSTRAINT chkRondaEstadoRonda  CHECK (EstadoRonda IN
        ('PENDIENTE','EN CURSO','CERRADA')),
    CONSTRAINT fkRondaIdTorneo      FOREIGN KEY (IdTorneo)
        REFERENCES Torneo (IdTorneo) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- INSCRIPCION
CREATE TABLE IF NOT EXISTS Inscripcion (
    IdInscripcion       INT         NOT NULL AUTO_INCREMENT,
    FechaInscripcion    DATE        NOT NULL,
    EstadoInscripcion   VARCHAR(10) NOT NULL DEFAULT 'PENDIENTE',
    IdTorneo            INT         NOT NULL,
    IdParticipante      INT         NOT NULL,
    PRIMARY KEY (IdInscripcion),
    -- RNE8
    CONSTRAINT uqInscripcionTorneoParticipante
        UNIQUE (IdTorneo, IdParticipante),
    CONSTRAINT uqInscripcionAgregacion UNIQUE (IdInscripcion, IdTorneo),
    -- RNE7
    CONSTRAINT chkInscripcionEstado CHECK (EstadoInscripcion IN
        ('PENDIENTE','ACEPTADA','RECHAZADA')),
    CONSTRAINT fkInscripcionIdTorneo FOREIGN KEY (IdTorneo)
        REFERENCES Torneo (IdTorneo) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fkInscripcionIdParticipante FOREIGN KEY (IdParticipante)
        REFERENCES Participante (IdParticipante)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- SOLICITUDEQUIPO
-- Pedido de un participante: integrar un equipo (existente o nuevo, con el nombre que
-- propone) o inscribir a su equipo en un torneo. Lo resuelve un organizador o el
-- administrador; los pedidos iguales se aprueban o rechazan juntos.
-- Equipo y Torneo van en RESTRICT: MariaDB no admite un CHECK sobre columnas con FK en
-- cascada. El sistema borra las solicitudes de un equipo antes de borrar el equipo
CREATE TABLE IF NOT EXISTS SolicitudEquipo (
    IdSolicitudEquipo   INT         NOT NULL AUTO_INCREMENT,
    TipoSolicitud       VARCHAR(10) NOT NULL,
    EstadoSolicitud     VARCHAR(10) NOT NULL DEFAULT 'PENDIENTE',
    NombrePropuesto     VARCHAR(80)     NULL,
    FechaSolicitud      DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FechaResolucion     DATETIME        NULL,
    IdParticipante      INT         NOT NULL,   -- quien pide
    IdEquipo            INT             NULL,   -- en un equipo nuevo, se completa al aprobar
    IdTorneo            INT             NULL,
    IdUsuarioResuelve   INT             NULL,
    PRIMARY KEY (IdSolicitudEquipo),
    CONSTRAINT chkSolicitudEquipoTipo CHECK (TipoSolicitud IN ('INTEGRAR','INSCRIBIR')),
    CONSTRAINT chkSolicitudEquipoEstado CHECK (EstadoSolicitud IN
        ('PENDIENTE','APROBADA','RECHAZADA')),
    -- RNE24: integrar lleva equipo o nombre propuesto y no lleva torneo;
    -- inscribir lleva equipo y torneo
    CONSTRAINT chkSolicitudEquipoDatos CHECK (
        (TipoSolicitud = 'INTEGRAR' AND IdTorneo IS NULL
            AND (IdEquipo IS NOT NULL OR NombrePropuesto IS NOT NULL))
        OR (TipoSolicitud = 'INSCRIBIR' AND IdEquipo IS NOT NULL AND IdTorneo IS NOT NULL)),
    -- RNE25: la pendiente no tiene fecha de resolucion; la resuelta si
    CONSTRAINT chkSolicitudEquipoResolucion CHECK (
        (EstadoSolicitud = 'PENDIENTE' AND FechaResolucion IS NULL)
        OR (EstadoSolicitud <> 'PENDIENTE' AND FechaResolucion IS NOT NULL)),
    CONSTRAINT fkSolicitudEquipoParticipante FOREIGN KEY (IdParticipante)
        REFERENCES Participante (IdParticipante) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fkSolicitudEquipoEquipo FOREIGN KEY (IdEquipo)
        REFERENCES Equipo (IdEquipo) ON UPDATE RESTRICT ON DELETE RESTRICT,
    CONSTRAINT fkSolicitudEquipoTorneo FOREIGN KEY (IdTorneo)
        REFERENCES Torneo (IdTorneo) ON UPDATE RESTRICT ON DELETE RESTRICT,
    CONSTRAINT fkSolicitudEquipoResuelve FOREIGN KEY (IdUsuarioResuelve)
        REFERENCES Usuario (IdUsuario) ON UPDATE CASCADE ON DELETE SET NULL,
    INDEX idxSolicitudEquipoEstado (EstadoSolicitud, TipoSolicitud)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ENFRENTAMIENTO
CREATE TABLE IF NOT EXISTS Enfrentamiento (
    IdEnfrentamiento        INT         NOT NULL AUTO_INCREMENT,
    FechaHora               DATETIME        NULL,
    EstadoPartido           VARCHAR(12) NOT NULL DEFAULT 'PROGRAMADO',
    IdTorneo                INT         NOT NULL,
    NumeroRonda             INT         NOT NULL,
    IdInscripcionLocal      INT         NOT NULL,
    IdInscripcionVisitante  INT         NOT NULL,
    PRIMARY KEY (IdEnfrentamiento),
    CONSTRAINT chkEnfrentamientoEstado CHECK (EstadoPartido IN
        ('PROGRAMADO','JUGADO','SUSPENDIDO','CANCELADO')),
    -- RNE11: local y visitante deben ser distintos
    CONSTRAINT chkEnfrentamientoRivales
        CHECK (IdInscripcionLocal <> IdInscripcionVisitante),
    CONSTRAINT fkEnfrentamientoRonda FOREIGN KEY (IdTorneo, NumeroRonda)
        REFERENCES Ronda (IdTorneo, NumeroRonda)
        ON UPDATE CASCADE ON DELETE CASCADE,
    -- RNE12: la inscripcion local pertenece al torneo del enfrentamiento
    CONSTRAINT fkEnfrentamientoLocal
        FOREIGN KEY (IdInscripcionLocal, IdTorneo)
        REFERENCES Inscripcion (IdInscripcion, IdTorneo)
        ON UPDATE RESTRICT ON DELETE RESTRICT,
    -- RNE12: y la visitante tambien
    CONSTRAINT fkEnfrentamientoVisitante
        FOREIGN KEY (IdInscripcionVisitante, IdTorneo)
        REFERENCES Inscripcion (IdInscripcion, IdTorneo)
        ON UPDATE RESTRICT ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- RESULTADO
CREATE TABLE IF NOT EXISTS Resultado (
    IdResultado         INT         NOT NULL AUTO_INCREMENT,
    PuntuacionLocal     INT         NOT NULL DEFAULT 0,
    PuntuacionVisitante INT         NOT NULL DEFAULT 0,
    Ganador             VARCHAR(10) NOT NULL,
    Validado            BOOLEAN     NOT NULL DEFAULT FALSE,
    FechaCarga          DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    IdEnfrentamiento    INT         NOT NULL,
    PRIMARY KEY (IdResultado),
    CONSTRAINT uqResultadoIdEnfrentamiento UNIQUE (IdEnfrentamiento),
    -- RNE13
    CONSTRAINT chkResultadoPuntuaciones CHECK (PuntuacionLocal >= 0
                                           AND PuntuacionVisitante >= 0),
    -- RNE14
    CONSTRAINT chkResultadoGanador  CHECK (Ganador IN
        ('LOCAL','VISITANTE','EMPATE')),
    CONSTRAINT fkResultadoIdEnfrentamiento FOREIGN KEY (IdEnfrentamiento)
        REFERENCES Enfrentamiento (IdEnfrentamiento)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- TABLAPOSICIONES
CREATE TABLE IF NOT EXISTS TablaPosiciones (
    IdPosicion          INT     NOT NULL AUTO_INCREMENT,
    PartidosJugados     INT     NOT NULL DEFAULT 0,
    Victorias           INT     NOT NULL DEFAULT 0,
    Empates             INT     NOT NULL DEFAULT 0,
    Derrotas            INT     NOT NULL DEFAULT 0,
    PuntosAcumulados    INT     NOT NULL DEFAULT 0,
    IdTorneo            INT     NOT NULL,
    IdInscripcion       INT     NOT NULL,
    PRIMARY KEY (IdPosicion),
    CONSTRAINT uqTablaPosicionesInscripcion UNIQUE (IdInscripcion),
    -- RNE15
    CONSTRAINT chkTablaPosicionesPartidos
        CHECK (PartidosJugados = Victorias + Empates + Derrotas),
    CONSTRAINT chkTablaPosicionesValores
        CHECK (Victorias >= 0 AND Empates >= 0 AND Derrotas >= 0
               AND PuntosAcumulados >= 0),
    CONSTRAINT fkTablaPosicionesAgregacion
        FOREIGN KEY (IdInscripcion, IdTorneo)
        REFERENCES Inscripcion (IdInscripcion, IdTorneo)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--  Datos de configuracion
INSERT IGNORE INTO Rol (NombreRol) VALUES
    ('ADMINISTRADOR'), ('ORGANIZADOR'), ('PARTICIPANTE');

INSERT IGNORE INTO TipoTorneo (NombreTipo, Descripcion) VALUES
    ('DEPORTIVO',   'Competencias deportivas tradicionales'),
    ('MENTAL',      'Ajedrez, juegos de cartas y de estrategia'),
    ('ELECTRONICO', 'Deportes electronicos y videojuegos');

INSERT IGNORE INTO ModuloCompetencia (NombreModulo, Descripcion) VALUES
    ('LIGA',         'Todos contra todos'),
    ('ELIMINATORIA', 'Llaves con eliminacion directa en cada ronda'),
    ('SUIZO',        'Emparejamiento por rendimiento acumulado');

--  DCL usuarios de la base de datos y sus permisos
--  La clave de cupcoreapp coincide con DB_PASS de config/database.php
CREATE USER IF NOT EXISTS 'cupcoreadmin'@'localhost'
    IDENTIFIED BY 'Cambiar-Admin-2026';
CREATE USER IF NOT EXISTS 'cupcoreapp'@'localhost'
    IDENTIFIED BY 'Cambiar-App-2026';
CREATE USER IF NOT EXISTS 'cupcoreconsulta'@'localhost'
    IDENTIFIED BY 'Cambiar-Consulta-2026';

-- Administrador de la base: mantenimiento y respaldos
GRANT ALL PRIVILEGES ON CupCore.* TO 'cupcoreadmin'@'localhost';

-- Usuario de la aplicacion PHP: solo operaciones CRUD
GRANT SELECT, INSERT, UPDATE, DELETE ON CupCore.* TO 'cupcoreapp'@'localhost';

-- Usuario de consulta publica: solo lectura de lo que se publica
GRANT SELECT ON CupCore.Torneo          TO 'cupcoreconsulta'@'localhost';
GRANT SELECT ON CupCore.TipoTorneo      TO 'cupcoreconsulta'@'localhost';
GRANT SELECT ON CupCore.Ronda           TO 'cupcoreconsulta'@'localhost';
GRANT SELECT ON CupCore.Enfrentamiento  TO 'cupcoreconsulta'@'localhost';
GRANT SELECT ON CupCore.Resultado       TO 'cupcoreconsulta'@'localhost';
GRANT SELECT ON CupCore.TablaPosiciones TO 'cupcoreconsulta'@'localhost';
GRANT SELECT ON CupCore.Participante    TO 'cupcoreconsulta'@'localhost';
GRANT SELECT ON CupCore.Equipo          TO 'cupcoreconsulta'@'localhost';

FLUSH PRIVILEGES;
