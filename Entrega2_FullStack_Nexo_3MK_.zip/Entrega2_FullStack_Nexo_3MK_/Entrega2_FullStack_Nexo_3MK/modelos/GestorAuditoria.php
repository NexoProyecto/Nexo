<?php
require_once __DIR__ . '/ConexionBD.php';

// Guarda en AuditoriaRegistro cada acción que cambia datos o ingresa un usuario.
// La letra del proyecto pide mantener una historia de todo lo hecho en la base.
class GestorAuditoria
{
    private PDO $bd;

    public function __construct()
    {
        $this->bd = ConexionBD::obtener();
    }

    // Registra una acción; $idUsuario es quién la hizo.
    public function registrar(int $idUsuario, string $accion, string $tabla): bool
    {
        $sql = "insert into AuditoriaRegistro
                    (AccionRealizada, TablaAfectada, FechaHora, IpOrigen, IdUsuario)
                values (:accion, :tabla, now(), :ip, :usuario)";

        $stmt = $this->bd->prepare($sql);
        $stmt->execute([
            ':accion'  => $accion,
            ':tabla'   => $tabla,
            ':ip'      => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            ':usuario' => $idUsuario,
        ]);

        return $stmt->rowCount() > 0;
    }

    // Últimas acciones registradas, para el panel del administrador.
    public function ultimas(int $limite = 20): array
    {
        $sql = "select AuditoriaRegistro.FechaHora       as fecha_hora,
                       concat(Usuario.Nombre, ' ', Usuario.Apellido) as usuario,
                       AuditoriaRegistro.AccionRealizada as accion,
                       AuditoriaRegistro.TablaAfectada   as tabla,
                       AuditoriaRegistro.IpOrigen        as ip
                from AuditoriaRegistro
                inner join Usuario on AuditoriaRegistro.IdUsuario = Usuario.IdUsuario
                order by AuditoriaRegistro.FechaHora desc
                limit :limite";

        $stmt = $this->bd->prepare($sql);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }
}
