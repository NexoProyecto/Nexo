<?php
// Vista del listado público de torneos con búsqueda.

function imagen_de_disciplina(string $disciplina): string
{
    return match ($disciplina) {
        'Fútbol'  => 'img/futbol.jpg',
        'eSports' => 'img/counter.webp',
        'Ajedrez' => 'img/ajedrez.jpg',
        default   => 'img/pingpong.jpg',
    };
}

function clase_de_modulo(string $modulo): string
{
    return match ($modulo) {
        'Liga'                => 'etiqueta-liga',
        'Eliminación directa' => 'etiqueta-eliminacion',
        default               => 'etiqueta-suizo',
    };
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CupCore | Torneos</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

    <nav class="menu">
        <div class="logo"><img src="img/logo.png" alt="Logo CupCore" class="logo-img"> CupCore</div>
        <ul>
            <li><a href="index.php?ruta=inicio"><span class="icono">🏠︎</span> Inicio</a></li>
            <li><a href="index.php?ruta=torneos" class="activo"><span class="icono">𐃯</span> Torneos</a></li>
            <li><a href="index.php?ruta=calendario"><span class="icono">🗓</span> Calendario</a></li>
            <li><a href="index.php?ruta=login"><span class="icono">♔</span> Ingresar</a></li>
        </ul>
    </nav>

    <main>
        <header class="encabezado">
            <h1>Torneos</h1>
            <p>Buscá torneos publicados y filtrá por tipo de competencia.</p>
        </header>

        <section class="seccion">
            <!-- El formulario envía por GET y el controlador filtra -->
            <form class="formulario" action="index.php?ruta=torneos" method="GET">
                <input type="hidden" name="ruta" value="torneos">
                <label>Buscar torneo
                    <input type="text" name="busqueda" placeholder="Ej: Copa Invierno" value="<?= htmlspecialchars($busqueda) ?>">
                </label>
                <label>Tipo de torneo (módulo)
                    <select name="modulo">
                        <option value="Todos" <?= $modulo === 'Todos' ? 'selected' : '' ?>>Todos</option>
                        <option value="Liga" <?= $modulo === 'Liga' ? 'selected' : '' ?>>Liga (todos contra todos)</option>
                        <option value="Eliminación directa" <?= $modulo === 'Eliminación directa' ? 'selected' : '' ?>>Eliminación directa (llaves)</option>
                        <option value="Sistema suizo" <?= $modulo === 'Sistema suizo' ? 'selected' : '' ?>>Sistema suizo (por puntaje)</option>
                    </select>
                </label>
                <button type="submit" class="boton">Buscar</button>
            </form>
        </section>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Torneos publicados (<?= count($torneos) ?>)</h2>
            </div>

            <?php if (count($torneos) === 0): ?>
                <p style="padding: 0 20px 20px; color: var(--texto-gris);">No se encontraron torneos con esos filtros.</p>
            <?php endif; ?>

            <div class="lista-torneos">
                <?php foreach ($torneos as $torneo): ?>
                <article class="torneo">
                    <img src="<?= imagen_de_disciplina($torneo['disciplina']) ?>" alt="Torneo de <?= htmlspecialchars($torneo['disciplina']) ?>" class="portada-img">
                    <div class="datos">
                        <span class="etiqueta <?= clase_de_modulo($torneo['modulo']) ?>"><?= htmlspecialchars($torneo['modulo']) ?></span>
                        <h3><?= htmlspecialchars($torneo['nombre']) ?></h3>
                        <div class="dato">🗓 <?= date('d/m', strtotime($torneo['fecha_inicio'])) ?> - <?= date('d/m', strtotime($torneo['fecha_fin'])) ?></div>
                        <div class="dato">𖨆 <?= (int) $torneo['inscriptos'] ?> inscriptos</div>
                        <div class="dato">Estado: <?= htmlspecialchars($torneo['estado']) ?></div>
                        <a href="index.php?ruta=calendario" class="boton-borde">Ver calendario</a>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
        </section>

        <footer class="pie">
            CupCore · Sistema de Gestión de Torneos Modulares · Grupo Nexo · 3°MK · 2026
        </footer>
    </main>
</body>
</html>