<?php
// Vista del calendario público (próximos partidos y últimos resultados).
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CupCore | Calendario</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

    <nav class="menu">
        <div class="logo"><img src="img/logo.png" alt="Logo CupCore" class="logo-img"> CupCore</div>
        <ul>
            <li><a href="index.php?ruta=inicio"><span class="icono">🏠︎</span> Inicio</a></li>
            <li><a href="index.php?ruta=torneos"><span class="icono">𐃯</span> Torneos</a></li>
            <li><a href="index.php?ruta=calendario" class="activo"><span class="icono">🗓</span> Calendario</a></li>
            <li><a href="index.php?ruta=login"><span class="icono">♔</span> Ingresar</a></li>
        </ul>
    </nav>

    <main>
        <header class="encabezado">
            <h1>Calendario</h1>
            <p>Próximos partidos y resultados oficiales de todos los torneos.</p>
        </header>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Próximos partidos</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr>
                            <th>Fecha</th><th>Hora</th><th>Torneo</th><th>Enfrentamiento</th><th>Ronda</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($proximos as $p): ?>
                        <tr>
                            <td><?= date('d/m', strtotime($p['fecha'])) ?></td>
                            <td><?= substr($p['hora'], 0, 5) ?></td>
                            <td><?= htmlspecialchars($p['torneo']) ?></td>
                            <td><?= htmlspecialchars($p['local']) ?> vs <?= htmlspecialchars($p['visitante']) ?></td>
                            <td><?= htmlspecialchars($p['ronda']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($proximos) === 0): ?>
                        <tr><td colspan="5" style="text-align:center; color:var(--texto-gris);">No hay partidos próximos.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Últimos resultados</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr>
                            <th>Fecha</th><th>Torneo</th><th>Enfrentamiento</th><th>Resultado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($resultados as $r): ?>
                        <tr>
                            <td><?= date('d/m', strtotime($r['fecha'])) ?></td>
                            <td><?= htmlspecialchars($r['torneo']) ?></td>
                            <td><?= htmlspecialchars($r['local']) ?> vs <?= htmlspecialchars($r['visitante']) ?></td>
                            <td><strong><?= $r['puntos_local'] ?> - <?= $r['puntos_visitante'] ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($resultados) === 0): ?>
                        <tr><td colspan="4" style="text-align:center; color:var(--texto-gris);">Todavía no hay resultados cargados.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <footer class="pie">
            CupCore · Sistema de Gestión de Torneos Modulares · Grupo Nexo · 3°MK · 2026
        </footer>
    </main>
</body>
</html>