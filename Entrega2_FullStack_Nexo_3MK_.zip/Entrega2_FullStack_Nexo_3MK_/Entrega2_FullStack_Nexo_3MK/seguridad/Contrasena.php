<?php
// Hash de contraseñas con bcrypt (costo 12). La contraseña original nunca
// se guarda ni se registra en los logs.
class Contrasena
{
    // Costo de bcrypt. A mayor costo, más lento el ataque por fuerza bruta.
    const COSTO = 12;

    public static function generarHash(string $clave): string
    {
        return password_hash($clave, PASSWORD_BCRYPT, ['cost' => self::COSTO]);
    }

    public static function verificar(string $clave, string $hash): bool
    {
        return password_verify($clave, $hash);
    }

    // Indica si el hash quedó con un costo viejo (por ejemplo, si se sube el
    // costo). Si devuelve true, se regenera el hash en el próximo ingreso.
    public static function necesitaActualizacion(string $hash): bool
    {
        return password_needs_rehash($hash, PASSWORD_BCRYPT, ['cost' => self::COSTO]);
    }

    // Datos del hash sin revelar la contraseña: algoritmo y costo aplicados.
    public static function informacion(string $hash): array
    {
        return password_get_info($hash);
    }

    // Contraseña provisional para las cuentas creadas por un administrador.
    // Cumple la política del proyecto y el usuario la cambia al ingresar.
    public static function provisional(): string
    {
        $mayusculas = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
        $minusculas = 'abcdefghijkmnpqrstuvwxyz';
        $numeros    = '23456789';
        $especiales = '!@#$%&*?';
        $clave  = $mayusculas[random_int(0, strlen($mayusculas) - 1)];
        $clave .= $especiales[random_int(0, strlen($especiales) - 1)];
        $clave .= $numeros[random_int(0, strlen($numeros) - 1)];
        for ($i = 0; $i < 7; $i++) {
            $clave .= $minusculas[random_int(0, strlen($minusculas) - 1)];
        }
        return $clave;
    }
}
