<?php
// Configuración segura de la sesión. Se invoca una sola vez por petición
// desde index.php. La cookie es httponly y SameSite=Strict; la sesión se
// cierra a los 30 minutos sin actividad.
class SesionSegura
{
    /** Minutos de inactividad antes de cerrar la sesión (política del proyecto). */
    const MINUTOS_INACTIVIDAD = 30;

    // La cookie 'secure' se activa solo sobre HTTPS; si estuviera siempre
    // activa, el navegador descartaría la cookie al probar por HTTP local.
    public static function iniciar(?bool $usarHttps = null): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }
        if ($usarHttps === null) {
            $usarHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
                || (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443;
        }
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'secure'   => $usarHttps,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
        session_name('CUPCORESESSID');
        session_start();
        if (!isset($_SESSION['ultimoAcceso'])) {
            $_SESSION['ultimoAcceso'] = time();
        }
    }

    // Cambia el identificador de sesión; se llama al ingresar correctamente.
    public static function renovarIdentificador(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }
    }

    // Devuelve true si pasaron más minutos de los permitidos sin actividad.
    public static function vencida(): bool
    {
        if (!isset($_SESSION['ultimoAcceso'])) {
            return false;
        }
        return (time() - (int) $_SESSION['ultimoAcceso']) > (self::MINUTOS_INACTIVIDAD * 60);
    }

    // Registra actividad para reiniciar el conteo de inactividad.
    public static function marcarActividad(): void
    {
        $_SESSION['ultimoAcceso'] = time();
    }

    // Cierra la sesión y borra la cookie.
    public static function cerrar(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $parametros = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $parametros['path']);
        }
        session_destroy();
    }

    // Genera y guarda el token contra CSRF que viaja oculto en los formularios.
    public static function tokenCsrf(): string
    {
        if (empty($_SESSION['tokenCsrf'])) {
            $_SESSION['tokenCsrf'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['tokenCsrf'];
    }

    // Compara el token recibido del formulario con el de la sesión.
    public static function tokenCsrfValido(?string $recibido): bool
    {
        return is_string($recibido)
            && !empty($_SESSION['tokenCsrf'])
            && hash_equals($_SESSION['tokenCsrf'], $recibido);
    }
}
