<?php
// Verificación de credenciales: valida el formulario en el servidor, limita
// los intentos fallidos, controla el estado de la cuenta y compara el hash
// bcrypt. Cada evento queda registrado para que fail2ban bloquee los ataques.

require_once __DIR__ . '/Validador.php';
require_once __DIR__ . '/RegistroSeguridad.php';
require_once __DIR__ . '/../modelos/GestorUsuarios.php';

class ControlAcceso
{
    // Mensaje único para cualquier fallo: no revela si el error fue el correo o la clave.
    const MENSAJE_ERROR = 'Correo o contraseña incorrectos.';

    const MENSAJE_BLOQUEO = 'La cuenta está bloqueada temporalmente por intentos fallidos. Reintentar en 15 minutos.';

    private GestorUsuarios $gestor;
    private RegistroSeguridad $registro;

    public function __construct(?GestorUsuarios $gestor = null, ?RegistroSeguridad $registro = null)
    {
        $this->gestor   = $gestor   ?? new GestorUsuarios();
        $this->registro = $registro ?? new RegistroSeguridad();
    }

    // Devuelve ['ok' => bool, 'mensaje' => string, 'usuario' => Usuario|null].
    public function ingresar($correo, $contrasena, string $ip): array
    {
        $validador = new Validador();
        $correoValido = $validador->email('correo', $correo);
        if ($correoValido === null || !is_string($contrasena) || $contrasena === '') {
            return $this->fallo(is_string($correo) ? $correo : 'desconocido', $ip);
        }

        // Límite de intentos fallidos por cuenta (15 minutos).
        if ($this->registro->estaBloqueado($correoValido)) {
            $this->registro->cuentaBloqueada($correoValido, $ip);
            return ['ok' => false, 'mensaje' => self::MENSAJE_BLOQUEO, 'usuario' => null];
        }

        $usuario = $this->gestor->buscarPorCorreo($correoValido);
        if ($usuario === null) {
            return $this->fallo($correoValido, $ip);
        }

        // Las cuentas dadas de baja (baja lógica) no pueden ingresar.
        if ($usuario->getEstado() !== 'Activo') {
            return $this->fallo($correoValido, $ip);
        }

        // La clave se compara contra el hash; nunca en texto plano.
        if (!$usuario->verificarContrasena($contrasena)) {
            return $this->fallo($correoValido, $ip);
        }

        $this->registro->ingresoCorrecto($correoValido, $ip);
        return ['ok' => true, 'mensaje' => '', 'usuario' => $usuario];
    }

    // Registra el intento fallido y devuelve siempre el mismo mensaje.
    private function fallo(string $usuario, string $ip): array
    {
        $this->registro->intentoFallido($usuario, $ip);
        return ['ok' => false, 'mensaje' => self::MENSAJE_ERROR, 'usuario' => null];
    }
}
