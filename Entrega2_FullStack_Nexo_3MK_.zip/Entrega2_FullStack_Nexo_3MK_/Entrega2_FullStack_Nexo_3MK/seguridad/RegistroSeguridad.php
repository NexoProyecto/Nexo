<?php
// Registro de eventos de acceso. El archivo que genera esta clase es el que
// lee fail2ban para bloquear las IPs con intentos fallidos repetidos, por eso
// cada línea conserva siempre el mismo formato.
class RegistroSeguridad
{
    // Ruta del archivo de registro en el servidor.
    const ARCHIVO = '/var/log/cupcore/acceso.log';

    // Intentos fallidos permitidos antes de bloquear la cuenta.
    const INTENTOS_PERMITIDOS = 5;

    // Ventana de tiempo del bloqueo, en segundos (15 minutos).
    const VENTANA_SEGUNDOS = 900;

    private string $archivo;

    public function __construct(?string $archivo = null)
    {
        $this->archivo = $archivo ?? self::ARCHIVO;
        $carpeta = dirname($this->archivo);
        if (!is_dir($carpeta)) {
            mkdir($carpeta, 0750, true);
        }
    }

    // Deja el valor apto para escribirlo en el registro. El correo llega de un
    // formulario: si conservara espacios o saltos de línea, se podrían escribir
    // líneas falsas en el archivo o hacer que fail2ban no reconozca el intento.
    private function limpiarValor(string $valor): string
    {
        $limpio = preg_replace('/[^A-Za-z0-9@._\-+]/', '_', $valor);
        if ($limpio === '' || $limpio === null) {
            $limpio = 'desconocido';
        }
        return mb_substr($limpio, 0, 120);
    }

    // Escribe una línea con la fecha, el evento, el usuario y la IP.
    private function escribir(string $evento, string $usuario, string $ip): void
    {
        $linea = sprintf(
            "%s CUPCORE %s usuario=%s ip=%s\n",
            gmdate('Y-m-d H:i:s'),
            $evento,
            $this->limpiarValor($usuario),
            $this->limpiarValor($ip)
        );
        file_put_contents($this->archivo, $linea, FILE_APPEND | LOCK_EX);
    }

    public function intentoFallido(string $usuario, string $ip): void
    {
        $this->escribir('LOGIN FALLIDO', $usuario, $ip);
    }

    public function ingresoCorrecto(string $usuario, string $ip): void
    {
        $this->escribir('LOGIN OK', $usuario, $ip);
    }

    public function cuentaBloqueada(string $usuario, string $ip): void
    {
        $this->escribir('CUENTA BLOQUEADA', $usuario, $ip);
    }

    // Cuenta los intentos fallidos de un usuario dentro de la ventana de tiempo.
    public function fallosRecientes(string $usuario): int
    {
        if (!is_readable($this->archivo)) {
            return 0;
        }
        $limite = time() - self::VENTANA_SEGUNDOS;
        $buscado = 'usuario=' . $this->limpiarValor($usuario) . ' ';
        $total = 0;
        foreach (file($this->archivo, FILE_IGNORE_NEW_LINES) as $linea) {
            if (strpos($linea, 'LOGIN FALLIDO') === false) {
                continue;
            }
            if (strpos($linea, $buscado) === false) {
                continue;
            }
            $fecha = strtotime(substr($linea, 0, 19) . ' UTC');
            if ($fecha !== false && $fecha >= $limite) {
                $total++;
            }
        }
        return $total;
    }

    // Devuelve true si la cuenta superó los intentos permitidos.
    public function estaBloqueado(string $usuario): bool
    {
        return $this->fallosRecientes($usuario) >= self::INTENTOS_PERMITIDOS;
    }
}
