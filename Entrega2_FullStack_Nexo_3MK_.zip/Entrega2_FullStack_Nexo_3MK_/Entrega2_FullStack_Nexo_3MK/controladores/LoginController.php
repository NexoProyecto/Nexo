<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../seguridad/ControlAcceso.php';
require_once __DIR__ . '/../seguridad/SesionSegura.php';

// Controller del login. La verificación pasa por ControlAcceso (valida los
// datos, limita intentos y registra los eventos) y el formulario exige el
// token CSRF. Al ingresar se renueva el identificador de sesión.
class LoginController extends ControladorBase
{
    public function index(): void
    {
        // Si ya inició sesión, va directo a su panel.
        if ($this->estaLogueado()) {
            $this->redirigirSegunRol();
        }

        $error = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!SesionSegura::tokenCsrfValido($_POST['tokenCsrf'] ?? null)) {
                $error = 'La página expiró. Recargar e intentar de nuevo.';
            } else {
                $control = new ControlAcceso();
                $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

                $resultado = $control->ingresar(
                    $_POST['correo'] ?? '',
                    $_POST['contrasena'] ?? '',
                    $ip
                );

                if ($resultado['ok']) {
                    $usuario = $resultado['usuario'];

                    // Identificador de sesión nuevo para el usuario autenticado.
                    SesionSegura::renovarIdentificador();

                    // En la sesión solo se guardan datos de identificación, nunca la clave.
                    $_SESSION['usuario'] = [
                        'id'     => $usuario->getId(),
                        'nombre' => $usuario->getNombre(),
                        'correo' => $usuario->getCorreo(),
                        'rol'    => $usuario->getRol(),
                    ];
                    SesionSegura::marcarActividad();

                    $this->redirigirSegunRol();
                }

                $error = $resultado['mensaje'];
            }
        }

        $this->renderizarVista('login', [
            'error'     => $error,
            'tokenCsrf' => SesionSegura::tokenCsrf(),
        ]);
    }
}
