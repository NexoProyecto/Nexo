<?php
// Clase padre de todos los controladores: renderiza vistas, redirige
// rutas internas y controla el acceso según el rol.
abstract class ControladorBase
{
    // Carga una vista y le pasa los datos.
    protected function renderizarVista(string $vista, array $datos = []): void
    {
        extract($datos);
        require __DIR__ . '/../vistas/' . $vista . '.php';
    }

    // Redirige a una ruta interna (ej: redirigir('admin')).
    protected function redirigir(string $ruta): void
    {
        header('Location: index.php?ruta=' . $ruta);
        exit;
    }

    // true si hay una sesión iniciada.
    protected function estaLogueado(): bool
    {
        return isset($_SESSION['usuario']);
    }

    // Permite seguir solo con sesión y el rol indicado; si no, al login.
    protected function requiereRol(string $rol): void
    {
        if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== $rol) {
            $this->redirigir('login');
        }
    }

    // Manda a cada usuario autenticado a su propio panel según el rol.
    protected function redirigirSegunRol(): void
    {
        switch ($_SESSION['usuario']['rol']) {
            case 'Administrador general':
                $this->redirigir('admin');
            case 'Organizador de torneo':
                $this->redirigir('organizador');
            default:
                $this->redirigir('participante');
        }
    }
}