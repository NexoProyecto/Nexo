<?php
require_once __DIR__ . '/ControladorBase.php';

class OrganizadorController extends ControladorBase
{
    public function index(): void
    {
        $this->requiereRol('Organizador de torneo');

        $this->renderizarVista('organizador', [
            'usuario' => $_SESSION['usuario'],
        ]);
    }
}