<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../modelos/GestorTorneos.php';

class InicioController extends ControladorBase
{
    public function index(): void
    {
        $gestor = new GestorTorneos();

        $this->renderizarVista('inicio', [
            'torneos'    => $gestor->listarTorneosPortada(3),
            'posiciones' => $gestor->listarPosiciones(1),
            'stats'      => $gestor->estadisticas(),
            'usuario'    => $_SESSION['usuario'] ?? null,
        ]);
    }
}