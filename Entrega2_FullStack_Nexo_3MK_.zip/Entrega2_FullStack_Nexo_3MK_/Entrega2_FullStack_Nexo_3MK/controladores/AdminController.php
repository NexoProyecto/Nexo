<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../modelos/GestorUsuarios.php';
require_once __DIR__ . '/../seguridad/Validador.php';
require_once __DIR__ . '/../seguridad/SesionSegura.php';

// Panel del administrador general. El alta y la baja de usuarios se validan
// en el servidor, el rol contra una lista cerrada y las dos acciones exigen
// el token CSRF.
class AdminController extends ControladorBase
{
    // Roles que el administrador puede asignar.
    private const ROLES = ['Administrador general', 'Organizador de torneo', 'Participante'];

    public function index(): void
    {
        $this->requiereRol('Administrador general');

        $gestor = new GestorUsuarios();

        $this->renderizarVista('admin', [
            'usuario'   => $_SESSION['usuario'],
            'usuarios'  => $gestor->listarUsuarios(),
            'tokenCsrf' => SesionSegura::tokenCsrf(),
            'aviso'     => $_SESSION['aviso'] ?? '',
        ]);
        unset($_SESSION['aviso']);
    }

    // Crea un usuario (llega por POST desde el formulario del panel).
    public function crearUsuario(): void
    {
        $this->requiereRol('Administrador general');

        if (!SesionSegura::tokenCsrfValido($_POST['tokenCsrf'] ?? null)) {
            $_SESSION['aviso'] = 'La página expiró. Recargar e intentar de nuevo.';
            $this->redirigir('admin');
        }

        $validador  = new Validador();
        $nombre     = $validador->texto('nombre', $_POST['nombre'] ?? '', 2, 60);
        $correo     = $validador->email('correo', $_POST['correo'] ?? '');
        $contrasena = $validador->clave('contrasena', $_POST['contrasena'] ?? '');
        $rol        = $validador->opcion('rol', $_POST['rol'] ?? 'Participante', self::ROLES);

        if ($validador->hayErrores()) {
            $_SESSION['aviso'] = 'No se pudo crear el usuario: '
                . implode(' ', $validador->errores());
            $this->redirigir('admin');
        }

        $gestor = new GestorUsuarios();
        $creado = $gestor->crearUsuario($nombre, $correo, $contrasena, $rol);

        $_SESSION['aviso'] = $creado
            ? 'Usuario creado correctamente.'
            : 'No se pudo crear el usuario: el correo ya esta registrado.';

        $this->redirigir('admin');
    }

    // Elimina un usuario según su id, que llega por GET (?id=N).
    public function eliminarUsuario(): void
    {
        $this->requiereRol('Administrador general');

        if (!SesionSegura::tokenCsrfValido($_GET['tokenCsrf'] ?? null)) {
            $_SESSION['aviso'] = 'Accion no autorizada.';
            $this->redirigir('admin');
        }

        $validador = new Validador();
        $id = $validador->entero('id', $_GET['id'] ?? '');

        if ($id === null) {
            $_SESSION['aviso'] = 'El identificador del usuario no es valido.';
            $this->redirigir('admin');
        }

        // Un administrador no puede darse de baja a sí mismo: el sistema quedaría
        // sin administrador activo.
        if ((string) $id === (string) $_SESSION['usuario']['id']) {
            $_SESSION['aviso'] = 'La cuenta en uso no se puede dar de baja.';
            $this->redirigir('admin');
        }

        $gestor = new GestorUsuarios();
        $gestor->eliminarUsuario((string) $id);
        $_SESSION['aviso'] = 'Usuario dado de baja.';

        $this->redirigir('admin');
    }
}
