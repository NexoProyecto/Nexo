<?php
// Conexión a la base CupCore. El usuario cupcoreapp se crea en BD_CupCore.sql
// (bloque DCL) y solo tiene permisos SELECT, INSERT, UPDATE y DELETE.
// El puerto de la base es 3307 en este equipo; si el servidor usa 3306,
// cambiar solo esta línea.
define('DB_HOST',    'localhost');
define('DB_PORT',    '3307');
define('DB_NAME',    'CupCore');
define('DB_USER',    'cupcoreapp');
define('DB_PASS',    'Cambiar-App-2026');
define('DB_CHARSET', 'utf8mb4');
