--  CupCore - Datos de prueba para poblar la base (VERSION REDUCIDA - 2da entrega)
--  Recorte: se conservan los primeros registros de cada tabla y se eliminan
--  las filas que dependian de los registros quitados. La base queda consistente.
--  Para la 3ra entrega se usa el archivo completo (minimo 50 registros).
--  Se ejecuta DESPUES de BD_CupCore.sql
--  Todos los usuarios tienen la contrasena: CupCore2026$
--  (hash bcrypt con costo 12; '1234' no cumplia la politica de contrasenas)

USE CupCore;

SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE AuditoriaRegistro;
TRUNCATE TABLE TablaPosiciones;
TRUNCATE TABLE Resultado;
TRUNCATE TABLE Enfrentamiento;
TRUNCATE TABLE Ronda;
TRUNCATE TABLE Inscripcion;
TRUNCATE TABLE Configura;
TRUNCATE TABLE Torneo;
TRUNCATE TABLE Integra;
TRUNCATE TABLE Vincula;
TRUNCATE TABLE Equipo;
TRUNCATE TABLE Participante;
TRUNCATE TABLE Usuario;
SET FOREIGN_KEY_CHECKS = 1;

-- ================= USUARIO (20) =================
-- 1 administrador, 6 organizadores y 53 participantes.
INSERT INTO Usuario (IdUsuario, Nombre, Apellido, Email, Password, Estado, FechaAlta, IdRol) VALUES
(1, 'Admin', 'CupCore', 'admin@cupcore.com', '$2y$12$bwQ0QGCx8ajI2WUzy1wctONIFfkmZcWQ.5sr/Nrm4jdw/fMsVqNo2', 'ACTIVO', '2026-03-03', 1),
(2, 'Roberto', 'Franco', 'rfranco@cupcore.com', '$2y$12$6WEUwVq9qyWwGtmunIW90uAHHkQnXhGxx1IsPaMZ4DoROcVW/4vK.', 'ACTIVO', '2026-03-05', 2),
(3, 'Sofia', 'Garcia', 'sofia@cupcore.com', '$2y$12$yGIcMic01YI030cQZvXYsuyKkpl9sgEHwTfKfhpfM6M1UDuPkDDk6', 'ACTIVO', '2026-03-07', 3),
(4, 'Agustin', 'Maya', 'agustin@cupcore.com', '$2y$12$DXx8I2TUJ6rDzg8e7PN9YOnCcw9fjhs/mO3oz0HdF985gocrNM/Sq', 'ACTIVO', '2026-03-09', 3),
(5, 'Florencia', 'Lopez', 'florencia.lopez4@cupcore.com', '$2y$12$ivtxd.mIVoCrA.XsLjZtwuKCrqwXcG5k.fLlCdzC7TH18w3Rpu3rK', 'ACTIVO', '2026-03-11', 2),
(6, 'Federico', 'Nunez', 'federico.nunez5@cupcore.com', '$2y$12$IQb.SIGYQluP/xi9ySq13eIWtOOLBS3dTyO8Hfc3LF5ILW2KmVvUu', 'ACTIVO', '2026-03-13', 2),
(7, 'Mateo', 'Fernandez', 'mateo.fernandez6@cupcore.com', '$2y$12$WvCXYwQd48FOIuHkjuxmQ.vuEiMmzJ1MR5ky/Q/YBNHSqGZdwU9ve', 'ACTIVO', '2026-03-15', 2),
(8, 'Carolina', 'Ferreira', 'carolina.ferreira7@cupcore.com', '$2y$12$NOjmcoeK29C2qHlMs4fMsOD2nkeCvH4ULr0uv9.lA5mz58lYzK.J.', 'ACTIVO', '2026-03-17', 2),
(9, 'Lucia', 'Suarez', 'lucia.suarez8@cupcore.com', '$2y$12$PLe1ex/aEib5SPoUkGmxJ.kMnwJB7LCvIRMGmyGbXHX6qr5x4FXQi', 'ACTIVO', '2026-03-19', 2),
(10, 'Maximo', 'Rodriguez', 'maximo.rodriguez9@cupcore.com', '$2y$12$sUuJLnk54IV/Vc/RgSjHdOYjxa.h9FRDuT7NMq17TG58HzO0KGv7C', 'ACTIVO', '2026-03-21', 3),
(11, 'Aitana', 'Correa', 'aitana.correa10@cupcore.com', '$2y$12$qUA5W24RnzI1RsCo9T2oRed8bJYPIMJfUOMVz9Kp8rGfn5NQll.u2', 'ACTIVO', '2026-03-23', 3),
(12, 'Nicolas', 'Rodriguez', 'nicolas.rodriguez11@cupcore.com', '$2y$12$J94cWBoNYlqhdkqgEEOaQ.2OD9jJ/ezLfMTzjkv5p7AIkotG7gvra', 'ACTIVO', '2026-03-25', 3),
(13, 'Joaquin', 'Cabrera', 'joaquin.cabrera12@cupcore.com', '$2y$12$uLI5OjLYPzBLDXQs8diaTOohmtKVUZ5u9IoNBuOIlcm08mUTI9U9a', 'ACTIVO', '2026-03-27', 3),
(14, 'Antonella', 'Fernandez', 'antonella.fernandez13@cupcore.com', '$2y$12$bnSr4WNU9Dgy/vT0IkWauO0oUQ0rlbtZdspajoPr0ECa4Ag/Bu8l2', 'ACTIVO', '2026-03-29', 3),
(15, 'Thiago', 'Fernandez', 'thiago.fernandez14@cupcore.com', '$2y$12$7WxasOg/geAgE0PQmHfyg.c213xS2JFO.xAF5N/EQLqj8HVcgNF.S', 'ACTIVO', '2026-03-31', 3),
(16, 'Lautaro', 'Cabrera', 'lautaro.cabrera15@cupcore.com', '$2y$12$WlQaHdblSyGC4Z2ceAvHdO6tseFoBe3pHlnHB/lta566kxF2qbhbO', 'ACTIVO', '2026-04-02', 3),
(17, 'Mateo', 'Fagundez', 'mateo.fagundez16@cupcore.com', '$2y$12$JuUzhWu.T6AxfxYw7Euo.OscUB/1kuWCVEWUk7EOvQpLV43fJOLCy', 'ACTIVO', '2026-04-04', 3),
(18, 'Abril', 'Martinez', 'abril.martinez17@cupcore.com', '$2y$12$rKggk/9wPcP/FLoUmrGwleVM1/2DeNt1gmS2Ga6UplvSRbwwwRkg6', 'ACTIVO', '2026-04-06', 3),
(19, 'Renata', 'Nunez', 'renata.nunez18@cupcore.com', '$2y$12$8lzzbGUqlwDmkMVn4StVSeccf3w3GqCw8GY8EdYru6zWzyrnnWe3G', 'ACTIVO', '2026-04-08', 3),
(20, 'Zoe', 'Machado', 'zoe.machado19@cupcore.com', '$2y$12$.1y1rHsyzSSZYAGU6S1GGeKnPuN9Q6wAI4bjFIBYuSLl/Qo7TT3rS', 'ACTIVO', '2026-04-10', 3);

-- ================= EQUIPO (12) =================
INSERT INTO Equipo (IdEquipo, NombreEquipo, PerfilPublico, FechaCreacion) VALUES
(1, 'Los Halcones', TRUE, '2026-02-11'),
(2, 'Nexo FC', TRUE, '2026-03-12'),
(3, 'Atletico Sur', TRUE, '2026-04-13'),
(4, 'Deportivo Norte', TRUE, '2026-05-14'),
(5, 'Los Tiburones', TRUE, '2026-06-15'),
(6, 'Real Progreso', TRUE, '2026-07-16'),
(7, 'Club Aurora', TRUE, '2026-08-17'),
(8, 'Las Panteras', TRUE, '2026-01-18'),
(9, 'Team Alpha', TRUE, '2026-02-10'),
(10, 'Black Dragons', TRUE, '2026-03-11'),
(11, 'Cyber Wolves', TRUE, '2026-04-12'),
(12, 'Fenix eSports', TRUE, '2026-05-13');

-- ================= PARTICIPANTE (20) =================
-- Los 12 primeros representan al equipo en los torneos por equipos;
-- los 48 restantes son competidores individuales.
INSERT INTO Participante (IdParticipante, NombreParticipante, Alias, FechaNacimiento, PerfilPublico) VALUES
(1, 'Los Halcones', 'Halcones', NULL, TRUE),
(2, 'Nexo FC', 'FC', NULL, TRUE),
(3, 'Atletico Sur', 'Sur', NULL, TRUE),
(4, 'Deportivo Norte', 'Norte', NULL, TRUE),
(5, 'Los Tiburones', 'Tiburones', NULL, TRUE),
(6, 'Real Progreso', 'Progreso', NULL, TRUE),
(7, 'Club Aurora', 'Aurora', NULL, TRUE),
(8, 'Las Panteras', 'Panteras', NULL, TRUE),
(9, 'Team Alpha', 'Alpha', NULL, TRUE),
(10, 'Black Dragons', 'Dragons', NULL, TRUE),
(11, 'Cyber Wolves', 'Wolves', NULL, TRUE),
(12, 'Fenix eSports', 'eSports', NULL, TRUE),
(13, 'Sofia Garcia', 'Sof3', '2008-04-26', TRUE),
(14, 'Agustin Maya', 'Agu4', '2008-06-02', TRUE),
(15, 'Maximo Rodriguez', 'Max10', '2008-07-09', TRUE),
(16, 'Aitana Correa', 'Ait11', '2008-08-15', TRUE),
(17, 'Nicolas Rodriguez', 'Nic12', '2008-09-21', TRUE),
(18, 'Joaquin Cabrera', 'Joa13', '2008-10-28', TRUE),
(19, 'Antonella Fernandez', 'Ant14', '2008-12-04', TRUE),
(20, 'Thiago Fernandez', 'Thi15', '2009-01-10', TRUE);

-- ================= VINCULA (8) =================
-- Relacion 1 a 1 sin totalidad: solo los participantes que ademas
-- tienen cuenta en el sistema aparecen aca.
INSERT INTO Vincula (IdParticipante, IdUsuario) VALUES
(13, 3),
(14, 4),
(15, 10),
(16, 11),
(17, 12),
(18, 13),
(19, 14),
(20, 15);

-- ================= INTEGRA (20) =================
-- Relacion N a N: que participantes integran cada equipo.
INSERT INTO Integra (IdParticipante, IdEquipo, FechaIngreso) VALUES
(1, 1, '2026-02-11'),
(2, 2, '2026-02-12'),
(3, 3, '2026-02-13'),
(4, 4, '2026-02-14'),
(5, 5, '2026-02-15'),
(6, 6, '2026-02-16'),
(7, 7, '2026-02-17'),
(8, 8, '2026-02-18'),
(9, 9, '2026-02-10'),
(10, 10, '2026-02-11'),
(11, 11, '2026-02-12'),
(12, 12, '2026-02-13'),
(13, 1, '2026-03-01'),
(14, 2, '2026-03-02'),
(15, 3, '2026-03-03'),
(16, 4, '2026-03-04'),
(17, 5, '2026-03-05'),
(18, 6, '2026-03-06'),
(19, 7, '2026-03-07'),
(20, 8, '2026-03-08');

-- ================= TORNEO (5) =================
INSERT INTO Torneo (IdTorneo, NombreTorneo, FechaInicio, FechaFin, Estado, IdTipoTorneo, IdUsuario) VALUES
(1, 'Copa Invierno Futbol 7', '2026-05-24', '2026-06-14', 'EN CURSO', 1, 2),
(2, 'Torneo Apertura eSports', '2026-05-18', '2026-05-30', 'FINALIZADO', 3, 2),
(3, 'Abierto de Ajedrez', '2026-06-01', '2026-06-21', 'EN CURSO', 2, 2),
(5, 'Copa Primavera Futbol 5', '2026-09-05', '2026-09-27', 'BORRADOR', 1, 6),
(8, 'Copa Clausura Basquetbol', '2026-10-04', '2026-10-25', 'ABIERTO', 1, 5);

-- ================= CONFIGURA (5) =================
-- Relacion N a N entre Torneo y ModuloCompetencia, con sus reglas.
INSERT INTO Configura (IdTorneo, IdModulo, ReglasEspecificas, Habilitado) VALUES
(1, 1, '3 puntos por victoria, 1 por empate, 0 por derrota', TRUE),
(2, 2, 'Llaves de eliminacion directa, sin empates', TRUE),
(3, 3, '1 punto por victoria, 0.5 por empate, desempate Buchholz', TRUE),
(5, 2, 'Llaves de eliminacion directa, sin empates', TRUE),
(8, 2, 'Llaves de eliminacion directa, sin empates', TRUE);

-- ================= INSCRIPCION (30) =================
INSERT INTO Inscripcion (IdInscripcion, FechaInscripcion, EstadoInscripcion, IdTorneo, IdParticipante) VALUES
(1, '2026-05-13', 'ACEPTADA', 1, 1),
(2, '2026-05-12', 'ACEPTADA', 1, 2),
(3, '2026-05-11', 'ACEPTADA', 1, 3),
(4, '2026-05-10', 'ACEPTADA', 1, 4),
(5, '2026-05-09', 'ACEPTADA', 1, 5),
(6, '2026-05-08', 'ACEPTADA', 1, 6),
(7, '2026-05-08', 'ACEPTADA', 2, 9),
(8, '2026-05-07', 'ACEPTADA', 2, 10),
(9, '2026-05-06', 'ACEPTADA', 2, 11),
(10, '2026-05-05', 'ACEPTADA', 2, 12),
(11, '2026-05-18', 'ACEPTADA', 3, 13),
(12, '2026-05-17', 'ACEPTADA', 3, 14),
(13, '2026-05-16', 'ACEPTADA', 3, 15),
(14, '2026-05-22', 'ACEPTADA', 3, 16),
(15, '2026-05-21', 'ACEPTADA', 3, 17),
(16, '2026-05-20', 'ACEPTADA', 3, 18),
(17, '2026-05-19', 'ACEPTADA', 3, 19),
(18, '2026-05-18', 'ACEPTADA', 3, 20),
(31, '2026-08-23', 'ACEPTADA', 5, 5),
(32, '2026-08-22', 'ACEPTADA', 5, 6),
(33, '2026-08-21', 'ACEPTADA', 5, 1),
(34, '2026-08-20', 'ACEPTADA', 5, 2),
(35, '2026-08-26', 'ACEPTADA', 5, 7),
(36, '2026-08-25', 'ACEPTADA', 5, 8),
(55, '2026-09-18', 'PENDIENTE', 8, 7),
(56, '2026-09-24', 'ACEPTADA', 8, 8),
(57, '2026-09-23', 'ACEPTADA', 8, 9),
(58, '2026-09-22', 'ACEPTADA', 8, 10),
(59, '2026-09-21', 'ACEPTADA', 8, 11),
(60, '2026-09-20', 'PENDIENTE', 8, 12);

-- ================= RONDA (15) =================
-- Entidad debil: su clave es IdTorneo + NumeroRonda.
INSERT INTO Ronda (IdTorneo, NumeroRonda, EstadoRonda, FechaProgramada) VALUES
(1, 1, 'CERRADA', '2026-05-24'),
(1, 2, 'CERRADA', '2026-05-31'),
(1, 3, 'CERRADA', '2026-06-07'),
(1, 4, 'CERRADA', '2026-06-14'),
(1, 5, 'EN CURSO', '2026-06-21'),
(2, 1, 'CERRADA', '2026-05-18'),
(2, 2, 'CERRADA', '2026-05-25'),
(3, 1, 'CERRADA', '2026-06-01'),
(3, 2, 'EN CURSO', '2026-06-08'),
(3, 3, 'PENDIENTE', '2026-06-15'),
(3, 4, 'PENDIENTE', '2026-06-22'),
(3, 5, 'PENDIENTE', '2026-06-29'),
(8, 1, 'PENDIENTE', '2026-10-04'),
(8, 2, 'PENDIENTE', '2026-10-11'),
(8, 3, 'PENDIENTE', '2026-10-18');

-- ================= ENFRENTAMIENTO (27) =================
INSERT INTO Enfrentamiento (IdEnfrentamiento, FechaHora, EstadoPartido, IdTorneo, NumeroRonda, IdInscripcionLocal, IdInscripcionVisitante) VALUES
(1, '2026-05-24 15:00:00', 'JUGADO', 1, 1, 1, 2),
(2, '2026-05-24 16:00:00', 'JUGADO', 1, 1, 4, 6),
(3, '2026-05-24 17:00:00', 'JUGADO', 1, 1, 3, 5),
(4, '2026-05-31 18:00:00', 'JUGADO', 1, 2, 6, 2),
(5, '2026-05-31 14:00:00', 'JUGADO', 1, 2, 5, 1),
(6, '2026-05-31 15:00:00', 'JUGADO', 1, 2, 4, 3),
(7, '2026-06-07 16:00:00', 'JUGADO', 1, 3, 6, 1),
(8, '2026-06-07 17:00:00', 'JUGADO', 1, 3, 5, 2),
(9, '2026-06-07 18:00:00', 'JUGADO', 1, 3, 3, 4),
(10, '2026-06-14 14:00:00', 'JUGADO', 1, 4, 2, 3),
(11, '2026-06-14 15:00:00', 'JUGADO', 1, 4, 1, 5),
(12, '2026-06-14 16:00:00', 'JUGADO', 1, 4, 6, 4),
(13, '2026-06-21 17:00:00', 'JUGADO', 1, 5, 1, 6),
(14, '2026-06-21 18:00:00', 'JUGADO', 1, 5, 2, 4),
(15, '2026-06-21 14:00:00', 'JUGADO', 1, 5, 3, 5),
(16, '2026-05-18 15:00:00', 'JUGADO', 2, 1, 9, 10),
(17, '2026-05-18 16:00:00', 'JUGADO', 2, 1, 7, 8),
(18, '2026-05-25 17:00:00', 'JUGADO', 2, 2, 9, 8),
(19, '2026-05-25 18:00:00', 'JUGADO', 2, 2, 10, 7),
(21, '2026-06-01 15:00:00', 'JUGADO', 3, 1, 12, 14),
(23, '2026-06-01 17:00:00', 'JUGADO', 3, 1, 17, 18),
(25, '2026-06-01 14:00:00', 'JUGADO', 3, 1, 13, 16),
(27, '2026-06-08 16:00:00', 'JUGADO', 3, 2, 14, 16),
(29, '2026-06-08 18:00:00', 'JUGADO', 3, 2, 15, 13),
(67, '2026-10-04 16:00:00', 'PROGRAMADO', 8, 1, 57, 58),
(68, '2026-10-04 17:00:00', 'PROGRAMADO', 8, 1, 56, 55),
(69, '2026-10-04 18:00:00', 'PROGRAMADO', 8, 1, 60, 59);

-- ================= RESULTADO (24) =================
INSERT INTO Resultado (IdResultado, PuntuacionLocal, PuntuacionVisitante, Ganador, Validado, IdEnfrentamiento) VALUES
(1, 4, 3, 'LOCAL', TRUE, 1),
(2, 4, 3, 'LOCAL', TRUE, 2),
(3, 0, 0, 'EMPATE', TRUE, 3),
(4, 4, 3, 'LOCAL', TRUE, 4),
(5, 2, 3, 'VISITANTE', TRUE, 5),
(6, 2, 0, 'LOCAL', TRUE, 6),
(7, 3, 0, 'LOCAL', TRUE, 7),
(8, 1, 2, 'VISITANTE', TRUE, 8),
(9, 1, 1, 'EMPATE', TRUE, 9),
(10, 3, 3, 'EMPATE', TRUE, 10),
(11, 4, 2, 'LOCAL', TRUE, 11),
(12, 1, 3, 'VISITANTE', TRUE, 12),
(13, 1, 1, 'EMPATE', TRUE, 13),
(14, 0, 1, 'VISITANTE', TRUE, 14),
(15, 1, 1, 'EMPATE', TRUE, 15),
(16, 4, 1, 'LOCAL', TRUE, 16),
(17, 3, 2, 'LOCAL', TRUE, 17),
(18, 4, 2, 'LOCAL', TRUE, 18),
(19, 5, 4, 'LOCAL', TRUE, 19),
(21, 3, 3, 'EMPATE', TRUE, 21),
(23, 0, 1, 'VISITANTE', TRUE, 23),
(25, 0, 2, 'VISITANTE', TRUE, 25),
(27, 1, 2, 'VISITANTE', TRUE, 27),
(29, 2, 3, 'VISITANTE', TRUE, 29);

-- ================= TABLAPOSICIONES (30) =================
-- Hereda las dos claves de la agregacion: IdTorneo e IdInscripcion.
INSERT INTO TablaPosiciones (IdPosicion, PartidosJugados, Victorias, Empates, Derrotas, PuntosAcumulados, IdTorneo, IdInscripcion) VALUES
(1, 5, 3, 1, 1, 10, 1, 1),
(2, 5, 1, 1, 3, 4, 1, 2),
(3, 5, 0, 4, 1, 4, 1, 3),
(4, 5, 4, 1, 0, 13, 1, 4),
(5, 5, 0, 2, 3, 2, 1, 5),
(6, 5, 2, 1, 2, 7, 1, 6),
(7, 2, 1, 0, 1, 3, 2, 7),
(8, 2, 0, 0, 2, 0, 2, 8),
(9, 2, 2, 0, 0, 6, 2, 9),
(10, 2, 1, 0, 1, 3, 2, 10),
(11, 2, 1, 1, 0, 4, 3, 11),
(12, 2, 0, 2, 0, 2, 3, 12),
(13, 2, 1, 0, 1, 3, 3, 13),
(14, 2, 0, 1, 1, 1, 3, 14),
(15, 2, 0, 0, 2, 0, 3, 15),
(16, 2, 2, 0, 0, 6, 3, 16),
(17, 2, 0, 0, 2, 0, 3, 17),
(18, 2, 1, 0, 1, 3, 3, 18),
(31, 0, 0, 0, 0, 0, 5, 31),
(32, 0, 0, 0, 0, 0, 5, 32),
(33, 0, 0, 0, 0, 0, 5, 33),
(34, 0, 0, 0, 0, 0, 5, 34),
(35, 0, 0, 0, 0, 0, 5, 35),
(36, 0, 0, 0, 0, 0, 5, 36),
(55, 0, 0, 0, 0, 0, 8, 55),
(56, 0, 0, 0, 0, 0, 8, 56),
(57, 0, 0, 0, 0, 0, 8, 57),
(58, 0, 0, 0, 0, 0, 8, 58),
(59, 0, 0, 0, 0, 0, 8, 59),
(60, 0, 0, 0, 0, 0, 8, 60);

-- ================= AUDITORIAREGISTRO (20) =================
INSERT INTO AuditoriaRegistro (IdAuditoria, AccionRealizada, TablaAfectada, FechaHora, IpOrigen, IdUsuario) VALUES
(1, 'MODIFICACION', 'Torneo', '2026-02-11 09:07:00', '192.168.1.11', 2),
(2, 'BAJA', 'Inscripcion', '2026-03-12 10:14:00', '192.168.1.12', 3),
(3, 'LOGIN', 'Resultado', '2026-04-13 11:21:00', '192.168.1.13', 4),
(4, 'LOGOUT', 'Enfrentamiento', '2026-05-14 12:28:00', '192.168.1.14', 5),
(5, 'ALTA', 'Ronda', '2026-06-15 13:35:00', '192.168.1.15', 6),
(6, 'MODIFICACION', 'Usuario', '2026-07-16 14:42:00', '192.168.1.16', 7),
(7, 'BAJA', 'Torneo', '2026-08-17 15:49:00', '192.168.1.17', 8),
(8, 'LOGIN', 'Inscripcion', '2026-09-18 16:56:00', '192.168.1.18', 9),
(9, 'LOGOUT', 'Resultado', '2026-01-19 17:03:00', '192.168.1.19', 1),
(10, 'ALTA', 'Enfrentamiento', '2026-02-20 18:10:00', '192.168.1.20', 1),
(11, 'MODIFICACION', 'Ronda', '2026-03-21 19:17:00', '192.168.1.21', 3),
(12, 'BAJA', 'Usuario', '2026-04-22 08:24:00', '192.168.1.22', 4),
(13, 'LOGIN', 'Torneo', '2026-05-23 09:31:00', '192.168.1.23', 5),
(14, 'LOGOUT', 'Inscripcion', '2026-06-24 10:38:00', '192.168.1.24', 6),
(15, 'ALTA', 'Resultado', '2026-07-25 11:45:00', '192.168.1.25', 7),
(16, 'MODIFICACION', 'Enfrentamiento', '2026-08-26 12:52:00', '192.168.1.26', 8),
(17, 'BAJA', 'Ronda', '2026-09-27 13:59:00', '192.168.1.27', 9),
(18, 'LOGIN', 'Usuario', '2026-01-10 14:06:00', '192.168.1.28', 1),
(19, 'LOGOUT', 'Torneo', '2026-02-11 15:13:00', '192.168.1.29', 2),
(20, 'ALTA', 'Inscripcion', '2026-03-12 16:20:00', '192.168.1.30', 1);

