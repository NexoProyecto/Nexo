--  Consultas de la base de datos
use CupCore;

-- una sola tabla

-- Todos los torneos, con todas sus columnas
select * from Torneo;


-- Solo algunas columnas y solo las filas que cumplen una condicion
select NombreTorneo, FechaInicio, FechaFin, Estado
from Torneo
where Estado = 'EN CURSO';


-- Cuantos usuarios hay cargados
select count(*) as CantidadUsuarios
from Usuario;


-- Cuantas inscripciones fueron aceptadas
select count(*) as InscripcionesAceptadas
from Inscripcion
where EstadoInscripcion = 'ACEPTADA';


-- Participantes ordenados por nombre
select NombreParticipante, Alias
from Participante
order by NombreParticipante;


-- Buscar por parte del texto
select NombreTorneo, Estado
from Torneo
where NombreTorneo like '%Ajedrez%';

-- dos tablas

-- Cada usuario con el nombre de su rol
select Usuario.Nombre, Usuario.Apellido, Usuario.Email, Rol.NombreRol
from Usuario
inner join Rol on Usuario.IdRol = Rol.IdRol
order by Rol.NombreRol;


-- Cada torneo con su disciplina
select Torneo.NombreTorneo, TipoTorneo.NombreTipo, Torneo.Estado
from Torneo
inner join TipoTorneo on Torneo.IdTipoTorneo = TipoTorneo.IdTipoTorneo
order by Torneo.FechaInicio;


-- Quienes estan inscriptos en el torneo 1.
select Participante.NombreParticipante, Inscripcion.EstadoInscripcion
from Inscripcion
inner join Participante on Inscripcion.IdParticipante = Participante.IdParticipante
where Inscripcion.IdTorneo = 1;

-- tres o mas bajas

-- Torneo, disciplina y organizador
select Torneo.NombreTorneo,
       TipoTorneo.NombreTipo,
       Usuario.Nombre,
       Usuario.Apellido,
       Torneo.Estado
from Torneo
inner join TipoTorneo on Torneo.IdTipoTorneo = TipoTorneo.IdTipoTorneo
inner join Usuario    on Torneo.IdUsuario    = Usuario.IdUsuario
order by Torneo.FechaInicio;


-- Modulo de competencia de cada torneo
select Torneo.NombreTorneo,
       ModuloCompetencia.NombreModulo,
       Configura.ReglasEspecificas
from Torneo
inner join Configura         on Torneo.IdTorneo    = Configura.IdTorneo
inner join ModuloCompetencia on Configura.IdModulo = ModuloCompetencia.IdModulo;


-- Tabla de posiciones del torneo 1
select Participante.NombreParticipante,
       TablaPosiciones.PartidosJugados,
       TablaPosiciones.Victorias,
       TablaPosiciones.Empates,
       TablaPosiciones.Derrotas,
       TablaPosiciones.PuntosAcumulados
from TablaPosiciones
inner join Inscripcion  on TablaPosiciones.IdInscripcion = Inscripcion.IdInscripcion
inner join Participante on Inscripcion.IdParticipante    = Participante.IdParticipante
where TablaPosiciones.IdTorneo = 1
order by TablaPosiciones.PuntosAcumulados desc;


-- Calendario de partidos que todavia no se jugaron
select Torneo.NombreTorneo,
       Enfrentamiento.NumeroRonda,
       Enfrentamiento.FechaHora,
       PartLocal.NombreParticipante  as Local,
       PartVisita.NombreParticipante as Visitante
from Enfrentamiento
inner join Torneo       on Enfrentamiento.IdTorneo = Torneo.IdTorneo
inner join Inscripcion  InsLocal   on Enfrentamiento.IdInscripcionLocal = InsLocal.IdInscripcion
inner join Participante PartLocal  on InsLocal.IdParticipante           = PartLocal.IdParticipante
inner join Inscripcion  InsVisita  on Enfrentamiento.IdInscripcionVisitante = InsVisita.IdInscripcion
inner join Participante PartVisita on InsVisita.IdParticipante          = PartVisita.IdParticipante
where Enfrentamiento.EstadoPartido = 'PROGRAMADO'
order by Enfrentamiento.FechaHora;


-- Resultados cargados, con el marcador
select Torneo.NombreTorneo,
       PartLocal.NombreParticipante  as Local,
       Resultado.PuntuacionLocal,
       Resultado.PuntuacionVisitante,
       PartVisita.NombreParticipante as Visitante,
       Resultado.Ganador
from Resultado
inner join Enfrentamiento on Resultado.IdEnfrentamiento = Enfrentamiento.IdEnfrentamiento
inner join Torneo         on Enfrentamiento.IdTorneo    = Torneo.IdTorneo
inner join Inscripcion  InsLocal   on Enfrentamiento.IdInscripcionLocal = InsLocal.IdInscripcion
inner join Participante PartLocal  on InsLocal.IdParticipante           = PartLocal.IdParticipante
inner join Inscripcion  InsVisita  on Enfrentamiento.IdInscripcionVisitante = InsVisita.IdInscripcion
inner join Participante PartVisita on InsVisita.IdParticipante          = PartVisita.IdParticipante
order by Enfrentamiento.FechaHora desc;

-- left join

-- Todos los participantes
select Participante.NombreParticipante, Vincula.IdUsuario
from Participante
left join Vincula on Participante.IdParticipante = Vincula.IdParticipante
order by Participante.NombreParticipante;


-- Solo los participantes que no tienen cuenta de usuario
select Participante.IdParticipante, Participante.NombreParticipante
from Participante
left join Vincula on Participante.IdParticipante = Vincula.IdParticipante
where Vincula.IdUsuario is null;

-- group by, agrupar filas

-- Cuantos inscriptos tiene cada torneo
select Torneo.NombreTorneo, count(*) as Inscriptos
from Inscripcion
inner join Torneo on Inscripcion.IdTorneo = Torneo.IdTorneo
group by Torneo.NombreTorneo
order by Inscriptos desc;


-- Puntos promedio y puntaje mas alto de cada torneo
select Torneo.NombreTorneo,
       avg(TablaPosiciones.PuntosAcumulados) as PuntosPromedio,
       max(TablaPosiciones.PuntosAcumulados) as PuntosMaximo
from TablaPosiciones
inner join Torneo on TablaPosiciones.IdTorneo = Torneo.IdTorneo
group by Torneo.NombreTorneo;


-- Cuantas acciones registro cada usuario en la auditoria
select Usuario.Nombre, Usuario.Apellido,
       AuditoriaRegistro.AccionRealizada,
       count(*) as Cantidad
from AuditoriaRegistro
inner join Usuario on AuditoriaRegistro.IdUsuario = Usuario.IdUsuario
group by Usuario.Nombre, Usuario.Apellido, AuditoriaRegistro.AccionRealizada
order by Cantidad desc;

-- union

-- Cuantas filas quedaron cargadas en cada tabla.
select 'Usuario' as Tabla, count(*) as Filas from Usuario
union all select 'Participante',      count(*) from Participante
union all select 'Equipo',            count(*) from Equipo
union all select 'Integra',           count(*) from Integra
union all select 'Torneo',            count(*) from Torneo
union all select 'Inscripcion',       count(*) from Inscripcion
union all select 'Ronda',             count(*) from Ronda
union all select 'Enfrentamiento',    count(*) from Enfrentamiento
union all select 'Resultado',         count(*) from Resultado
union all select 'TablaPosiciones',   count(*) from TablaPosiciones
union all select 'AuditoriaRegistro', count(*) from AuditoriaRegistro;

-- subconsulta

select NombreTorneo, Estado
from Torneo
where IdTorneo in (select IdTorneo from Enfrentamiento
                    where EstadoPartido = 'JUGADO');


--  VISTA.
create or replace view VistaPosiciones as
select TablaPosiciones.IdTorneo,
       Torneo.NombreTorneo,
       Participante.NombreParticipante,
       TablaPosiciones.PartidosJugados,
       TablaPosiciones.Victorias,
       TablaPosiciones.Empates,
       TablaPosiciones.Derrotas,
       TablaPosiciones.PuntosAcumulados
from TablaPosiciones
inner join Torneo       on TablaPosiciones.IdTorneo      = Torneo.IdTorneo
inner join Inscripcion  on TablaPosiciones.IdInscripcion = Inscripcion.IdInscripcion
inner join Participante on Inscripcion.IdParticipante    = Participante.IdParticipante;

select * from VistaPosiciones
where IdTorneo = 1
order by PuntosAcumulados desc;

-- transaccion
-- Como estan las posiciones antes de la transaccion
select IdInscripcion, PartidosJugados, Victorias, Derrotas, PuntosAcumulados
from TablaPosiciones
where IdInscripcion in (57, 58);

start transaction;

update Enfrentamiento
set EstadoPartido = 'JUGADO'
where IdEnfrentamiento = 67;

insert into Resultado (PuntuacionLocal, PuntuacionVisitante, Ganador,
                       Validado, IdEnfrentamiento)
values (3, 1, 'LOCAL', 1, 67);

update TablaPosiciones
set PartidosJugados  = PartidosJugados + 1,
    Victorias        = Victorias + 1,
    PuntosAcumulados = PuntosAcumulados + 3
where IdInscripcion = 57;

update TablaPosiciones
set PartidosJugados = PartidosJugados + 1,
    Derrotas        = Derrotas + 1
where IdInscripcion = 58;

-- Adentro de la transaccion los cambios 
select IdInscripcion, PartidosJugados, Victorias, Derrotas, PuntosAcumulados
from TablaPosiciones
where IdInscripcion in (57, 58);

rollback;

-- Despues del rollback vuelven a estar como al principio
select IdInscripcion, PartidosJugados, Victorias, Derrotas, PuntosAcumulados
from TablaPosiciones
where IdInscripcion in (57, 58);

--  DCL (permisos de los usuarios de la base)
show grants for 'cupcoreapp'@'localhost';
show grants for 'cupcoreconsulta'@'localhost';
