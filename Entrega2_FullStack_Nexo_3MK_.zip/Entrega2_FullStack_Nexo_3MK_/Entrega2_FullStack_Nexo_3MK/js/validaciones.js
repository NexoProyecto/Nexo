/*
 * Validación de formularios en el navegador. Es la primera barrera;
 * la definitiva es la del servidor (Validador.php).
 */

var CLAVE_LARGO_MINIMO = 8;

// Texto obligatorio: sin espacios sobrantes, largo controlado y sin caracteres de inyección.
function validarTexto(valor, min, max) {
  if (typeof valor !== 'string') {
    return 'El campo debe ser texto.';
  }
  var limpio = valor.trim();
  if (limpio === '') {
    return 'El campo es obligatorio.';
  }
  if (limpio.length < min || limpio.length > max) {
    return 'El campo debe tener entre ' + min + ' y ' + max + ' caracteres.';
  }
  if (/[<>"';\\]/.test(limpio)) {
    return 'El campo contiene caracteres no permitidos.';
  }
  return null;
}

// Correo electrónico.
function validarEmail(valor) {
  if (typeof valor !== 'string' || valor.trim() === '') {
    return 'El correo es obligatorio.';
  }
  var limpio = valor.trim();
  if (limpio.length > 120) {
    return 'El correo es demasiado largo.';
  }
  if (!/^[^\s@]+@[^\s@.]+(\.[^\s@.]+)+$/.test(limpio)) {
    return 'El correo no tiene un formato válido.';
  }
  return null;
}

// Contraseña según la política del proyecto.
function validarClave(valor) {
  if (typeof valor !== 'string' || valor === '') {
    return 'La contraseña es obligatoria.';
  }
  if (valor.length < CLAVE_LARGO_MINIMO) {
    return 'La contraseña debe tener al menos ' + CLAVE_LARGO_MINIMO + ' caracteres.';
  }
  if (valor.length > 72) {
    return 'La contraseña no puede superar 72 caracteres.';
  }
  var faltan = [];
  if (!/[A-Z]/.test(valor)) { faltan.push('una letra mayúscula'); }
  if (!/[a-z]/.test(valor)) { faltan.push('una letra minúscula'); }
  if (!/[0-9]/.test(valor)) { faltan.push('un número'); }
  if (!/[^A-Za-z0-9]/.test(valor)) { faltan.push('un carácter especial'); }
  if (faltan.length > 0) {
    return 'La contraseña debe incluir ' + faltan.join(', ') + '.';
  }
  return null;
}

function validarClaveRepetida(clave, repeticion) {
  if (clave !== repeticion) {
    return 'Las dos contraseñas no coinciden.';
  }
  return null;
}

// Entero positivo (identificadores).
function validarEntero(valor, min, max) {
  if (!/^\d+$/.test(String(valor).trim())) {
    return 'El valor debe ser un número entero.';
  }
  var numero = parseInt(valor, 10);
  if (numero < min || numero > max) {
    return 'El valor debe estar entre ' + min + ' y ' + max + '.';
  }
  return null;
}

// Muestra el mensaje debajo del campo y marca el borde en rojo.
function mostrarError(campo, mensaje) {
  var contenedor = document.getElementById('error-' + campo.name);
  if (contenedor) {
    contenedor.textContent = mensaje === null ? '' : mensaje;
  }
  campo.classList.toggle('campo-invalido', mensaje !== null);
}

/* Conecta la validación a los formularios del proyecto:
   - form-ingreso : vistas/login.php (correo y contrasena)
   - form-usuario : vistas/admin.php (nombre, correo, contrasena y rol)
*/
function conectarFormularios() {
  var formIngreso = document.getElementById('form-ingreso');
  if (formIngreso) {
    formIngreso.addEventListener('submit', function (evento) {
      var campos = formIngreso.elements;
      var errorCorreo = validarEmail(campos.correo.value);
      var errorClave = campos.contrasena.value === '' ? 'La contraseña es obligatoria.' : null;
      mostrarError(campos.correo, errorCorreo);
      mostrarError(campos.contrasena, errorClave);
      if (errorCorreo !== null || errorClave !== null) {
        evento.preventDefault();
      }
    });
  }

  var formUsuario = document.getElementById('form-usuario');
  if (formUsuario) {
    formUsuario.addEventListener('submit', function (evento) {
      var campos = formUsuario.elements;
      var revisiones = [
        [campos.nombre, validarTexto(campos.nombre.value, 2, 60)],
        [campos.correo, validarEmail(campos.correo.value)],
        [campos.contrasena, validarClave(campos.contrasena.value)]
      ];
      var hayError = false;
      for (var i = 0; i < revisiones.length; i++) {
        mostrarError(revisiones[i][0], revisiones[i][1]);
        if (revisiones[i][1] !== null) { hayError = true; }
      }
      if (hayError) {
        evento.preventDefault();
      }
    });
  }
}

if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', conectarFormularios);
}

/* Exportación usada solo por las pruebas automáticas. */
if (typeof module !== 'undefined') {
  module.exports = {
    validarTexto: validarTexto,
    validarEmail: validarEmail,
    validarClave: validarClave,
    validarClaveRepetida: validarClaveRepetida,
    validarEntero: validarEntero
  };
}
