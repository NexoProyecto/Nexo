#!/bin/bash
# respaldar-base.sh - respaldo de la base CupCore comprimido, cifrado y firmado
#
# Uso, como root:  bash respaldar-base.sh
# Variables:
#   DESTINO       carpeta de los respaldos; por omision /backup/mysql
#   CLAVES        carpeta de las claves; por omision /etc/cupcore/claves
#   DIAS          dias que se conservan los respaldos; por omision 14
#   OPCIONES_BD   opciones de conexion para el volcado; como root no hacen falta
#
# Por cada respaldo deja tres archivos:
#   CupCore_AAAA-MM-DD_HH-MM.sql.gz.enc      volcado comprimido y cifrado con AES-256
#   CupCore_AAAA-MM-DD_HH-MM.sql.gz.enc.firma   firma RSA con SHA-256 del archivo cifrado
#   CupCore_AAAA-MM-DD_HH-MM.sha256          hash SHA-256 del volcado sin cifrar

set -euo pipefail

DESTINO="${DESTINO:-/backup/mysql}"
CLAVES="${CLAVES:-/etc/cupcore/claves}"
DIAS="${DIAS:-14}"
OPCIONES_BD="${OPCIONES_BD:-}"

VOLCAR="$(command -v mariadb-dump || command -v mysqldump)"
NOMBRE="CupCore_$(date +%Y-%m-%d_%H-%M)"
TEMPORAL="$(mktemp -d)"
trap 'rm -rf "$TEMPORAL"' EXIT

for archivo in respaldo.clave firma-privada.pem; do
    [ -f "$CLAVES/$archivo" ] || { echo "Falta $CLAVES/$archivo: ejecutar generar-claves.sh"; exit 1; }
done

umask 077
mkdir -p "$DESTINO"

# 1. Volcado y compresion
# shellcheck disable=SC2086
"$VOLCAR" $OPCIONES_BD --single-transaction --routines CupCore | gzip > "$TEMPORAL/$NOMBRE.sql.gz"

# 2. Hash del volcado
(cd "$TEMPORAL" && sha256sum "$NOMBRE.sql.gz") > "$DESTINO/$NOMBRE.sha256"

# 3. Cifrado
openssl enc -aes-256-cbc -pbkdf2 -iter 100000 -salt \
    -pass "file:$CLAVES/respaldo.clave" \
    -in "$TEMPORAL/$NOMBRE.sql.gz" -out "$DESTINO/$NOMBRE.sql.gz.enc"

# 4. Firma del archivo cifrado
openssl dgst -sha256 -sign "$CLAVES/firma-privada.pem" \
    -out "$DESTINO/$NOMBRE.sql.gz.enc.firma" "$DESTINO/$NOMBRE.sql.gz.enc"

# 5. Respaldos vencidos
find "$DESTINO" -maxdepth 1 -name 'CupCore_*' -mtime +"$DIAS" -delete

echo "Respaldo: $DESTINO/$NOMBRE.sql.gz.enc ($(du -h "$DESTINO/$NOMBRE.sql.gz.enc" | cut -f1))"
