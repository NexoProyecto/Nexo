#!/bin/bash
# restaurar-base.sh - verifica la firma de un respaldo, lo descifra y lo carga
#
# Uso, como root:
#   bash restaurar-base.sh /backup/mysql/CupCore_AAAA-MM-DD_HH-MM.sql.gz.enc
#   CARGAR=1 bash restaurar-base.sh /backup/mysql/CupCore_AAAA-MM-DD_HH-MM.sql.gz.enc
#
# Variables:
#   CARGAR=1      carga el respaldo en la base CupCore y reemplaza sus datos
#   CLAVES        carpeta de las claves; por omision /etc/cupcore/claves
#   SALIDA        carpeta del volcado descifrado; por omision la carpeta actual
#   OPCIONES_BD   opciones de conexion para la carga; como root no hacen falta
#
# Sin CARGAR=1 deja el volcado descifrado en SALIDA y no toca la base.
# Con la firma invalida se detiene antes de descifrar.

set -euo pipefail

CIFRADO="${1:?Uso: bash restaurar-base.sh ARCHIVO.sql.gz.enc}"
CLAVES="${CLAVES:-/etc/cupcore/claves}"
SALIDA="${SALIDA:-.}"
CARGAR="${CARGAR:-0}"
OPCIONES_BD="${OPCIONES_BD:-}"

CLIENTE="$(command -v mariadb || command -v mysql)"
BASE="$(basename "$CIFRADO" .sql.gz.enc)"
CARPETA="$(dirname "$CIFRADO")"
VOLCADO="$SALIDA/$BASE.sql.gz"

# 1. Firma
if ! openssl dgst -sha256 -verify "$CLAVES/firma-publica.pem" \
        -signature "$CIFRADO.firma" "$CIFRADO" > /dev/null 2>&1; then
    echo "FIRMA INVALIDA: el archivo fue modificado o no lo firmo este servidor. No se descifra."
    exit 1
fi
echo "Firma correcta."

# 2. Descifrado
umask 077
openssl enc -d -aes-256-cbc -pbkdf2 -iter 100000 \
    -pass "file:$CLAVES/respaldo.clave" -in "$CIFRADO" -out "$VOLCADO"

# 3. Hash del volcado
if [ -f "$CARPETA/$BASE.sha256" ]; then
    (cd "$SALIDA" && sha256sum -c --quiet "$(cd "$CARPETA" && pwd)/$BASE.sha256")
    echo "Hash SHA-256 correcto."
fi
gzip -t "$VOLCADO"
echo "Volcado descifrado: $VOLCADO"

# 4. Carga
if [ "$CARGAR" = 1 ]; then
    # shellcheck disable=SC2086
    gunzip -c "$VOLCADO" | "$CLIENTE" $OPCIONES_BD CupCore
    rm -f "$VOLCADO"
    echo "Respaldo cargado en la base CupCore."
fi
