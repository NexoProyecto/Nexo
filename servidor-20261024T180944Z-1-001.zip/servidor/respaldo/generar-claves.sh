#!/bin/bash
# generar-claves.sh - crea la clave de cifrado y el par de claves de firma de los respaldos
#
# Uso, como root:  bash generar-claves.sh
# Variable:        CLAVES   carpeta de las claves; por omision /etc/cupcore/claves
#
# Archivos:
#   respaldo.clave      clave del cifrado AES-256 (secreta)
#   firma-privada.pem   clave privada RSA de 3072 bits: firma los respaldos (secreta)
#   firma-publica.pem   clave publica RSA: verifica la firma (se puede copiar a otro equipo)
# No reemplaza claves existentes: con otra clave los respaldos anteriores no se descifran.

set -euo pipefail

CLAVES="${CLAVES:-/etc/cupcore/claves}"

umask 077
mkdir -p "$CLAVES"
chmod 700 "$CLAVES"

if [ ! -f "$CLAVES/respaldo.clave" ]; then
    openssl rand -base64 48 > "$CLAVES/respaldo.clave"
    echo "Clave de cifrado creada."
fi

if [ ! -f "$CLAVES/firma-privada.pem" ]; then
    openssl genrsa -out "$CLAVES/firma-privada.pem" 3072 2>/dev/null
    openssl rsa -in "$CLAVES/firma-privada.pem" -pubout -out "$CLAVES/firma-publica.pem" 2>/dev/null
    echo "Par de claves de firma creado."
fi

chmod 600 "$CLAVES/respaldo.clave" "$CLAVES/firma-privada.pem"
chmod 644 "$CLAVES/firma-publica.pem"
echo "Claves en $CLAVES"
