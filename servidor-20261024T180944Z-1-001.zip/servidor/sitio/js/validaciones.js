/* Validación de formularios en el navegador */

var CLAVE_LARGO_MINIMO = 8;

function validarTexto(valor, min, max) {
  if (typeof valor !== 'string') {
    return 'El campo debe ser texto.';
  }
  var limpio = valor.trim();
  if (limpio === '') {
    return 'El campo es obligatorio.';
  }
  if (limpio.length < min || limpio.length > max) {
    return 'El campo debe tener entre ' + min + ' y ' + max + ' caracteres.';
  }
  if (/[<>"';\\]/.test(limpio)) {
    return 'El campo contiene caracteres no permitidos.';
  }
  return null;
}

function validarEmail(valor) {
  if (typeof valor !== 'string' || valor.trim() === '') {
    return 'El correo es obligatorio.';
  }
  var limpio = valor.trim();
  if (limpio.length > 120) {
    return 'El correo es demasiado largo.';
  }
  if (!/^[^\s@]+@[^\s@.]+(\.[^\s@.]+)+$/.test(limpio)) {
    return 'El correo no tiene un formato válido.';
  }
  return null;
}

function validarClave(valor) {
  if (typeof valor !== 'string' || valor === '') {
    return 'La contraseña es obligatoria.';
  }
  if (valor.length < CLAVE_LARGO_MINIMO) {
    return 'La contraseña debe tener al menos ' + CLAVE_LARGO_MINIMO + ' caracteres.';
  }
  if (valor.length > 72) {
    return 'La contraseña no puede superar 72 caracteres.';
  }
  var faltan = [];
  if (!/[A-Z]/.test(valor)) { faltan.push('una letra mayúscula'); }
  if (!/[a-z]/.test(valor)) { faltan.push('una letra minúscula'); }
  if (!/[0-9]/.test(valor)) { faltan.push('un número'); }
  if (!/[^A-Za-z0-9]/.test(valor)) { faltan.push('un carácter especial'); }
  if (faltan.length > 0) {
    return 'La contraseña debe incluir ' + faltan.join(', ') + '.';
  }
  return null;
}

function validarClaveRepetida(clave, repeticion) {
  if (clave !== repeticion) {
    return 'Las dos contraseñas no coinciden.';
  }
  return null;
}

function validarEntero(valor, min, max) {
  if (!/^\d+$/.test(String(valor).trim())) {
    return 'El valor debe ser un número entero.';
  }
  var numero = parseInt(valor, 10);
  if (numero < min || numero > max) {
    return 'El valor debe estar entre ' + min + ' y ' + max + '.';
  }
  return null;
}

/* Fechas AAAA-MM-DD de un torneo: inicio obligatorio y fin, si está, no anterior al inicio */
function validarFechas(inicio, fin) {
  var formato = /^\d{4}-\d{2}-\d{2}$/;
  if (!formato.test(inicio)) {
    return 'La fecha de inicio es obligatoria.';
  }
  if (fin !== '' && !formato.test(fin)) {
    return 'La fecha de fin no es válida.';
  }
  if (fin !== '' && fin < inicio) {
    return 'La fecha de fin no puede ser anterior a la de inicio.';
  }
  return null;
}

function mostrarError(campo, mensaje) {
  var contenedor = document.getElementById('error-' + campo.name);
  if (contenedor) {
    contenedor.textContent = mensaje === null ? '' : mensaje;
  }
  campo.classList.toggle('campo-invalido', mensaje !== null);
}

/* Formularios: form-ingreso (login.php), form-solicitud (solicitud.php), form-usuario (admin.php), form-clave (clave.php),
   form-torneo (organizador.php y gestion.php), form-participante (participantes.php),
   form-resultado (gestion.php) y todo formulario con data-confirmar */
function conectarFormularios() {
  var formIngreso = document.getElementById('form-ingreso');
  if (formIngreso) {
    formIngreso.addEventListener('submit', function (evento) {
      var campos = formIngreso.elements;
      var errorCorreo = validarEmail(campos.correo.value);
      var errorClave = campos.contrasena.value === '' ? 'La contraseña es obligatoria.' : null;
      mostrarError(campos.correo, errorCorreo);
      mostrarError(campos.contrasena, errorClave);
      if (errorCorreo !== null || errorClave !== null) {
        evento.preventDefault();
      }
    });
  }

  var formUsuario = document.getElementById('form-usuario');
  if (formUsuario) {
    formUsuario.addEventListener('submit', function (evento) {
      var campos = formUsuario.elements;
      var revisiones = [
        [campos.nombre, validarTexto(campos.nombre.value, 2, 60)],
        [campos.correo, validarEmail(campos.correo.value)],
        [campos.contrasena, validarClave(campos.contrasena.value)]
      ];
      var hayError = false;
      for (var i = 0; i < revisiones.length; i++) {
        mostrarError(revisiones[i][0], revisiones[i][1]);
        if (revisiones[i][1] !== null) { hayError = true; }
      }
      if (hayError) {
        evento.preventDefault();
      }
    });
  }

  var formSolicitud = document.getElementById('form-solicitud');
  if (formSolicitud) {
    formSolicitud.addEventListener('submit', function (evento) {
      var campos = formSolicitud.elements;
      var motivo = campos.motivo.value.trim();
      var revisiones = [
        [campos.nombre, validarTexto(campos.nombre.value, 2, 50)],
        [campos.apellido, validarTexto(campos.apellido.value, 2, 50)],
        [campos.correo, validarEmail(campos.correo.value)],
        [campos.contrasena, validarClave(campos.contrasena.value)],
        [campos.repetida, validarClaveRepetida(campos.contrasena.value, campos.repetida.value)],
        [campos.motivo, motivo === '' ? null : validarTexto(motivo, 1, 300)]
      ];
      var hayError = false;
      for (var i = 0; i < revisiones.length; i++) {
        mostrarError(revisiones[i][0], revisiones[i][1]);
        if (revisiones[i][1] !== null) { hayError = true; }
      }
      if (hayError) {
        evento.preventDefault();
      }
    });
  }

  var formClave = document.getElementById('form-clave');
  if (formClave) {
    formClave.addEventListener('submit', function (evento) {
      var campos = formClave.elements;
      var revisiones = [
        [campos.actual, campos.actual.value === '' ? 'La contraseña actual es obligatoria.' : null],
        [campos.nueva, validarClave(campos.nueva.value)],
        [campos.repetida, validarClaveRepetida(campos.nueva.value, campos.repetida.value)]
      ];
      var hayError = false;
      for (var i = 0; i < revisiones.length; i++) {
        mostrarError(revisiones[i][0], revisiones[i][1]);
        if (revisiones[i][1] !== null) { hayError = true; }
      }
      if (hayError) {
        evento.preventDefault();
      }
    });
  }

  var formTorneo = document.getElementById('form-torneo');
  if (formTorneo) {
    formTorneo.addEventListener('submit', function (evento) {
      var campos = formTorneo.elements;
      var errorNombre = validarTexto(campos.nombre.value, 3, 100);
      var errorFechas = validarFechas(campos.inicio.value, campos.fin.value);
      var errorReglas = campos.reglas.value.trim() === '' ? null : validarTexto(campos.reglas.value, 1, 500);
      mostrarError(campos.nombre, errorNombre);
      mostrarError(campos.inicio, errorFechas);
      mostrarError(campos.reglas, errorReglas);
      if (errorNombre !== null || errorFechas !== null || errorReglas !== null) {
        evento.preventDefault();
      }
    });
  }

  var formParticipante = document.getElementById('form-participante');
  if (formParticipante) {
    formParticipante.addEventListener('submit', function (evento) {
      var campo = formParticipante.elements.nombre;
      var error = validarTexto(campo.value, 2, 80);
      mostrarError(campo, error);
      if (error !== null) {
        evento.preventDefault();
      }
    });
  }

  var formsResultado = document.querySelectorAll('form.form-resultado');
  for (var k = 0; k < formsResultado.length; k++) {
    formsResultado[k].addEventListener('submit', function (evento) {
      var campos = this.elements;
      var hayError = false;
      [campos.local, campos.visitante].forEach(function (campo) {
        var invalido = validarEntero(campo.value, 0, 999) !== null;
        campo.classList.toggle('campo-invalido', invalido);
        if (invalido) { hayError = true; }
      });
      if (hayError) {
        evento.preventDefault();
      }
    });
  }

  var formsConfirmar = document.querySelectorAll('form[data-confirmar]');
  for (var j = 0; j < formsConfirmar.length; j++) {
    formsConfirmar[j].addEventListener('submit', function (evento) {
      if (this.getAttribute('data-confirmado') === 'si') {
        this.removeAttribute('data-confirmado');
        return;
      }
      evento.preventDefault();
      abrirConfirmacion(this, evento.submitter || null);
    });
  }
}

/* Ventana de confirmación con el diseño del sitio para los formularios con data-confirmar.
   data-aviso agrega una advertencia destacada y data-boton, el texto del botón que confirma.
   El foco empieza en Volver; Escape o un clic fuera de la ventana no envían el formulario */
function abrirConfirmacion(formulario, boton) {
  var anterior = document.activeElement;
  var fondo = document.createElement('div');
  fondo.className = 'ventana-fondo';

  var ventana = document.createElement('div');
  ventana.className = 'ventana';
  ventana.setAttribute('role', 'alertdialog');
  ventana.setAttribute('aria-modal', 'true');
  ventana.setAttribute('aria-labelledby', 'ventana-titulo');
  ventana.setAttribute('aria-describedby', 'ventana-texto');

  var titulo = document.createElement('h2');
  titulo.id = 'ventana-titulo';
  titulo.className = 'ventana-titulo';
  titulo.textContent = 'Confirmar';
  ventana.appendChild(titulo);

  var texto = document.createElement('p');
  texto.id = 'ventana-texto';
  texto.textContent = formulario.getAttribute('data-confirmar');
  ventana.appendChild(texto);

  var aviso = formulario.getAttribute('data-aviso');
  if (aviso) {
    var parrafo = document.createElement('p');
    parrafo.className = 'ventana-aviso';
    parrafo.textContent = aviso;
    ventana.appendChild(parrafo);
  }

  var botones = document.createElement('div');
  botones.className = 'ventana-botones';
  var cancelar = document.createElement('button');
  cancelar.type = 'button';
  cancelar.className = 'boton-borde';
  cancelar.textContent = 'Volver';
  var aceptar = document.createElement('button');
  aceptar.type = 'button';
  aceptar.className = 'boton';
  aceptar.textContent = formulario.getAttribute('data-boton') || 'Confirmar';
  botones.appendChild(cancelar);
  botones.appendChild(aceptar);
  ventana.appendChild(botones);

  function cerrar() {
    document.removeEventListener('keydown', teclas);
    fondo.parentNode.removeChild(fondo);
    if (anterior && anterior.focus) { anterior.focus(); }
  }

  function teclas(evento) {
    if (evento.key === 'Escape') {
      evento.preventDefault();
      cerrar();
    } else if (evento.key === 'Tab') {
      evento.preventDefault();
      (document.activeElement === cancelar ? aceptar : cancelar).focus();
    }
  }

  cancelar.addEventListener('click', cerrar);
  fondo.addEventListener('click', function (evento) {
    if (evento.target === fondo) { cerrar(); }
  });
  aceptar.addEventListener('click', function () {
    cerrar();
    formulario.setAttribute('data-confirmado', 'si');
    if (formulario.requestSubmit) {
      formulario.requestSubmit(boton);
    } else {
      formulario.submit();
    }
  });

  fondo.appendChild(ventana);
  document.body.appendChild(fondo);
  document.addEventListener('keydown', teclas);
  cancelar.focus();
}

if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', conectarFormularios);
}

/* Exportación para pruebas/pruebas_js.js */
if (typeof module !== 'undefined') {
  module.exports = {
    validarTexto: validarTexto,
    validarEmail: validarEmail,
    validarClave: validarClave,
    validarClaveRepetida: validarClaveRepetida,
    validarEntero: validarEntero,
    validarFechas: validarFechas
  };
}
