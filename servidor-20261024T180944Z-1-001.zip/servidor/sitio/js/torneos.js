/* Consultas a las rutas api/ sin recargar la página (fetch y JSON) */

var CLASE_DE_MODULO = {
  'Liga': 'etiqueta-liga',
  'Eliminación directa': 'etiqueta-eliminacion'
};

function fechaCorta(fecha) {
  if (!fecha) {
    return '—';
  }
  var partes = fecha.split('-');
  return partes[2] + '/' + partes[1] + '/' + partes[0];
}

/* Crea un elemento con clase y texto. El texto entra por textContent: no se interpreta como HTML */
function elemento(etiqueta, clase, texto) {
  var nodo = document.createElement(etiqueta);
  if (clase) { nodo.className = clase; }
  if (texto !== undefined) { nodo.textContent = texto; }
  return nodo;
}

function tarjetaDeTorneo(torneo) {
  var tarjeta = elemento('article', 'torneo');

  var imagen = elemento('img', 'portada-img');
  // La imagen la elige el servidor según el nombre del torneo (GestorTorneos::imagenDeTorneo)
  imagen.src = torneo.imagen;
  imagen.alt = 'Imagen del torneo ' + torneo.nombre;
  imagen.loading = 'lazy';
  tarjeta.appendChild(imagen);

  var datos = elemento('div', 'datos');
  datos.appendChild(elemento('span', 'etiqueta ' + (CLASE_DE_MODULO[torneo.modulo] || 'etiqueta-suizo'), torneo.modulo));
  datos.appendChild(elemento('h3', '', torneo.nombre));
  datos.appendChild(elemento('div', 'dato', '▦ ' + fechaCorta(torneo.fecha_inicio) + ' - ' + fechaCorta(torneo.fecha_fin)));
  datos.appendChild(elemento('div', 'dato', '☻ ' + torneo.inscriptos + ' inscriptos · ' + torneo.disciplina));
  datos.appendChild(elemento('div', 'dato', 'Estado: ' + torneo.estado));

  var enlace = elemento('a', 'boton-borde', 'Ver torneo');
  enlace.href = 'index.php?ruta=torneo&id=' + encodeURIComponent(torneo.id);
  datos.appendChild(enlace);

  tarjeta.appendChild(datos);
  return tarjeta;
}

/* Listado de torneos: busca mientras se escribe, sin enviar el formulario */
function conectarBusqueda() {
  var formulario = document.getElementById('form-busqueda');
  var lista = document.getElementById('lista-torneos');
  if (!formulario || !lista || typeof fetch !== 'function') {
    return;
  }

  var espera = null;
  var pedido = 0;

  function buscar() {
    var numero = ++pedido;
    var consulta = 'index.php?ruta=api/torneos'
      + '&busqueda=' + encodeURIComponent(formulario.elements.busqueda.value)
      + '&modulo=' + encodeURIComponent(formulario.elements.modulo.value);

    fetch(consulta, { headers: { 'Accept': 'application/json' } })
      .then(function (respuesta) {
        if (!respuesta.ok) { throw new Error('Respuesta ' + respuesta.status); }
        return respuesta.json();
      })
      .then(function (datos) {
        // Una respuesta que llega tarde no pisa a la de una búsqueda posterior
        if (numero !== pedido) { return; }
        lista.textContent = '';
        datos.torneos.forEach(function (torneo) {
          lista.appendChild(tarjetaDeTorneo(torneo));
        });
        var cantidad = datos.torneos.length;
        document.getElementById('cantidad-torneos').textContent = cantidad;
        var sinTorneos = document.getElementById('sin-torneos');
        sinTorneos.classList.toggle('oculto', cantidad > 0);
      })
      .catch(function () {
        // Sin respuesta del servidor queda el listado que ya está en pantalla;
        // el botón Buscar sigue funcionando
      });
  }

  formulario.elements.busqueda.addEventListener('input', function () {
    clearTimeout(espera);
    espera = setTimeout(buscar, 300);
  });
  formulario.elements.modulo.addEventListener('change', buscar);
}

/* Detalle de un torneo en curso: actualiza la tabla de posiciones cada 30 segundos */
function conectarPosiciones() {
  var seccion = document.getElementById('posiciones');
  var cuerpo = document.getElementById('cuerpo-posiciones');
  if (!seccion || !cuerpo || seccion.getAttribute('data-actualizar') !== '1' || typeof fetch !== 'function') {
    return;
  }

  var consulta = 'index.php?ruta=api/posiciones&torneo=' + encodeURIComponent(seccion.getAttribute('data-torneo'));

  setInterval(function () {
    fetch(consulta, { headers: { 'Accept': 'application/json' } })
      .then(function (respuesta) {
        if (!respuesta.ok) { throw new Error('Respuesta ' + respuesta.status); }
        return respuesta.json();
      })
      .then(function (datos) {
        if (datos.posiciones.length === 0) { return; }
        cuerpo.textContent = '';
        datos.posiciones.forEach(function (fila, indice) {
          var tr = document.createElement('tr');
          var puntos = elemento('td');
          puntos.appendChild(elemento('strong', '', fila.puntos));
          [indice + 1, fila.participante, fila.jugados, fila.ganados, fila.empatados, fila.perdidos].forEach(function (valor) {
            tr.appendChild(elemento('td', '', valor));
          });
          tr.appendChild(puntos);
          cuerpo.appendChild(tr);
        });
      })
      .catch(function () {
        // Queda la tabla que ya está en pantalla
      });
  }, 30000);
}

if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', function () {
    conectarBusqueda();
    conectarPosiciones();
  });
}

/* Exportación para las pruebas */
if (typeof module !== 'undefined') {
  module.exports = { fechaCorta: fechaCorta };
}
