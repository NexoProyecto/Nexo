<?php
require_once __DIR__ . '/ConexionBD.php';
require_once __DIR__ . '/GestorInscripciones.php';
require_once __DIR__ . '/modulos/ModuloCompetencia.php';

/**
 * Desarrollo de un torneo: rondas, enfrentamientos, resultados y tabla de posiciones.
 * Los cruces los arma el módulo de competencia del torneo.
 * Una regla que no se cumple se informa con una DomainException, con el texto para la pantalla.
 */
class GestorCompetencia
{
    /** Días entre una ronda y la siguiente */
    private const DIAS_ENTRE_RONDAS = 7;

    private PDO $bd;

    public function __construct(?PDO $conexion = null)
    {
        $this->bd = $conexion ?? ConexionBD::obtener();
    }

    /** Inicia el torneo: crea la tabla de posiciones y las rondas iniciales del módulo */
    public function iniciar(int $idTorneo): void
    {
        $torneo = $this->torneo($idTorneo);

        if ($torneo['Estado'] !== 'ABIERTO') {
            throw new DomainException('El torneo se inicia con las inscripciones abiertas.');
        }

        $inscripciones = (new GestorInscripciones($this->bd))->aceptadas($idTorneo);
        if (count($inscripciones) < 2) {
            throw new DomainException('Hacen falta al menos dos inscripciones aceptadas.');
        }

        $modulo = ModuloCompetencia::crear($torneo['NombreModulo']);

        $this->bd->beginTransaction();

        try {
            $alta = $this->bd->prepare(
                "insert into TablaPosiciones (IdTorneo, IdInscripcion) values (:torneo, :inscripcion)"
            );
            foreach ($inscripciones as $inscripcion) {
                $alta->execute([':torneo' => $idTorneo, ':inscripcion' => $inscripcion]);
            }

            foreach ($modulo->rondasIniciales($inscripciones) as $indice => $cruces) {
                $this->crearRonda($torneo, $indice + 1, $cruces, $indice === 0);
            }

            $stmt = $this->bd->prepare("update Torneo set Estado = 'EN CURSO' where IdTorneo = :id");
            $stmt->execute([':id' => $idTorneo]);

            $this->recalcularPosiciones($idTorneo, $modulo);

            $this->bd->commit();
        } catch (Throwable $e) {
            $this->bd->rollBack();
            throw $e;
        }
    }

    /** Rondas del torneo, cada una con sus partidos */
    public function rondas(int $idTorneo): array
    {
        $stmt = $this->bd->prepare(
            "select Ronda.NumeroRonda     as numero,
                    Ronda.EstadoRonda     as estado_codigo,
                    case Ronda.EstadoRonda
                        when 'PENDIENTE' then 'Pendiente'
                        when 'EN CURSO'  then 'En curso'
                        else 'Cerrada'
                    end                   as estado,
                    Ronda.FechaProgramada as fecha
             from Ronda
             where Ronda.IdTorneo = :torneo
             order by Ronda.NumeroRonda"
        );
        $stmt->execute([':torneo' => $idTorneo]);

        $rondas = [];
        foreach ($stmt as $fila) {
            $fila['partidos'] = [];
            $rondas[(int) $fila['numero']] = $fila;
        }

        $stmt = $this->bd->prepare(
            "select Enfrentamiento.IdEnfrentamiento as id,
                    Enfrentamiento.NumeroRonda      as ronda,
                    Enfrentamiento.FechaHora        as fecha_hora,
                    Enfrentamiento.EstadoPartido    as estado_codigo,
                    PartLocal.NombreParticipante    as local,
                    PartVisita.NombreParticipante   as visitante,
                    Resultado.PuntuacionLocal       as puntos_local,
                    Resultado.PuntuacionVisitante   as puntos_visitante,
                    Resultado.Ganador               as ganador,
                    Resultado.Validado              as validado
             from Enfrentamiento
             inner join Inscripcion  InsLocal   on Enfrentamiento.IdInscripcionLocal
                                                 = InsLocal.IdInscripcion
             inner join Participante PartLocal  on InsLocal.IdParticipante
                                                 = PartLocal.IdParticipante
             inner join Inscripcion  InsVisita  on Enfrentamiento.IdInscripcionVisitante
                                                 = InsVisita.IdInscripcion
             inner join Participante PartVisita on InsVisita.IdParticipante
                                                 = PartVisita.IdParticipante
             left join Resultado on Enfrentamiento.IdEnfrentamiento = Resultado.IdEnfrentamiento
             where Enfrentamiento.IdTorneo = :torneo
             order by Enfrentamiento.NumeroRonda, Enfrentamiento.IdEnfrentamiento"
        );
        $stmt->execute([':torneo' => $idTorneo]);

        foreach ($stmt as $fila) {
            $rondas[(int) $fila['ronda']]['partidos'][] = $fila;
        }

        return array_values($rondas);
    }

    /**
     * Carga o corrige el resultado de un partido de la ronda en curso. Queda sin validar.
     * Un resultado validado lo corrige solo quien tiene autorización ($puedeCorregirValidado).
     */
    public function cargarResultado(int $idEnfrentamiento, int $puntosLocal, int $puntosVisitante,
                                    bool $puedeCorregirValidado = false): void
    {
        $partido = $this->partido($idEnfrentamiento);
        $modulo  = ModuloCompetencia::crear($partido['NombreModulo']);

        if ($partido['EstadoTorneo'] !== 'EN CURSO' || $partido['EstadoRonda'] !== 'EN CURSO') {
            throw new DomainException('El resultado se carga en la ronda en curso de un torneo en curso.');
        }
        if ((int) $partido['Validado'] === 1 && !$puedeCorregirValidado) {
            throw new DomainException('El resultado ya está validado: lo corrige un administrador.');
        }
        if ($puntosLocal === $puntosVisitante && !$modulo->admiteEmpate()) {
            throw new DomainException('En eliminación directa no hay empate: uno de los dos tiene que ganar.');
        }

        $ganador = 'EMPATE';
        if ($puntosLocal !== $puntosVisitante) {
            $ganador = $puntosLocal > $puntosVisitante ? 'LOCAL' : 'VISITANTE';
        }

        $this->bd->beginTransaction();

        try {
            $stmt = $this->bd->prepare(
                "insert into Resultado (PuntuacionLocal, PuntuacionVisitante, Ganador, Validado, IdEnfrentamiento)
                 values (:pl, :pv, :ganador, 0, :partido)
                 on duplicate key update PuntuacionLocal = values(PuntuacionLocal),
                                         PuntuacionVisitante = values(PuntuacionVisitante),
                                         Ganador = values(Ganador),
                                         Validado = 0,
                                         FechaCarga = now()"
            );
            $stmt->execute([
                ':pl'      => $puntosLocal,
                ':pv'      => $puntosVisitante,
                ':ganador' => $ganador,
                ':partido' => $idEnfrentamiento,
            ]);

            $stmt = $this->bd->prepare(
                "update Enfrentamiento set EstadoPartido = 'JUGADO' where IdEnfrentamiento = :id"
            );
            $stmt->execute([':id' => $idEnfrentamiento]);

            $this->recalcularPosiciones((int) $partido['IdTorneo'], $modulo);

            $this->bd->commit();
        } catch (Throwable $e) {
            $this->bd->rollBack();
            throw $e;
        }
    }

    /** Valida el resultado cargado: pasa a ser oficial y cuenta en la tabla de posiciones */
    public function validarResultado(int $idEnfrentamiento): void
    {
        $partido = $this->partido($idEnfrentamiento);

        if ($partido['IdResultado'] === null) {
            throw new DomainException('El partido no tiene resultado cargado.');
        }
        // Mismo control que al cargarlo: un torneo cancelado conserva su ronda "en curso"
        if ($partido['EstadoTorneo'] !== 'EN CURSO' || $partido['EstadoRonda'] !== 'EN CURSO') {
            throw new DomainException('El resultado se valida en la ronda en curso de un torneo en curso.');
        }

        $this->bd->beginTransaction();

        try {
            $stmt = $this->bd->prepare("update Resultado set Validado = 1 where IdResultado = :id");
            $stmt->execute([':id' => $partido['IdResultado']]);

            $this->recalcularPosiciones(
                (int) $partido['IdTorneo'],
                ModuloCompetencia::crear($partido['NombreModulo'])
            );

            $this->bd->commit();
        } catch (Throwable $e) {
            $this->bd->rollBack();
            throw $e;
        }
    }

    /**
     * Cierra la ronda en curso y abre la siguiente. En eliminación directa y en el sistema
     * suizo la ronda siguiente se arma en este momento; sin ronda siguiente, el torneo finaliza.
     * Devuelve el texto de lo que pasó.
     */
    public function cerrarRonda(int $idTorneo): string
    {
        $torneo = $this->torneo($idTorneo);

        $stmt = $this->bd->prepare(
            "select Ronda.NumeroRonda
             from Ronda
             where Ronda.IdTorneo = :torneo and Ronda.EstadoRonda = 'EN CURSO'"
        );
        $stmt->execute([':torneo' => $idTorneo]);
        $numero = $stmt->fetchColumn();

        if ($torneo['Estado'] !== 'EN CURSO' || $numero === false) {
            throw new DomainException('El torneo no tiene una ronda en curso.');
        }

        $stmt = $this->bd->prepare(
            "select count(*)
             from Enfrentamiento
             left join Resultado on Enfrentamiento.IdEnfrentamiento = Resultado.IdEnfrentamiento
             where Enfrentamiento.IdTorneo = :torneo
               and Enfrentamiento.NumeroRonda = :ronda
               and (Resultado.IdResultado is null or Resultado.Validado = 0)"
        );
        $stmt->execute([':torneo' => $idTorneo, ':ronda' => $numero]);

        if ((int) $stmt->fetchColumn() > 0) {
            throw new DomainException('La ronda se cierra con todos sus resultados cargados y validados.');
        }

        $modulo = ModuloCompetencia::crear($torneo['NombreModulo']);
        $numero = (int) $numero;

        $this->bd->beginTransaction();

        try {
            $this->estadoRonda($idTorneo, $numero, 'CERRADA');
            $this->recalcularPosiciones($idTorneo, $modulo);

            if ($this->estadoRonda($idTorneo, $numero + 1, 'EN CURSO')) {
                $mensaje = 'Ronda ' . $numero . ' cerrada. La ronda ' . ($numero + 1) . ' está en curso.';
            } else {
                $cruces = $modulo->rondaSiguiente(
                    (new GestorInscripciones($this->bd))->aceptadas($idTorneo),
                    $this->partidosJugados($idTorneo),
                    $this->puntos($idTorneo)
                );

                if ($cruces === null) {
                    $stmt = $this->bd->prepare(
                        "update Torneo set Estado = 'FINALIZADO', FechaFin = greatest(FechaInicio, curdate())
                         where IdTorneo = :id"
                    );
                    $stmt->execute([':id' => $idTorneo]);
                    $mensaje = 'Ronda ' . $numero . ' cerrada. El torneo finalizó.';
                } else {
                    $this->crearRonda($torneo, $numero + 1, $cruces, true);
                    $mensaje = 'Ronda ' . $numero . ' cerrada. Se generó la ronda ' . ($numero + 1) . '.';
                }
            }

            $this->bd->commit();
        } catch (Throwable $e) {
            $this->bd->rollBack();
            throw $e;
        }

        return $mensaje;
    }

    /**
     * Calcula la tabla de posiciones con los resultados validados.
     * En el sistema suizo, quien queda libre en una ronda cerrada suma los puntos de una victoria.
     */
    public function recalcularPosiciones(int $idTorneo, ModuloCompetencia $modulo): void
    {
        $filas = [];
        foreach ((new GestorInscripciones($this->bd))->aceptadas($idTorneo) as $inscripcion) {
            $filas[$inscripcion] = ['v' => 0, 'e' => 0, 'd' => 0, 'libres' => 0];
        }

        $jugaron = [];
        foreach ($this->partidosJugados($idTorneo) as $partido) {
            $jugaron[$partido['ronda']][] = $partido['local'];
            $jugaron[$partido['ronda']][] = $partido['visitante'];

            if ($partido['ganador'] === 'EMPATE') {
                $filas[$partido['local']]['e']++;
                $filas[$partido['visitante']]['e']++;
                continue;
            }
            $gano   = $partido['ganador'] === 'LOCAL' ? 'local' : 'visitante';
            $perdio = $gano === 'local' ? 'visitante' : 'local';
            $filas[$partido[$gano]]['v']++;
            $filas[$partido[$perdio]]['d']++;
        }

        if ($modulo->puntuaRondaLibre()) {
            $stmt = $this->bd->prepare(
                "select Ronda.NumeroRonda from Ronda
                 where Ronda.IdTorneo = :torneo and Ronda.EstadoRonda = 'CERRADA'"
            );
            $stmt->execute([':torneo' => $idTorneo]);
            foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $ronda) {
                foreach (array_diff(array_keys($filas), $jugaron[(int) $ronda] ?? []) as $libre) {
                    $filas[$libre]['libres']++;
                }
            }
        }

        $stmt = $this->bd->prepare(
            "update TablaPosiciones
             set PartidosJugados = :pj, Victorias = :v, Empates = :e, Derrotas = :d, PuntosAcumulados = :puntos
             where IdInscripcion = :inscripcion"
        );
        foreach ($filas as $inscripcion => $fila) {
            $stmt->execute([
                ':pj'     => $fila['v'] + $fila['e'] + $fila['d'],
                ':v'      => $fila['v'],
                ':e'      => $fila['e'],
                ':d'      => $fila['d'],
                ':puntos' => ($fila['v'] + $fila['libres']) * $modulo->puntosVictoria()
                           + $fila['e'] * $modulo->puntosEmpate(),
                ':inscripcion' => $inscripcion,
            ]);
        }
    }

    /** Crea la ronda y sus enfrentamientos, con fecha a partir del inicio del torneo */
    private function crearRonda(array $torneo, int $numero, array $cruces, bool $enCurso): void
    {
        $fecha = date('Y-m-d', strtotime(
            $torneo['FechaInicio'] . ' +' . (($numero - 1) * self::DIAS_ENTRE_RONDAS) . ' days'
        ));

        $stmt = $this->bd->prepare(
            "insert into Ronda (IdTorneo, NumeroRonda, EstadoRonda, FechaProgramada)
             values (:torneo, :numero, :estado, :fecha)"
        );
        $stmt->execute([
            ':torneo' => $torneo['IdTorneo'],
            ':numero' => $numero,
            ':estado' => $enCurso ? 'EN CURSO' : 'PENDIENTE',
            ':fecha'  => $fecha,
        ]);

        $stmt = $this->bd->prepare(
            "insert into Enfrentamiento (FechaHora, EstadoPartido, IdTorneo, NumeroRonda,
                                         IdInscripcionLocal, IdInscripcionVisitante)
             values (:fecha, 'PROGRAMADO', :torneo, :numero, :local, :visitante)"
        );
        foreach ($cruces as $indice => [$local, $visitante]) {
            // Un partido por hora, de 10:00 a 21:00
            $hora = 10 + ($indice % 12);
            $stmt->execute([
                ':fecha'     => sprintf('%s %02d:00:00', $fecha, $hora),
                ':torneo'    => $torneo['IdTorneo'],
                ':numero'    => $numero,
                ':local'     => $local,
                ':visitante' => $visitante,
            ]);
        }
    }

    /** Devuelve false si la ronda no existe */
    private function estadoRonda(int $idTorneo, int $numero, string $estado): bool
    {
        $stmt = $this->bd->prepare(
            "update Ronda set EstadoRonda = :estado where IdTorneo = :torneo and NumeroRonda = :numero"
        );
        $stmt->execute([':estado' => $estado, ':torneo' => $idTorneo, ':numero' => $numero]);

        return $stmt->rowCount() > 0;
    }

    /** Partidos con resultado validado, en el formato que reciben los módulos */
    private function partidosJugados(int $idTorneo): array
    {
        $stmt = $this->bd->prepare(
            "select Enfrentamiento.NumeroRonda            as ronda,
                    Enfrentamiento.IdInscripcionLocal     as local,
                    Enfrentamiento.IdInscripcionVisitante as visitante,
                    Resultado.Ganador                     as ganador
             from Enfrentamiento
             inner join Resultado on Enfrentamiento.IdEnfrentamiento = Resultado.IdEnfrentamiento
             where Enfrentamiento.IdTorneo = :torneo and Resultado.Validado = 1
             order by Enfrentamiento.NumeroRonda, Enfrentamiento.IdEnfrentamiento"
        );
        $stmt->execute([':torneo' => $idTorneo]);

        $partidos = [];
        foreach ($stmt as $fila) {
            $partidos[] = [
                'ronda'     => (int) $fila['ronda'],
                'local'     => (int) $fila['local'],
                'visitante' => (int) $fila['visitante'],
                'ganador'   => $fila['ganador'],
            ];
        }

        return $partidos;
    }

    /** Puntaje acumulado por inscripción */
    private function puntos(int $idTorneo): array
    {
        $stmt = $this->bd->prepare(
            "select TablaPosiciones.IdInscripcion, TablaPosiciones.PuntosAcumulados
             from TablaPosiciones
             where TablaPosiciones.IdTorneo = :torneo"
        );
        $stmt->execute([':torneo' => $idTorneo]);

        return array_map('intval', $stmt->fetchAll(PDO::FETCH_KEY_PAIR));
    }

    private function torneo(int $idTorneo): array
    {
        $stmt = $this->bd->prepare(
            "select Torneo.IdTorneo, Torneo.Estado, Torneo.FechaInicio, ModuloCompetencia.NombreModulo
             from Torneo
             inner join Configura         on Torneo.IdTorneo      = Configura.IdTorneo
                                         and Configura.Habilitado = 1
             inner join ModuloCompetencia on Configura.IdModulo   = ModuloCompetencia.IdModulo
             where Torneo.IdTorneo = :id"
        );
        $stmt->execute([':id' => $idTorneo]);

        $fila = $stmt->fetch();
        if (!$fila) {
            throw new DomainException('El torneo no existe.');
        }

        return $fila;
    }

    /** Torneo al que pertenece un partido; lo usan los controladores para comprobar el permiso */
    public function torneoDePartido(int $idEnfrentamiento): ?int
    {
        $stmt = $this->bd->prepare(
            "select Enfrentamiento.IdTorneo from Enfrentamiento where Enfrentamiento.IdEnfrentamiento = :id"
        );
        $stmt->execute([':id' => $idEnfrentamiento]);

        $id = $stmt->fetchColumn();

        return $id === false ? null : (int) $id;
    }

    private function partido(int $idEnfrentamiento): array
    {
        $stmt = $this->bd->prepare(
            "select Enfrentamiento.IdTorneo,
                    Torneo.Estado      as EstadoTorneo,
                    Ronda.EstadoRonda,
                    ModuloCompetencia.NombreModulo,
                    Resultado.IdResultado,
                    Resultado.Validado
             from Enfrentamiento
             inner join Torneo on Enfrentamiento.IdTorneo = Torneo.IdTorneo
             inner join Ronda  on Enfrentamiento.IdTorneo    = Ronda.IdTorneo
                              and Enfrentamiento.NumeroRonda = Ronda.NumeroRonda
             inner join Configura         on Torneo.IdTorneo      = Configura.IdTorneo
                                         and Configura.Habilitado = 1
             inner join ModuloCompetencia on Configura.IdModulo   = ModuloCompetencia.IdModulo
             left join Resultado on Enfrentamiento.IdEnfrentamiento = Resultado.IdEnfrentamiento
             where Enfrentamiento.IdEnfrentamiento = :id"
        );
        $stmt->execute([':id' => $idEnfrentamiento]);

        $fila = $stmt->fetch();
        if (!$fila) {
            throw new DomainException('El partido no existe.');
        }

        return $fila;
    }
}
