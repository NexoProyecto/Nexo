<?php
/** Usuario del sistema */
class Usuario
{
    private string $id;
    private string $nombre;
    private string $correo;
    private string $contrasenaHash;
    private string $rol;
    private string $estado;
    private bool $debeCambiarClave;

    public function __construct(
        string $id,
        string $nombre,
        string $correo,
        string $contrasenaHash,
        string $rol,
        string $estado = 'Activo',
        bool $debeCambiarClave = false
    ) {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->correo = $correo;
        $this->contrasenaHash = $contrasenaHash;
        $this->rol = $rol;
        $this->estado = $estado;
        $this->debeCambiarClave = $debeCambiarClave;
    }

    // Getters

    public function getId(): string
    {
        return $this->id;
    }

    public function getNombre(): string
    {
        return $this->nombre;
    }

    public function getCorreo(): string
    {
        return $this->correo;
    }

    public function getRol(): string
    {
        return $this->rol;
    }

    public function getEstado(): string
    {
        return $this->estado;
    }

    public function getContrasenaHash(): string
    {
        return $this->contrasenaHash;
    }

    /** Contraseña provisional o vencida */
    public function debeCambiarClave(): bool
    {
        return $this->debeCambiarClave;
    }

    public function verificarContrasena(string $intento): bool
    {
        return password_verify($intento, $this->contrasenaHash);
    }
}