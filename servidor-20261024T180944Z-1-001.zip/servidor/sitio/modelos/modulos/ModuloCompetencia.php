<?php
/**
 * Módulo de competencia: reglas de un tipo de torneo.
 *
 * Cada módulo arma los cruces de sus rondas y define el puntaje. Trabaja solo con
 * identificadores de inscripción y no consulta la base: los datos se los pasa GestorCompetencia.
 *
 * Un cruce es un arreglo [local, visitante]. Un partido jugado es un arreglo con las claves
 * ronda, local, visitante y ganador (LOCAL, VISITANTE o EMPATE).
 */
abstract class ModuloCompetencia
{
    /** Código de la tabla ModuloCompetencia: LIGA, ELIMINATORIA o SUIZO */
    abstract public function codigo(): string;

    abstract public function puntosVictoria(): int;

    abstract public function puntosEmpate(): int;

    /** Rondas que se crean al iniciar el torneo: una lista de cruces por ronda */
    abstract public function rondasIniciales(array $inscripciones): array;

    /**
     * Cruces de la ronda que sigue a las ya cerradas, o null si el torneo terminó.
     * $puntos: puntaje acumulado por inscripción.
     */
    abstract public function rondaSiguiente(array $inscripciones, array $partidos, array $puntos): ?array;

    public function admiteEmpate(): bool
    {
        return true;
    }

    /** En el sistema suizo, la inscripción que queda libre en una ronda suma una victoria */
    public function puntuaRondaLibre(): bool
    {
        return false;
    }

    public static function crear(string $codigo): ModuloCompetencia
    {
        return match ($codigo) {
            'LIGA'         => new ModuloLiga(),
            'ELIMINATORIA' => new ModuloEliminatoria(),
            'SUIZO'        => new ModuloSuizo(),
            default        => throw new InvalidArgumentException(
                'Módulo desconocido: ' . $codigo
            ),
        };
    }
}

require_once __DIR__ . '/ModuloLiga.php';
require_once __DIR__ . '/ModuloEliminatoria.php';
require_once __DIR__ . '/ModuloSuizo.php';
