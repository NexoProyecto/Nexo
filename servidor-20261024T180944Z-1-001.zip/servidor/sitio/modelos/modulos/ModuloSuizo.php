<?php
/** Sistema suizo: nadie queda eliminado y en cada ronda se cruzan los de puntaje más parecido */
class ModuloSuizo extends ModuloCompetencia
{
    public function codigo(): string
    {
        return 'SUIZO';
    }

    public function puntosVictoria(): int
    {
        return 2;
    }

    public function puntosEmpate(): int
    {
        return 1;
    }

    public function puntuaRondaLibre(): bool
    {
        return true;
    }

    /** Cantidad de rondas: las que hacen falta para que quede un solo invicto */
    public function totalRondas(int $cantidad): int
    {
        $rondas = 1;
        while (2 ** $rondas < $cantidad) {
            $rondas++;
        }
        return $rondas;
    }

    /** Primera ronda: la mitad de arriba de la lista contra la mitad de abajo */
    public function rondasIniciales(array $inscripciones): array
    {
        $inscripciones = array_values($inscripciones);
        if (count($inscripciones) % 2 === 1) {
            array_pop($inscripciones);
        }

        $mitad  = intdiv(count($inscripciones), 2);
        $cruces = [];
        for ($i = 0; $i < $mitad; $i++) {
            $cruces[] = [$inscripciones[$i], $inscripciones[$i + $mitad]];
        }

        return [$cruces];
    }

    public function rondaSiguiente(array $inscripciones, array $partidos, array $puntos): ?array
    {
        $jugadas = 0;
        $rivales = [];
        $conPartido = [];
        foreach ($partidos as $partido) {
            $jugadas = max($jugadas, $partido['ronda']);
            $rivales[$partido['local']][]     = $partido['visitante'];
            $rivales[$partido['visitante']][] = $partido['local'];
            $conPartido[$partido['ronda']][]  = $partido['local'];
            $conPartido[$partido['ronda']][]  = $partido['visitante'];
        }

        if ($jugadas >= $this->totalRondas(count($inscripciones))) {
            return null;
        }

        // Orden por puntaje; a igual puntaje, por orden de inscripción
        $orden = array_values($inscripciones);
        usort($orden, function ($a, $b) use ($puntos) {
            return [($puntos[$b] ?? 0), $a] <=> [($puntos[$a] ?? 0), $b];
        });

        // Con cantidad impar queda libre uno que todavía no quedó libre, empezando por el de menor puntaje
        $candidatosALibre = [null];
        if (count($orden) % 2 === 1) {
            $yaLibres = [];
            foreach ($conPartido as $enLaRonda) {
                $yaLibres = array_merge($yaLibres, array_diff($inscripciones, $enLaRonda));
            }
            $candidatosALibre = array_values(array_diff(array_reverse($orden), $yaLibres));
            if (count($candidatosALibre) === 0) {
                $candidatosALibre = [end($orden)];
            }
        }

        // Se prueba con cada candidato hasta encontrar cruces sin partidos repetidos
        foreach ($candidatosALibre as $libre) {
            $this->intentos = 0;
            $cruces = $this->emparejar(array_values(array_diff($orden, [$libre])), $rivales);
            if ($cruces !== null) {
                return $cruces;
            }
        }

        // Sin combinación posible, se admite repetir un rival
        return $this->emparejar(array_values(array_diff($orden, [$candidatosALibre[0]])), []);
    }

    /** Tope de combinaciones que se prueban por ronda */
    private const INTENTOS_MAXIMOS = 20000;

    private int $intentos = 0;

    /**
     * Cruza al primero de la lista con el siguiente con el que todavía no jugó y sigue con el
     * resto. Si el resto queda sin combinación, vuelve atrás y prueba con otro rival.
     * Devuelve null si no hay forma de cruzar a todos sin repetir.
     */
    private function emparejar(array $orden, array $rivales): ?array
    {
        if (count($orden) === 0) {
            return [];
        }
        if (++$this->intentos > self::INTENTOS_MAXIMOS) {
            return null;
        }

        $uno = array_shift($orden);

        foreach ($orden as $posicion => $candidato) {
            if (in_array($candidato, $rivales[$uno] ?? [], true)) {
                continue;
            }
            $resto = $orden;
            array_splice($resto, $posicion, 1);

            $siguientes = $this->emparejar($resto, $rivales);
            if ($siguientes !== null) {
                return array_merge([[$uno, $candidato]], $siguientes);
            }
        }

        return null;
    }
}
