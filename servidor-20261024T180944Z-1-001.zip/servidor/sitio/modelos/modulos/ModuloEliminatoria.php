<?php
/** Eliminación directa: el que pierde queda fuera y los ganadores se cruzan en la ronda siguiente */
class ModuloEliminatoria extends ModuloCompetencia
{
    public function codigo(): string
    {
        return 'ELIMINATORIA';
    }

    public function puntosVictoria(): int
    {
        return 1;
    }

    public function puntosEmpate(): int
    {
        return 0;
    }

    public function admiteEmpate(): bool
    {
        return false;
    }

    /**
     * Primera ronda. Si la cantidad no es potencia de 2, los primeros inscriptos pasan
     * directo a la segunda ronda, que así queda con una potencia de 2.
     */
    public function rondasIniciales(array $inscripciones): array
    {
        $inscripciones = array_values($inscripciones);
        $cantidad = count($inscripciones);

        $llave = 1;
        while ($llave < $cantidad) {
            $llave *= 2;
        }
        $libres = $llave - $cantidad;

        return [$this->cruzar(array_slice($inscripciones, $libres))];
    }

    public function rondaSiguiente(array $inscripciones, array $partidos, array $puntos): ?array
    {
        $eliminados = [];
        foreach ($partidos as $partido) {
            $eliminados[] = $partido['ganador'] === 'LOCAL' ? $partido['visitante'] : $partido['local'];
        }

        $siguen = array_values(array_diff($inscripciones, $eliminados));

        return count($siguen) < 2 ? null : $this->cruzar($siguen);
    }

    /** Cruza de a dos, en el orden de la lista */
    private function cruzar(array $lista): array
    {
        $cruces = [];
        for ($i = 0; $i + 1 < count($lista); $i += 2) {
            $cruces[] = [$lista[$i], $lista[$i + 1]];
        }
        return $cruces;
    }
}
