<?php
/** Liga: todos contra todos a una rueda, con el calendario completo desde el inicio */
class ModuloLiga extends ModuloCompetencia
{
    public function codigo(): string
    {
        return 'LIGA';
    }

    public function puntosVictoria(): int
    {
        return 3;
    }

    public function puntosEmpate(): int
    {
        return 1;
    }

    /**
     * Método del círculo: el primero queda fijo y los demás rotan un lugar por ronda.
     * Con cantidad impar se agrega un lugar vacío; quien lo enfrenta queda libre esa ronda.
     */
    public function rondasIniciales(array $inscripciones): array
    {
        $lugares = array_values($inscripciones);
        if (count($lugares) % 2 === 1) {
            $lugares[] = null;
        }

        $cantidad = count($lugares);
        $rondas   = [];

        for ($ronda = 0; $ronda < $cantidad - 1; $ronda++) {
            $cruces = [];
            for ($i = 0; $i < $cantidad / 2; $i++) {
                $uno = $lugares[$i];
                $dos = $lugares[$cantidad - 1 - $i];
                if ($uno === null || $dos === null) {
                    continue;
                }
                // La localía se alterna de una ronda a la otra
                $cruces[] = ($ronda + $i) % 2 === 0 ? [$uno, $dos] : [$dos, $uno];
            }
            $rondas[] = $cruces;

            $ultimo = array_pop($lugares);
            array_splice($lugares, 1, 0, [$ultimo]);
        }

        return $rondas;
    }

    public function rondaSiguiente(array $inscripciones, array $partidos, array $puntos): ?array
    {
        return null;
    }
}
