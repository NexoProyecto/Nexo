<?php
require_once __DIR__ . '/ConexionBD.php';

/** Inscripciones de participantes en torneos: tabla Inscripcion */
class GestorInscripciones
{
    /** Estado: código => texto */
    private const ESTADO = "case Inscripcion.EstadoInscripcion
                                when 'PENDIENTE' then 'Pendiente'
                                when 'ACEPTADA'  then 'Aceptada'
                                else 'Rechazada'
                            end";

    private PDO $bd;

    public function __construct(?PDO $conexion = null)
    {
        $this->bd = $conexion ?? ConexionBD::obtener();
    }

    public function listarDeTorneo(int $idTorneo): array
    {
        $stmt = $this->bd->prepare(
            "select Inscripcion.IdInscripcion     as id,
                    Inscripcion.FechaInscripcion  as fecha,
                    Inscripcion.EstadoInscripcion as estado_codigo,
                    " . self::ESTADO . "          as estado,
                    Participante.IdParticipante     as id_participante,
                    Participante.NombreParticipante as participante,
                    Participante.PerfilPublico      as perfil_publico
             from Inscripcion
             inner join Participante on Inscripcion.IdParticipante = Participante.IdParticipante
             where Inscripcion.IdTorneo = :torneo
             order by Inscripcion.IdInscripcion"
        );
        $stmt->execute([':torneo' => $idTorneo]);

        return $stmt->fetchAll();
    }

    /** Identificadores de las inscripciones aceptadas, en orden de inscripción */
    public function aceptadas(int $idTorneo): array
    {
        $stmt = $this->bd->prepare(
            "select Inscripcion.IdInscripcion
             from Inscripcion
             where Inscripcion.IdTorneo = :torneo
               and Inscripcion.EstadoInscripcion = 'ACEPTADA'
             order by Inscripcion.IdInscripcion"
        );
        $stmt->execute([':torneo' => $idTorneo]);

        return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
    }

    /** Torneos de un participante, con su posición en la tabla */
    public function listarDeParticipante(int $idParticipante): array
    {
        $stmt = $this->bd->prepare(
            "select Inscripcion.IdInscripcion     as id,
                    Inscripcion.EstadoInscripcion as estado_codigo,
                    " . self::ESTADO . "          as estado,
                    Torneo.IdTorneo               as id_torneo,
                    Torneo.NombreTorneo           as torneo,
                    Torneo.Estado                 as estado_torneo,
                    TablaPosiciones.PartidosJugados  as jugados,
                    TablaPosiciones.Victorias        as ganados,
                    TablaPosiciones.PuntosAcumulados as puntos,
                    (select count(*) + 1
                       from TablaPosiciones Otra
                      where Otra.IdTorneo = TablaPosiciones.IdTorneo
                        and (Otra.PuntosAcumulados > TablaPosiciones.PuntosAcumulados
                             or (Otra.PuntosAcumulados = TablaPosiciones.PuntosAcumulados
                                 and Otra.Victorias > TablaPosiciones.Victorias))) as posicion
             from Inscripcion
             inner join Torneo on Inscripcion.IdTorneo = Torneo.IdTorneo
             left join TablaPosiciones on Inscripcion.IdInscripcion = TablaPosiciones.IdInscripcion
             where Inscripcion.IdParticipante = :participante
             order by Torneo.FechaInicio desc"
        );
        $stmt->execute([':participante' => $idParticipante]);

        return $stmt->fetchAll();
    }

    /** Partidos de un participante: los programados o los ya jugados y validados */
    public function partidosDeParticipante(int $idParticipante, bool $jugados): array
    {
        $sql = "select Enfrentamiento.FechaHora    as fecha_hora,
                       Enfrentamiento.NumeroRonda  as ronda,
                       Torneo.IdTorneo             as id_torneo,
                       Torneo.NombreTorneo         as torneo,
                       PartLocal.NombreParticipante  as local,
                       PartVisita.NombreParticipante as visitante,
                       Resultado.PuntuacionLocal     as puntos_local,
                       Resultado.PuntuacionVisitante as puntos_visitante
                from Enfrentamiento
                inner join Torneo on Enfrentamiento.IdTorneo = Torneo.IdTorneo
                inner join Inscripcion  InsLocal   on Enfrentamiento.IdInscripcionLocal
                                                    = InsLocal.IdInscripcion
                inner join Participante PartLocal  on InsLocal.IdParticipante
                                                    = PartLocal.IdParticipante
                inner join Inscripcion  InsVisita  on Enfrentamiento.IdInscripcionVisitante
                                                    = InsVisita.IdInscripcion
                inner join Participante PartVisita on InsVisita.IdParticipante
                                                    = PartVisita.IdParticipante
                left join Resultado on Enfrentamiento.IdEnfrentamiento = Resultado.IdEnfrentamiento
                where (InsLocal.IdParticipante = :uno or InsVisita.IdParticipante = :dos)";

        $sql .= $jugados
            ? " and Resultado.Validado = 1 order by Enfrentamiento.FechaHora desc limit 20"
            : " and Enfrentamiento.EstadoPartido = 'PROGRAMADO' and Torneo.Estado = 'EN CURSO'
                order by Enfrentamiento.FechaHora limit 20";

        $stmt = $this->bd->prepare($sql);
        $stmt->execute([':uno' => $idParticipante, ':dos' => $idParticipante]);

        return $stmt->fetchAll();
    }

    /** Torneos con inscripciones abiertas en los que el participante no está inscripto */
    public function torneosDisponibles(int $idParticipante): array
    {
        $stmt = $this->bd->prepare(
            "select Torneo.IdTorneo     as id,
                    Torneo.NombreTorneo as nombre,
                    Torneo.FechaInicio  as fecha_inicio
             from Torneo
             where Torneo.Estado = 'ABIERTO'
               and Torneo.IdTorneo not in (select Inscripcion.IdTorneo
                                             from Inscripcion
                                            where Inscripcion.IdParticipante = :participante)
             order by Torneo.FechaInicio"
        );
        $stmt->execute([':participante' => $idParticipante]);

        return $stmt->fetchAll();
    }

    /**
     * Inscribe a un participante en un torneo con inscripciones abiertas.
     * Devuelve false si el torneo no las tiene abiertas o si ya estaba inscripto (RNE8).
     */
    public function inscribir(int $idTorneo, int $idParticipante, string $estado = 'PENDIENTE'): bool
    {
        try {
            $stmt = $this->bd->prepare(
                "insert into Inscripcion (FechaInscripcion, EstadoInscripcion, IdTorneo, IdParticipante)
                 select curdate(), :estado, Torneo.IdTorneo, :participante
                 from Torneo
                 where Torneo.IdTorneo = :torneo and Torneo.Estado = 'ABIERTO'"
            );
            $stmt->execute([
                ':estado'       => $estado,
                ':participante' => $idParticipante,
                ':torneo'       => $idTorneo,
            ]);
        } catch (PDOException $e) {
            return false;
        }

        return $stmt->rowCount() > 0;
    }

    /** Acepta o rechaza una inscripción de un torneo con inscripciones abiertas */
    public function resolver(int $idInscripcion, int $idTorneo, string $estado): bool
    {
        $stmt = $this->bd->prepare(
            "update Inscripcion
             inner join Torneo on Inscripcion.IdTorneo = Torneo.IdTorneo
             set Inscripcion.EstadoInscripcion = :estado
             where Inscripcion.IdInscripcion = :id
               and Inscripcion.IdTorneo = :torneo
               and Torneo.Estado = 'ABIERTO'"
        );
        $stmt->execute([':estado' => $estado, ':id' => $idInscripcion, ':torneo' => $idTorneo]);

        return $stmt->rowCount() > 0;
    }
}
