<?php
require_once __DIR__ . '/ConexionBD.php';
require_once __DIR__ . '/GestorParticipantes.php';
require_once __DIR__ . '/GestorInscripciones.php';

/**
 * Solicitudes de equipo: tabla SolicitudEquipo.
 * INTEGRAR: un participante pide entrar a un equipo existente o a uno nuevo con el nombre que propone.
 * INSCRIBIR: un integrante pide inscribir a su equipo en un torneo con inscripciones abiertas.
 * Los pedidos iguales forman un grupo y se resuelven juntos.
 */
class GestorSolicitudesEquipo
{
    /** Pedidos pendientes que admite cada participante a la vez */
    public const MAXIMO_PENDIENTES = 10;

    // Resultado de un pedido
    public const ENVIADA          = 'enviada';
    public const YA_INTEGRA       = 'ya_integra';
    public const NO_INTEGRA       = 'no_integra';
    public const REPETIDA         = 'repetida';
    public const DEMASIADAS       = 'demasiadas';
    public const SIN_EQUIPO       = 'sin_equipo';
    public const TORNEO_CERRADO   = 'torneo_cerrado';
    public const YA_INSCRIPTO     = 'ya_inscripto';

    private PDO $bd;

    public function __construct(?PDO $conexion = null)
    {
        $this->bd = $conexion ?? ConexionBD::obtener();
    }

    /** Nombre comparable: sin mayúsculas, sin tildes y con un solo espacio entre palabras */
    public static function nombreComparable(string $nombre): string
    {
        $nombre = mb_strtolower(trim(preg_replace('/\s+/u', ' ', $nombre)));

        return strtr($nombre, ['á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ü' => 'u']);
    }

    /**
     * Pedido para integrar un equipo existente ($idEquipo) o uno nuevo ($nombre).
     * Un nombre igual al de un equipo existente se toma como pedido para ese equipo.
     */
    public function solicitarIntegrar(int $idParticipante, ?int $idEquipo, ?string $nombre): string
    {
        $participantes = new GestorParticipantes($this->bd);

        if ($idEquipo === null && $nombre !== null) {
            $existente = $participantes->buscarEquipoPorNombre($nombre);
            if ($existente !== null) {
                $idEquipo = (int) $existente['id'];
                $nombre   = null;
            }
        }

        if ($idEquipo !== null) {
            if ($participantes->obtenerEquipo($idEquipo) === null) {
                return self::SIN_EQUIPO;
            }
            if ($participantes->integra($idEquipo, $idParticipante)) {
                return self::YA_INTEGRA;
            }
        }

        foreach ($this->pendientesDe($idParticipante) as $pendiente) {
            if ($pendiente['tipo'] !== 'INTEGRAR') {
                continue;
            }
            $mismoEquipo = $idEquipo !== null && (int) $pendiente['id_equipo'] === $idEquipo;
            $mismoNombre = $nombre !== null && $pendiente['nombre_propuesto'] !== null
                && self::nombreComparable($pendiente['nombre_propuesto']) === self::nombreComparable($nombre);
            if ($mismoEquipo || $mismoNombre) {
                return self::REPETIDA;
            }
        }

        return $this->insertar('INTEGRAR', $idParticipante, $idEquipo, $idEquipo === null ? $nombre : null, null);
    }

    /** Pedido para inscribir al equipo en un torneo; solo lo envía un integrante */
    public function solicitarInscribir(int $idParticipante, int $idEquipo, int $idTorneo): string
    {
        $participantes = new GestorParticipantes($this->bd);

        if (!$participantes->integra($idEquipo, $idParticipante)) {
            return self::NO_INTEGRA;
        }

        $stmt = $this->bd->prepare("select Estado from Torneo where IdTorneo = :torneo");
        $stmt->execute([':torneo' => $idTorneo]);
        if ($stmt->fetchColumn() !== 'ABIERTO') {
            return self::TORNEO_CERRADO;
        }

        $stmt = $this->bd->prepare(
            "select count(*) from Inscripcion
             inner join Equipo on Inscripcion.IdParticipante = Equipo.IdParticipante
             where Equipo.IdEquipo = :equipo and Inscripcion.IdTorneo = :torneo"
        );
        $stmt->execute([':equipo' => $idEquipo, ':torneo' => $idTorneo]);
        if ((int) $stmt->fetchColumn() > 0) {
            return self::YA_INSCRIPTO;
        }

        foreach ($this->pendientesDe($idParticipante) as $pendiente) {
            if ($pendiente['tipo'] === 'INSCRIBIR' && (int) $pendiente['id_equipo'] === $idEquipo
                && (int) $pendiente['id_torneo'] === $idTorneo) {
                return self::REPETIDA;
            }
        }

        return $this->insertar('INSCRIBIR', $idParticipante, $idEquipo, null, $idTorneo);
    }

    private function insertar(string $tipo, int $idParticipante, ?int $idEquipo, ?string $nombre,
                              ?int $idTorneo): string
    {
        if (count($this->pendientesDe($idParticipante)) >= self::MAXIMO_PENDIENTES) {
            return self::DEMASIADAS;
        }

        $stmt = $this->bd->prepare(
            "insert into SolicitudEquipo (TipoSolicitud, NombrePropuesto, IdParticipante, IdEquipo, IdTorneo)
             values (:tipo, :nombre, :participante, :equipo, :torneo)"
        );
        $stmt->execute([
            ':tipo'         => $tipo,
            ':nombre'       => $nombre,
            ':participante' => $idParticipante,
            ':equipo'       => $idEquipo,
            ':torneo'       => $idTorneo,
        ]);

        return self::ENVIADA;
    }

    private const COLUMNAS = "SolicitudEquipo.IdSolicitudEquipo as id,
                    SolicitudEquipo.TipoSolicitud     as tipo,
                    SolicitudEquipo.EstadoSolicitud   as estado,
                    SolicitudEquipo.NombrePropuesto   as nombre_propuesto,
                    SolicitudEquipo.FechaSolicitud    as fecha,
                    SolicitudEquipo.FechaResolucion   as fecha_resolucion,
                    SolicitudEquipo.IdParticipante    as id_participante,
                    Participante.NombreParticipante   as participante,
                    SolicitudEquipo.IdEquipo          as id_equipo,
                    Equipo.NombreEquipo               as equipo,
                    SolicitudEquipo.IdTorneo          as id_torneo,
                    Torneo.NombreTorneo               as torneo
             from SolicitudEquipo
             inner join Participante on SolicitudEquipo.IdParticipante = Participante.IdParticipante
             left join Equipo on SolicitudEquipo.IdEquipo = Equipo.IdEquipo
             left join Torneo on SolicitudEquipo.IdTorneo = Torneo.IdTorneo";

    /** Pedidos de un participante, los más recientes primero */
    public function deParticipante(int $idParticipante): array
    {
        $stmt = $this->bd->prepare(
            "select " . self::COLUMNAS . "
             where SolicitudEquipo.IdParticipante = :participante
             order by SolicitudEquipo.FechaSolicitud desc, SolicitudEquipo.IdSolicitudEquipo desc
             limit 30"
        );
        $stmt->execute([':participante' => $idParticipante]);

        return $stmt->fetchAll();
    }

    private function pendientesDe(int $idParticipante): array
    {
        return array_values(array_filter(
            $this->deParticipante($idParticipante),
            fn ($s) => $s['estado'] === 'PENDIENTE'
        ));
    }

    /**
     * Pedidos pendientes agrupados: los iguales (mismo equipo, mismo nombre nuevo o mismo
     * equipo y torneo) quedan en un solo grupo. Con $idOrganizador, los de inscripción se
     * limitan a los torneos que ese usuario organiza; el administrador pasa null y ve todos.
     * Devuelve ['INTEGRAR' => grupos, 'INSCRIBIR' => grupos]
     */
    public function pendientesAgrupados(?int $idOrganizador): array
    {
        $sql = "select " . self::COLUMNAS . "
                where SolicitudEquipo.EstadoSolicitud = 'PENDIENTE'";
        $parametros = [];

        if ($idOrganizador !== null) {
            $sql .= " and (SolicitudEquipo.TipoSolicitud = 'INTEGRAR'
                           or Torneo.IdUsuario = :creador
                           or exists (select 1 from Organiza
                                       where Organiza.IdTorneo = Torneo.IdTorneo
                                         and Organiza.IdUsuario = :organizador
                                         and Organiza.EstadoOrganiza = 'ACEPTADA'))";
            $parametros = [':creador' => $idOrganizador, ':organizador' => $idOrganizador];
        }
        $sql .= " order by SolicitudEquipo.FechaSolicitud, SolicitudEquipo.IdSolicitudEquipo";

        $stmt = $this->bd->prepare($sql);
        $stmt->execute($parametros);

        $grupos = ['INTEGRAR' => [], 'INSCRIBIR' => []];
        foreach ($stmt->fetchAll() as $s) {
            if ($s['tipo'] === 'INSCRIBIR') {
                $clave = $s['id_equipo'] . '-' . $s['id_torneo'];
            } elseif ($s['id_equipo'] !== null) {
                $clave = 'equipo-' . $s['id_equipo'];
            } else {
                $clave = 'nuevo-' . self::nombreComparable($s['nombre_propuesto']);
            }

            if (!isset($grupos[$s['tipo']][$clave])) {
                $grupos[$s['tipo']][$clave] = [
                    'ids'         => [],
                    'solicitantes' => [],
                    'equipo'      => $s['equipo'],
                    'id_equipo'   => $s['id_equipo'],
                    'torneo'      => $s['torneo'],
                    'nombres'     => [],
                    'desde'       => $s['fecha'],
                ];
            }
            $grupo = &$grupos[$s['tipo']][$clave];
            $grupo['ids'][]          = (int) $s['id'];
            $grupo['solicitantes'][] = $s['participante'];
            if ($s['nombre_propuesto'] !== null && !in_array($s['nombre_propuesto'], $grupo['nombres'], true)) {
                $grupo['nombres'][] = $s['nombre_propuesto'];
            }
            unset($grupo);
        }

        return ['INTEGRAR' => array_values($grupos['INTEGRAR']), 'INSCRIBIR' => array_values($grupos['INSCRIBIR'])];
    }

    /** Equipos con pedidos de inscripción pendientes en el torneo */
    public function equiposPendientesDeTorneo(int $idTorneo): int
    {
        $stmt = $this->bd->prepare(
            "select count(distinct IdEquipo) from SolicitudEquipo
             where IdTorneo = :torneo and EstadoSolicitud = 'PENDIENTE'"
        );
        $stmt->execute([':torneo' => $idTorneo]);

        return (int) $stmt->fetchColumn();
    }

    /** Pedidos pendientes con esos identificadores */
    public function pendientesPorId(array $ids): array
    {
        $ids = array_values(array_unique(array_map('intval', $ids)));
        if (count($ids) === 0) {
            return [];
        }

        $marcas = implode(', ', array_fill(0, count($ids), '?'));
        $stmt   = $this->bd->prepare(
            "select " . self::COLUMNAS . "
             where SolicitudEquipo.EstadoSolicitud = 'PENDIENTE'
               and SolicitudEquipo.IdSolicitudEquipo in ($marcas)"
        );
        $stmt->execute($ids);

        return $stmt->fetchAll();
    }

    /**
     * Aprueba pedidos para integrar, todos en el mismo equipo. Si $nombre trae un nombre,
     * ese es el equipo (existente o nuevo); si no, el equipo de los pedidos o el nombre que
     * propusieron. Devuelve el identificador del equipo o null si no se puede determinar.
     */
    public function aprobarIntegrar(array $solicitudes, ?string $nombre, bool $perfilPublico, int $idUsuario): ?int
    {
        $participantes = new GestorParticipantes($this->bd);

        if ($nombre === null) {
            $equipos = array_unique(array_filter(array_column($solicitudes, 'id_equipo'), fn ($e) => $e !== null));
            $nombres = array_unique(array_map(
                [self::class, 'nombreComparable'],
                array_filter(array_column($solicitudes, 'nombre_propuesto'), fn ($n) => $n !== null)
            ));
            if (count($equipos) === 1 && count($nombres) === 0) {
                $idEquipo = (int) reset($equipos);
            } elseif (count($equipos) === 0 && count($nombres) === 1) {
                $nombre = $solicitudes[0]['nombre_propuesto'];
            } else {
                return null;
            }
        }

        $this->bd->beginTransaction();
        try {
            if ($nombre !== null) {
                $existente = $participantes->buscarEquipoPorNombre($nombre);
                $idEquipo  = $existente !== null
                    ? (int) $existente['id']
                    : $participantes->crearEquipo($nombre, $perfilPublico);
            }

            foreach ($solicitudes as $s) {
                $participantes->agregarIntegrante($idEquipo, (int) $s['id_participante']);
            }
            $this->marcar(array_column($solicitudes, 'id'), 'APROBADA', $idUsuario, $idEquipo);
            $this->bd->commit();
        } catch (Throwable $e) {
            $this->bd->rollBack();
            throw $e;
        }

        return $idEquipo;
    }

    /**
     * Aprueba pedidos de inscripción del mismo equipo en el mismo torneo: inscribe al
     * representante del equipo, aceptado. Devuelve false si el torneo ya no tiene
     * inscripciones abiertas
     */
    public function aprobarInscribir(array $solicitudes, int $idUsuario): bool
    {
        $idEquipo = (int) $solicitudes[0]['id_equipo'];
        $idTorneo = (int) $solicitudes[0]['id_torneo'];

        $this->bd->beginTransaction();
        try {
            $representante = (new GestorParticipantes($this->bd))->representante($idEquipo);
            $inscripto     = (new GestorInscripciones($this->bd))->inscribir($idTorneo, $representante, 'ACEPTADA');

            if (!$inscripto) {
                // Ya tenía una inscripción (pedida o rechazada): queda aceptada si el torneo sigue abierto
                $stmt = $this->bd->prepare(
                    "update Inscripcion
                     inner join Torneo on Inscripcion.IdTorneo = Torneo.IdTorneo
                     set Inscripcion.EstadoInscripcion = 'ACEPTADA'
                     where Inscripcion.IdTorneo = :torneo and Inscripcion.IdParticipante = :participante
                       and Torneo.Estado = 'ABIERTO'"
                );
                $stmt->execute([':torneo' => $idTorneo, ':participante' => $representante]);
                $existe = $this->bd->prepare(
                    "select count(*) from Inscripcion
                     inner join Torneo on Inscripcion.IdTorneo = Torneo.IdTorneo
                     where Inscripcion.IdTorneo = :torneo and Inscripcion.IdParticipante = :participante
                       and Torneo.Estado = 'ABIERTO'"
                );
                $existe->execute([':torneo' => $idTorneo, ':participante' => $representante]);
                if ((int) $existe->fetchColumn() === 0) {
                    $this->bd->rollBack();
                    return false;
                }
            }

            $this->marcar(array_column($solicitudes, 'id'), 'APROBADA', $idUsuario, $idEquipo);
            $this->bd->commit();
        } catch (Throwable $e) {
            $this->bd->rollBack();
            throw $e;
        }

        return true;
    }

    public function rechazar(array $ids, int $idUsuario): void
    {
        $this->marcar($ids, 'RECHAZADA', $idUsuario, null);
    }

    /** Resuelve los pedidos; con $idEquipo, deja anotado el equipo en el que quedaron */
    private function marcar(array $ids, string $estado, int $idUsuario, ?int $idEquipo): void
    {
        $stmt = $this->bd->prepare(
            "update SolicitudEquipo
             set EstadoSolicitud = :estado, FechaResolucion = now(), IdUsuarioResuelve = :usuario,
                 IdEquipo = coalesce(:equipo, IdEquipo)
             where IdSolicitudEquipo = :id and EstadoSolicitud = 'PENDIENTE'"
        );
        foreach ($ids as $id) {
            $stmt->execute([':estado' => $estado, ':usuario' => $idUsuario, ':equipo' => $idEquipo, ':id' => (int) $id]);
        }
    }
}
