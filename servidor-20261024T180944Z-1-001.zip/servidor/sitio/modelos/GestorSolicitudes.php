<?php
require_once __DIR__ . '/ConexionBD.php';

/** Solicitudes de cuenta: tabla SolicitudCuenta */
class GestorSolicitudes
{
    /** Rol: texto => código de la tabla Rol */
    private const CODIGO_ROL = [
        'Administrador general' => 'ADMINISTRADOR',
        'Organizador de torneo' => 'ORGANIZADOR',
        'Participante'          => 'PARTICIPANTE',
    ];

    /** Roles que se pueden pedir desde la pantalla de solicitud */
    public const ROLES_SOLICITABLES = ['Participante', 'Organizador de torneo'];

    private PDO $bd;

    public function __construct(?PDO $conexion = null)
    {
        $this->bd = $conexion ?? ConexionBD::obtener();
    }

    /**
     * Registra el pedido. Devuelve false, sin guardar nada, si el correo ya tiene cuenta
     * o una solicitud pendiente; quien pide recibe la misma respuesta en los dos casos.
     */
    public function registrar(string $nombre, string $apellido, string $correo, string $hash,
                              string $rol, ?string $motivo): bool
    {
        if (!in_array($rol, self::ROLES_SOLICITABLES, true) || $this->correoOcupado($correo)) {
            return false;
        }

        $stmt = $this->bd->prepare(
            "insert into SolicitudCuenta (Nombre, Apellido, Email, Password, Motivo, IdRolTentativo)
             select :nombre, :apellido, :correo, :hash, :motivo, Rol.IdRol
             from Rol where Rol.NombreRol = :rol"
        );
        $stmt->execute([
            ':nombre'   => $nombre,
            ':apellido' => $apellido,
            ':correo'   => $correo,
            ':hash'     => $hash,
            ':motivo'   => $motivo,
            ':rol'      => self::CODIGO_ROL[$rol],
        ]);

        return $stmt->rowCount() > 0;
    }

    /** El correo ya tiene cuenta o una solicitud pendiente */
    public function correoOcupado(string $correo): bool
    {
        $stmt = $this->bd->prepare(
            "select (select count(*) from Usuario where lower(Email) = lower(:correo1))
                  + (select count(*) from SolicitudCuenta
                     where EstadoSolicitud = 'PENDIENTE' and lower(Email) = lower(:correo2))"
        );
        $stmt->execute([':correo1' => $correo, ':correo2' => $correo]);

        return (int) $stmt->fetchColumn() > 0;
    }

    public function listarPendientes(): array
    {
        return $this->bd->query(self::select() . " where SolicitudCuenta.EstadoSolicitud = 'PENDIENTE'
                                                  order by SolicitudCuenta.FechaSolicitud")->fetchAll();
    }

    public function listarResueltas(int $limite = 20): array
    {
        $stmt = $this->bd->prepare(self::select() . " where SolicitudCuenta.EstadoSolicitud <> 'PENDIENTE'
                                                     order by SolicitudCuenta.FechaResolucion desc
                                                     limit :limite");
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    /**
     * Da de alta la cuenta con el rol que decide el administrador y la contraseña que eligió
     * quien la pidió. Un participante queda con su ficha de participante vinculada.
     * Devuelve el identificador de la cuenta, o null si la solicitud no está pendiente o el
     * correo ya tiene cuenta.
     */
    public function aprobar(int $idSolicitud, string $rol, int $idAdministrador): ?int
    {
        if (!isset(self::CODIGO_ROL[$rol])) {
            return null;
        }

        $this->bd->beginTransaction();

        try {
            // La fila queda bloqueada: dos aprobaciones simultáneas no crean dos cuentas
            $stmt = $this->bd->prepare(
                "select Nombre, Apellido, Email, Password from SolicitudCuenta
                 where IdSolicitud = :id and EstadoSolicitud = 'PENDIENTE' for update"
            );
            $stmt->execute([':id' => $idSolicitud]);
            $solicitud = $stmt->fetch();

            if (!$solicitud) {
                $this->bd->rollBack();
                return null;
            }

            $stmt = $this->bd->prepare("select count(*) from Usuario where lower(Email) = lower(:correo)");
            $stmt->execute([':correo' => $solicitud['Email']]);
            if ((int) $stmt->fetchColumn() > 0) {
                $this->bd->rollBack();
                return null;
            }

            $stmt = $this->bd->prepare(
                "insert into Usuario (Nombre, Apellido, Email, Password, Estado,
                                      FechaAlta, FechaClave, CambioObligatorio, IdRol)
                 select :nombre, :apellido, :correo, :hash, 'ACTIVO', curdate(), curdate(), 0, Rol.IdRol
                 from Rol where Rol.NombreRol = :rol"
            );
            $stmt->execute([
                ':nombre'   => $solicitud['Nombre'],
                ':apellido' => $solicitud['Apellido'],
                ':correo'   => $solicitud['Email'],
                ':hash'     => $solicitud['Password'],
                ':rol'      => self::CODIGO_ROL[$rol],
            ]);
            $idUsuario = (int) $this->bd->lastInsertId();

            $stmt = $this->bd->prepare("insert into HistorialClave (Password, IdUsuario) values (:hash, :id)");
            $stmt->execute([':hash' => $solicitud['Password'], ':id' => $idUsuario]);

            if ($rol === 'Participante') {
                $stmt = $this->bd->prepare(
                    "insert into Participante (NombreParticipante, PerfilPublico) values (:nombre, 0)"
                );
                $stmt->execute([':nombre' => mb_substr($solicitud['Nombre'] . ' ' . $solicitud['Apellido'], 0, 80)]);
                $stmt = $this->bd->prepare("insert into Vincula (IdParticipante, IdUsuario) values (:p, :u)");
                $stmt->execute([':p' => (int) $this->bd->lastInsertId(), ':u' => $idUsuario]);
            }

            $this->resolver($idSolicitud, 'APROBADA', $idAdministrador, $idUsuario);

            $this->bd->commit();
        } catch (Throwable $e) {
            $this->bd->rollBack();
            throw $e;
        }

        return $idUsuario;
    }

    /** Rechaza una solicitud pendiente; el hash de la contraseña se borra */
    public function rechazar(int $idSolicitud, int $idAdministrador): bool
    {
        return $this->resolver($idSolicitud, 'RECHAZADA', $idAdministrador, null);
    }

    private function resolver(int $idSolicitud, string $estado, int $idAdministrador, ?int $idUsuario): bool
    {
        $stmt = $this->bd->prepare(
            "update SolicitudCuenta
             set EstadoSolicitud = :estado, Password = null, FechaResolucion = current_timestamp,
                 IdUsuarioResuelve = :admin, IdUsuarioCreado = :usuario
             where IdSolicitud = :id and EstadoSolicitud = 'PENDIENTE'"
        );
        $stmt->execute([
            ':estado'  => $estado,
            ':admin'   => $idAdministrador,
            ':usuario' => $idUsuario,
            ':id'      => $idSolicitud,
        ]);

        return $stmt->rowCount() > 0;
    }

    /** Columnas de los listados; el hash de la contraseña no sale de la base */
    private static function select(): string
    {
        return "select SolicitudCuenta.IdSolicitud as id,
                       concat(SolicitudCuenta.Nombre, ' ', SolicitudCuenta.Apellido) as nombre,
                       SolicitudCuenta.Email as correo,
                       SolicitudCuenta.Motivo as motivo,
                       SolicitudCuenta.FechaSolicitud as fecha,
                       SolicitudCuenta.FechaResolucion as fecha_resolucion,
                       case SolicitudCuenta.EstadoSolicitud
                           when 'PENDIENTE' then 'Pendiente'
                           when 'APROBADA'  then 'Aprobada'
                           else 'Rechazada'
                       end as estado,
                       case Rol.NombreRol
                           when 'ADMINISTRADOR' then 'Administrador general'
                           when 'ORGANIZADOR'   then 'Organizador de torneo'
                           else 'Participante'
                       end as rol_tentativo,
                       concat(Resuelve.Nombre, ' ', Resuelve.Apellido) as resuelta_por
                from SolicitudCuenta
                inner join Rol on SolicitudCuenta.IdRolTentativo = Rol.IdRol
                left join Usuario as Resuelve on SolicitudCuenta.IdUsuarioResuelve = Resuelve.IdUsuario";
    }
}
