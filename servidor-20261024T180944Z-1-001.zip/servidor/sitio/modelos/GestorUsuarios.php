<?php
require_once __DIR__ . '/ConexionBD.php';
require_once __DIR__ . '/Usuario.php';
require_once __DIR__ . '/../seguridad/Contrasena.php';

/** Usuarios: tablas Usuario y Rol */
class GestorUsuarios
{
    /** SELECT de las consultas de lectura */
    private const SELECT_BASE = "
        select Usuario.IdUsuario as id,
               concat(Usuario.Nombre, ' ', Usuario.Apellido) as nombre,
               Usuario.Email    as correo,
               Usuario.Password as contrasena_hash,
               case Rol.NombreRol
                   when 'ADMINISTRADOR' then 'Administrador general'
                   when 'ORGANIZADOR'   then 'Organizador de torneo'
                   else 'Participante'
               end as rol,
               case Usuario.Estado when 'ACTIVO' then 'Activo' else 'Inactivo' end as estado,
               Usuario.FechaAlta as creado_en,
               Usuario.CambioObligatorio as cambio_obligatorio,
               datediff(curdate(), Usuario.FechaClave) as dias_clave
        from Usuario
        inner join Rol on Usuario.IdRol = Rol.IdRol";

    /** Rol: texto => código de la tabla Rol */
    private const CODIGO_ROL = [
        'Administrador general' => 'ADMINISTRADOR',
        'Organizador de torneo' => 'ORGANIZADOR',
        'Participante'          => 'PARTICIPANTE',
    ];

    private PDO $bd;

    /** Sin argumento usa ConexionBD::obtener() */
    public function __construct(?PDO $conexion = null)
    {
        $this->bd = $conexion ?? ConexionBD::obtener();
    }

    public function listarUsuarios(): array
    {
        $stmt = $this->bd->query(self::SELECT_BASE . " order by Usuario.IdUsuario");

        $usuarios = [];
        foreach ($stmt as $fila) {
            $usuarios[] = self::mapearFila($fila);
        }

        return $usuarios;
    }

    public function buscarPorCorreo(string $correo): ?Usuario
    {
        $sql  = self::SELECT_BASE . " where lower(Usuario.Email) = lower(:correo) limit 1";
        $stmt = $this->bd->prepare($sql);
        $stmt->execute([':correo' => $correo]);

        $fila = $stmt->fetch();

        return $fila ? self::mapearFila($fila) : null;
    }

    /** Alta con contraseña provisional. Devuelve false si el correo existe o el rol no es válido */
    public function crearUsuario(string $nombre, string $correo, string $contrasena, string $rol): bool
    {
        if ($this->buscarPorCorreo($correo) !== null) {
            return false;
        }

        $idRol = $this->obtenerIdRol($rol);
        if ($idRol === null) {
            return false;
        }

        // Nombre y apellido por separado
        $partes   = explode(' ', trim($nombre), 2);
        $pila     = $partes[0];
        $apellido = $partes[1] ?? '-';

        $hash = Contrasena::generarHash($contrasena);

        $sql = "insert into Usuario (Nombre, Apellido, Email, Password, Estado,
                                     FechaAlta, FechaClave, CambioObligatorio, IdRol)
                values (:nombre, :apellido, :correo, :hash, 'ACTIVO',
                        curdate(), curdate(), 1, :idrol)";

        $stmt = $this->bd->prepare($sql);
        $stmt->execute([
            ':nombre'   => $pila,
            ':apellido' => $apellido,
            ':correo'   => $correo,
            ':hash'     => $hash,
            ':idrol'    => $idRol,
        ]);

        if ($stmt->rowCount() === 0) {
            return false;
        }

        $this->guardarEnHistorial((string) $this->bd->lastInsertId(), $hash);

        return true;
    }

    /** Compara con la contraseña actual y con las últimas del historial */
    public function claveYaUsada(string $id, string $contrasena): bool
    {
        $stmt = $this->bd->prepare("select Password from Usuario where IdUsuario = :id");
        $stmt->execute([':id' => $id]);
        $hashes = $stmt->fetchAll(PDO::FETCH_COLUMN);

        $stmt = $this->bd->prepare(
            "select Password from HistorialClave where IdUsuario = :id
             order by IdHistorial desc limit " . Contrasena::HISTORIAL
        );
        $stmt->execute([':id' => $id]);
        $hashes = array_merge($hashes, $stmt->fetchAll(PDO::FETCH_COLUMN));

        foreach ($hashes as $hash) {
            if (Contrasena::verificar($contrasena, $hash)) {
                return true;
            }
        }

        return false;
    }

    /** Guarda la contraseña nueva, la fecha del cambio y quita la marca de provisional */
    public function cambiarClave(string $id, string $contrasena): bool
    {
        $hash = Contrasena::generarHash($contrasena);

        $stmt = $this->bd->prepare(
            "update Usuario
             set Password = :hash, FechaClave = curdate(), CambioObligatorio = 0
             where IdUsuario = :id"
        );
        $stmt->execute([':hash' => $hash, ':id' => $id]);

        if ($stmt->rowCount() === 0) {
            return false;
        }

        $this->guardarEnHistorial($id, $hash);

        return true;
    }

    private function guardarEnHistorial(string $id, string $hash): void
    {
        $stmt = $this->bd->prepare(
            "insert into HistorialClave (Password, IdUsuario) values (:hash, :id)"
        );
        $stmt->execute([':hash' => $hash, ':id' => $id]);
    }

    /** Borra el usuario; con datos asociados (FK RESTRICT) pasa a INACTIVO */
    public function eliminarUsuario(string $id): void
    {
        try {
            $stmt = $this->bd->prepare("delete from Usuario where IdUsuario = :id");
            $stmt->execute([':id' => $id]);
        } catch (PDOException $e) {
            $stmt = $this->bd->prepare(
                "update Usuario set Estado = 'INACTIVO' where IdUsuario = :id"
            );
            $stmt->execute([':id' => $id]);
        }
    }

    /**
     * Cambia el rol y el estado de una cuenta.
     * Devuelve false si el rol no es válido o la cuenta no existe.
     */
    public function modificarUsuario(string $id, string $rol, string $estado): bool
    {
        $idRol = $this->obtenerIdRol($rol);
        if ($idRol === null || !in_array($estado, ['Activo', 'Inactivo'], true)) {
            return false;
        }

        $stmt = $this->bd->prepare("select count(*) from Usuario where IdUsuario = :id");
        $stmt->execute([':id' => $id]);
        if ((int) $stmt->fetchColumn() === 0) {
            return false;
        }

        $stmt = $this->bd->prepare(
            "update Usuario set IdRol = :idrol, Estado = :estado where IdUsuario = :id"
        );
        $stmt->execute([
            ':idrol'  => $idRol,
            ':estado' => strtoupper($estado),
            ':id'     => $id,
        ]);

        return true;
    }

    private static function mapearFila(array $fila): Usuario
    {
        return new Usuario(
            (string) $fila['id'],
            $fila['nombre'],
            $fila['correo'],
            $fila['contrasena_hash'],
            $fila['rol'],
            $fila['estado'],
            self::debeCambiarClave($fila)
        );
    }

    /** Provisional, o vencida en las cuentas de administrador y de organizador */
    private static function debeCambiarClave(array $fila): bool
    {
        if ((int) $fila['cambio_obligatorio'] === 1) {
            return true;
        }

        return $fila['rol'] !== 'Participante'
            && (int) $fila['dias_clave'] > Contrasena::DIAS_VIGENCIA;
    }

    private function obtenerIdRol(string $rol): ?int
    {
        $codigo = self::CODIGO_ROL[$rol] ?? null;
        if ($codigo === null) {
            return null;
        }

        $stmt = $this->bd->prepare("select IdRol from Rol where NombreRol = :nombre limit 1");
        $stmt->execute([':nombre' => $codigo]);

        $fila = $stmt->fetch();

        return $fila ? (int) $fila['IdRol'] : null;
    }
}
