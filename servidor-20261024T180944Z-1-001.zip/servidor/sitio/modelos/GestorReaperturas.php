<?php
require_once __DIR__ . '/ConexionBD.php';

/**
 * Solicitudes de reapertura de un torneo cerrado. La pide un organizador del torneo
 * (el creador o uno aceptado) y la resuelve el administrador: al reabrir el torneo
 * la solicitud queda aprobada
 */
class GestorReaperturas
{
    private PDO $bd;

    public function __construct(?PDO $conexion = null)
    {
        $this->bd = $conexion ?? ConexionBD::obtener();
    }

    /**
     * Registra el pedido si el torneo está cerrado, el usuario es su organizador y no
     * hay otro pendiente (la clave única uqReaperturaPendiente lo garantiza en la base)
     */
    public function solicitar(int $idTorneo, int $idUsuario, string $motivo): bool
    {
        $stmt = $this->bd->prepare(
            "insert ignore into SolicitudReapertura (IdTorneo, IdUsuarioSolicita, Motivo)
             select Torneo.IdTorneo, :usuario, :motivo
             from Torneo
             where Torneo.IdTorneo = :torneo
               and Torneo.Estado = 'CERRADO'
               and (Torneo.IdUsuario = :creador
                    or exists (select 1 from Organiza
                               where Organiza.IdTorneo = Torneo.IdTorneo
                                 and Organiza.IdUsuario = :organizador
                                 and Organiza.EstadoOrganiza = 'ACEPTADA'))"
        );
        $stmt->execute([
            ':usuario'     => $idUsuario,
            ':motivo'      => $motivo,
            ':torneo'      => $idTorneo,
            ':creador'     => $idUsuario,
            ':organizador' => $idUsuario,
        ]);

        return $stmt->rowCount() > 0;
    }

    /** Pedidos pendientes, indexados por torneo */
    public function pendientesPorTorneo(): array
    {
        $filas = $this->bd->query(
            "select SolicitudReapertura.IdSolicitudReapertura as id,
                    SolicitudReapertura.IdTorneo as id_torneo,
                    concat(Usuario.Nombre, ' ', Usuario.Apellido) as solicitante,
                    SolicitudReapertura.Motivo as motivo,
                    SolicitudReapertura.FechaSolicitud as fecha
             from SolicitudReapertura
             inner join Usuario on SolicitudReapertura.IdUsuarioSolicita = Usuario.IdUsuario
             where SolicitudReapertura.EstadoSolicitud = 'PENDIENTE'"
        )->fetchAll();

        return array_column($filas, null, 'id_torneo');
    }

    /** Reabre el torneo y aprueba su pedido pendiente, si lo tiene, en una sola transacción */
    public function reabrir(int $idTorneo, int $idAdmin): bool
    {
        $this->bd->beginTransaction();
        try {
            $stmt = $this->bd->prepare(
                "update Torneo set Estado = EstadoPrevio, EstadoPrevio = null
                 where IdTorneo = :id and Estado = 'CERRADO'"
            );
            $stmt->execute([':id' => $idTorneo]);
            if ($stmt->rowCount() === 0) {
                $this->bd->rollBack();
                return false;
            }

            $this->resolverPendiente($idTorneo, 'APROBADA', $idAdmin);
            $this->bd->commit();
            return true;
        } catch (Throwable $e) {
            $this->bd->rollBack();
            throw $e;
        }
    }

    /** Rechaza el pedido pendiente: el torneo sigue cerrado */
    public function rechazar(int $idTorneo, int $idAdmin): bool
    {
        return $this->resolverPendiente($idTorneo, 'RECHAZADA', $idAdmin);
    }

    private function resolverPendiente(int $idTorneo, string $estado, int $idAdmin): bool
    {
        $stmt = $this->bd->prepare(
            "update SolicitudReapertura
             set EstadoSolicitud   = :estado,
                 FechaResolucion   = current_timestamp,
                 IdUsuarioResuelve = :admin
             where IdTorneo = :torneo and EstadoSolicitud = 'PENDIENTE'"
        );
        $stmt->execute([':estado' => $estado, ':admin' => $idAdmin, ':torneo' => $idTorneo]);

        return $stmt->rowCount() > 0;
    }
}
