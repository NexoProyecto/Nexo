<?php
require_once __DIR__ . '/ConexionBD.php';

/** Organizadores de cada torneo: el que lo creó (Torneo.IdUsuario) y los aceptados en Organiza */
class GestorOrganizadores
{
    /** Estados en los que un organizador puede pedir sumarse a un torneo */
    private const ESTADOS_UNIRSE = "('ABIERTO', 'EN CURSO')";

    private PDO $bd;

    public function __construct(?PDO $conexion = null)
    {
        $this->bd = $conexion ?? ConexionBD::obtener();
    }

    /** El usuario creó el torneo o fue aceptado como organizador */
    public function esOrganizador(int $idTorneo, int $idUsuario): bool
    {
        $stmt = $this->bd->prepare(
            "select count(*) from Torneo
             where Torneo.IdTorneo = :torneo
               and (Torneo.IdUsuario = :creador
                    or exists (select 1 from Organiza
                               where Organiza.IdTorneo = Torneo.IdTorneo
                                 and Organiza.IdUsuario = :organizador
                                 and Organiza.EstadoOrganiza = 'ACEPTADA'))"
        );
        $stmt->execute([':torneo' => $idTorneo, ':creador' => $idUsuario, ':organizador' => $idUsuario]);

        return (int) $stmt->fetchColumn() > 0;
    }

    /** Pedidos y organizadores aceptados de un torneo */
    public function listarDeTorneo(int $idTorneo): array
    {
        $stmt = $this->bd->prepare(
            "select Organiza.IdUsuario as id_usuario,
                    concat(Usuario.Nombre, ' ', Usuario.Apellido) as nombre,
                    Usuario.Email as correo,
                    Organiza.EstadoOrganiza as estado_codigo,
                    case Organiza.EstadoOrganiza
                        when 'PENDIENTE' then 'Pendiente'
                        when 'ACEPTADA'  then 'Aceptado'
                        else 'Rechazado'
                    end as estado,
                    Organiza.FechaSolicitud as fecha
             from Organiza
             inner join Usuario on Organiza.IdUsuario = Usuario.IdUsuario
             where Organiza.IdTorneo = :torneo
             order by field(Organiza.EstadoOrganiza, 'PENDIENTE', 'ACEPTADA', 'RECHAZADA'),
                      Organiza.FechaSolicitud"
        );
        $stmt->execute([':torneo' => $idTorneo]);

        return $stmt->fetchAll();
    }

    /** Torneos publicados de otros organizadores, con el pedido del usuario si ya lo hizo */
    public function torneosParaUnirse(int $idUsuario): array
    {
        $stmt = $this->bd->prepare(
            "select Torneo.IdTorneo as id,
                    Torneo.NombreTorneo as nombre,
                    Torneo.FechaInicio as fecha_inicio,
                    case Torneo.Estado when 'ABIERTO' then 'Inscripciones' else 'En curso' end as estado,
                    concat(Usuario.Nombre, ' ', Usuario.Apellido) as organizador,
                    Organiza.EstadoOrganiza as pedido
             from Torneo
             inner join Usuario on Torneo.IdUsuario = Usuario.IdUsuario
             left join Organiza on Organiza.IdTorneo = Torneo.IdTorneo
                               and Organiza.IdUsuario = :usuario
             where Torneo.Estado in " . self::ESTADOS_UNIRSE . "
               and Torneo.IdUsuario <> :creador
               and (Organiza.EstadoOrganiza is null or Organiza.EstadoOrganiza <> 'ACEPTADA')
             order by Torneo.FechaInicio desc, Torneo.IdTorneo desc"
        );
        $stmt->execute([':usuario' => $idUsuario, ':creador' => $idUsuario]);

        return $stmt->fetchAll();
    }

    /**
     * Pide sumarse como organizador. Un pedido rechazado se puede repetir.
     * Devuelve false si el torneo no admite pedidos, es propio o ya hay un pedido pendiente o aceptado.
     */
    public function solicitar(int $idTorneo, int $idUsuario): bool
    {
        $stmt = $this->bd->prepare(
            "insert into Organiza (IdTorneo, IdUsuario, EstadoOrganiza)
             select Torneo.IdTorneo, :usuario, 'PENDIENTE'
             from Torneo
             where Torneo.IdTorneo = :torneo
               and Torneo.Estado in " . self::ESTADOS_UNIRSE . "
               and Torneo.IdUsuario <> :creador
             on duplicate key update
                 FechaSolicitud    = if(EstadoOrganiza = 'RECHAZADA', current_timestamp, FechaSolicitud),
                 FechaResolucion   = if(EstadoOrganiza = 'RECHAZADA', null, FechaResolucion),
                 IdUsuarioResuelve = if(EstadoOrganiza = 'RECHAZADA', null, IdUsuarioResuelve),
                 EstadoOrganiza    = if(EstadoOrganiza = 'RECHAZADA', 'PENDIENTE', EstadoOrganiza)"
        );
        $stmt->execute([':usuario' => $idUsuario, ':torneo' => $idTorneo, ':creador' => $idUsuario]);

        // 1: alta; 2: pedido rechazado que vuelve a pendiente; 0: sin cambios
        return $stmt->rowCount() > 0;
    }

    /** Acepta o rechaza un pedido pendiente de un torneo que no está cerrado */
    public function resolver(int $idTorneo, int $idSolicitante, string $estado, int $idResuelve): bool
    {
        if (!in_array($estado, ['ACEPTADA', 'RECHAZADA'], true)) {
            return false;
        }

        $stmt = $this->bd->prepare(
            "update Organiza
             inner join Torneo on Organiza.IdTorneo = Torneo.IdTorneo
             set Organiza.EstadoOrganiza    = :estado,
                 Organiza.FechaResolucion   = current_timestamp,
                 Organiza.IdUsuarioResuelve = :resuelve
             where Organiza.IdTorneo = :torneo
               and Organiza.IdUsuario = :solicitante
               and Organiza.EstadoOrganiza = 'PENDIENTE'
               and Torneo.Estado <> 'CERRADO'"
        );
        $stmt->execute([
            ':estado'      => $estado,
            ':resuelve'    => $idResuelve,
            ':torneo'      => $idTorneo,
            ':solicitante' => $idSolicitante,
        ]);

        return $stmt->rowCount() > 0;
    }
}
