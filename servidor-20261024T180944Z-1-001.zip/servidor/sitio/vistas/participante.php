<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Vista: panel del participante ($usuario, $participante, $torneos, $proximos, $jugados, $disponibles, $tokenCsrf, $aviso)
$titulo = 'Mi panel';
$activo = 'participante';
require __DIR__ . '/parciales/cabecera.php';

$activos  = 0;
$ganados  = 0;
$mejor    = null;
foreach ($torneos as $t) {
    if ($t['estado_codigo'] !== 'ACEPTADA') {
        continue;
    }
    if ($t['estado_torneo'] === 'EN CURSO') {
        $activos++;
    }
    $ganados += (int) $t['ganados'];
    if ($t['jugados'] !== null && ($mejor === null || (int) $t['posicion'] < $mejor)) {
        $mejor = (int) $t['posicion'];
    }
}
?>
        <header class="encabezado">
            <h1>Hola, <?= e($usuario['nombre']) ?></h1>
            <p>Panel del participante: torneos, partidos y posiciones.</p>
        </header>

        <div class="aviso-rol">Sesión iniciada como: <strong><?= e($usuario['nombre']) ?></strong> (Participante)</div>

        <?php if (!empty($aviso)): ?>
            <div class="aviso-rol" id="aviso"><?= e($aviso) ?></div>
        <?php endif; ?>

        <section class="estadisticas">
            <div class="estadistica">
                <span class="icono">♛</span>
                <div><strong><?= $activos ?></strong><span>Torneos en curso</span></div>
            </div>
            <div class="estadistica">
                <span class="icono">⚔︎</span>
                <div><strong><?= count($proximos) ?></strong><span>Próximos partidos</span></div>
            </div>
            <div class="estadistica">
                <span class="icono">✓</span>
                <div><strong><?= $ganados ?></strong><span>Partidos ganados</span></div>
            </div>
            <div class="estadistica">
                <span class="icono">✪</span>
                <div><strong><?= $mejor === null ? '—' : $mejor . '°' ?></strong><span>Mejor posición</span></div>
            </div>
        </section>

        <section class="seccion" id="mis-torneos">
            <div class="titulo-seccion">
                <h2>Mis torneos</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Torneo</th><th>Inscripción</th><th>Posición</th><th>PJ</th><th>G</th><th>Pts</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($torneos as $t): ?>
                        <tr>
                            <td>
                                <?php if ($t['estado_torneo'] === 'BORRADOR'): ?>
                                    <?= e($t['torneo']) ?>
                                <?php else: ?>
                                    <a class="enlace" href="index.php?ruta=torneo&amp;id=<?= (int) $t['id_torneo'] ?>"><?= e($t['torneo']) ?></a>
                                <?php endif; ?>
                            </td>
                            <td><?= e($t['estado']) ?></td>
                            <td><?= $t['jugados'] === null ? '—' : (int) $t['posicion'] . '°' ?></td>
                            <td><?= (int) $t['jugados'] ?></td>
                            <td><?= (int) $t['ganados'] ?></td>
                            <td><?= (int) $t['puntos'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($torneos) === 0): ?>
                        <tr><td colspan="6" class="celda-vacia">Sin inscripciones.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="seccion" id="inscribirse">
            <div class="titulo-seccion">
                <h2>Inscribirse en un torneo</h2>
            </div>
            <?php if (count($disponibles) === 0): ?>
                <p class="texto-vacio">No hay torneos con inscripciones abiertas.</p>
            <?php else: ?>
            <form class="formulario" action="index.php?ruta=participante/inscribir" method="POST">
                <input type="hidden" name="tokenCsrf" value="<?= e($tokenCsrf) ?>">
                <label>Torneo con inscripciones abiertas
                    <select name="torneo" required>
                        <?php foreach ($disponibles as $d): ?>
                        <option value="<?= (int) $d['id'] ?>"><?= e($d['nombre']) ?> · inicia el <?= fecha_corta($d['fecha_inicio']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <button type="submit" class="boton">Pedir inscripción</button>
                <p class="ayuda-campo">La inscripción queda pendiente hasta que el organizador la acepta.</p>
            </form>
            <?php endif; ?>
        </section>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Mis próximos partidos</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Fecha</th><th>Hora</th><th>Torneo</th><th>Enfrentamiento</th><th>Ronda</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($proximos as $p): ?>
                        <tr>
                            <td><?= fecha_corta($p['fecha_hora']) ?></td>
                            <td><?= hora_corta($p['fecha_hora']) ?></td>
                            <td><?= e($p['torneo']) ?></td>
                            <td><?= e($p['local']) ?> vs <?= e($p['visitante']) ?></td>
                            <td>Ronda <?= (int) $p['ronda'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($proximos) === 0): ?>
                        <tr><td colspan="5" class="celda-vacia">No hay partidos próximos.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Mis resultados</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Fecha</th><th>Torneo</th><th>Enfrentamiento</th><th>Resultado</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($jugados as $j): ?>
                        <tr>
                            <td><?= fecha_corta($j['fecha_hora']) ?></td>
                            <td><?= e($j['torneo']) ?></td>
                            <td><?= e($j['local']) ?> vs <?= e($j['visitante']) ?></td>
                            <td><strong><?= (int) $j['puntos_local'] ?> - <?= (int) $j['puntos_visitante'] ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($jugados) === 0): ?>
                        <tr><td colspan="4" class="celda-vacia">Sin resultados cargados.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="seccion" id="perfil">
            <div class="titulo-seccion">
                <h2>Mi perfil</h2>
            </div>
            <form class="formulario" action="index.php?ruta=participante/perfil" method="POST">
                <input type="hidden" name="tokenCsrf" value="<?= e($tokenCsrf) ?>">
                <label>Nombre y apellido
                    <input type="text" value="<?= e($usuario['nombre']) ?>" disabled>
                </label>
                <label>Correo electrónico
                    <input type="email" value="<?= e($usuario['correo']) ?>" disabled>
                </label>
                <label>Alias o nombre de jugador
                    <input type="text" name="alias" maxlength="40" value="<?= e($participante['alias'] ?? '') ?>">
                </label>
                <label>Fecha de nacimiento
                    <input type="date" name="nacimiento" value="<?= e($participante['fecha_nacimiento'] ?? '') ?>">
                </label>
                <label class="casilla">
                    <input type="checkbox" name="publico" value="1" <?= (int) ($participante['perfil_publico'] ?? 0) === 1 ? 'checked' : '' ?>>
                    Perfil público: el nombre, el alias y los torneos figuran en la consulta pública
                </label>
                <button type="submit" class="boton">Guardar perfil</button>
                <p class="ayuda-campo">El nombre y el correo son los de la cuenta.</p>
            </form>
        </section>

<?php
require __DIR__ . '/parciales/pie.php';
