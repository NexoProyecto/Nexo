<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Vista: portada ($torneos, $destacado, $posiciones, $stats)
$titulo = 'Inicio';
$activo = 'inicio';
require __DIR__ . '/parciales/cabecera.php';
?>
        <header class="encabezado portada-inicio">
            <h1>Bienvenido a CupCore</h1>
            <?php if (!isset($_SESSION['usuario'])): ?>
                <a href="index.php?ruta=login" class="boton">Iniciar sesión</a>
            <?php endif; ?>
            <p>Organización, inscripción y seguimiento de torneos deportivos, mentales y electrónicos.</p>
        </header>

        <section class="estadisticas">
            <div class="estadistica">
                <span class="icono">♛</span>
                <div><strong><?= (int) $stats['torneos'] ?></strong><span>Torneos publicados</span></div>
            </div>
            <div class="estadistica">
                <span class="icono">☻</span>
                <div><strong><?= (int) $stats['participantes'] ?></strong><span>Inscripciones aceptadas</span></div>
            </div>
            <div class="estadistica">
                <span class="icono">▦</span>
                <div><strong><?= (int) $stats['proximos'] ?></strong><span>Torneos con inscripción abierta</span></div>
            </div>
            <div class="estadistica">
                <span class="icono">⚔︎</span>
                <div><strong><?= (int) $stats['partidos'] ?></strong><span>Partidos por jugar</span></div>
            </div>
        </section>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Torneos en curso y con inscripción abierta</h2>
                <a href="index.php?ruta=torneos">Ver todos ›</a>
            </div>

            <div class="lista-torneos">
                <?php foreach ($torneos as $torneo): ?>
                    <?php require __DIR__ . '/parciales/tarjeta-torneo.php'; ?>
                <?php endforeach; ?>
            </div>
            <?php if (count($torneos) === 0): ?>
                <p class="texto-vacio">No hay torneos en curso ni con inscripción abierta.</p>
            <?php endif; ?>
        </section>

        <?php if ($destacado !== null): ?>
        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Tabla de posiciones · <?= e($destacado['nombre']) ?></h2>
                <a href="index.php?ruta=torneo&amp;id=<?= (int) $destacado['id'] ?>">Ver torneo ›</a>
            </div>
            <?php require __DIR__ . '/parciales/posiciones.php'; ?>
        </section>
        <?php endif; ?>

<?php
require __DIR__ . '/parciales/pie.php';
