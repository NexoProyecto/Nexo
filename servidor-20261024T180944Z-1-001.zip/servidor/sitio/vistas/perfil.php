<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Vista: perfil público de un equipo ($equipo, $integrantes) o de un participante ($participante, $equipos, $torneos)
$titulo = isset($equipo) ? $equipo['nombre'] : $participante['nombre'];
$activo = 'torneos';
require __DIR__ . '/parciales/cabecera.php';
?>
        <?php if (isset($equipo)): ?>
        <header class="encabezado">
            <h1><?= e($equipo['nombre']) ?></h1>
            <p>Equipo · creado el <?= fecha_corta($equipo['fecha_creacion']) ?></p>
        </header>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Integrantes (<?= count($integrantes) ?>)</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Nombre</th><th>Alias</th><th>Ingreso</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($integrantes as $i): ?>
                        <?php if ((int) $i['perfil_publico'] !== 1) { continue; } ?>
                        <tr>
                            <td><a class="enlace" href="index.php?ruta=perfil&amp;id=<?= (int) $i['id'] ?>"><?= e($i['nombre']) ?></a></td>
                            <td><?= e($i['alias'] ?? '—') ?></td>
                            <td><?= fecha_corta($i['fecha_ingreso']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <p class="ayuda-campo">Figuran los integrantes con perfil público.</p>
        </section>
        <?php else: ?>
        <header class="encabezado">
            <h1><?= e($participante['nombre']) ?></h1>
            <p>Participante<?= $participante['alias'] ? ' · alias ' . e($participante['alias']) : '' ?></p>
        </header>

        <?php if (count($equipos) > 0): ?>
        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Equipos</h2>
            </div>
            <ul class="lista-simple">
                <?php foreach ($equipos as $eq): ?>
                <li>
                    <?php if ((int) $eq['perfil_publico'] === 1): ?>
                        <a class="enlace" href="index.php?ruta=perfil&amp;tipo=equipo&amp;id=<?= (int) $eq['id'] ?>"><?= e($eq['nombre']) ?></a>
                    <?php else: ?>
                        <?= e($eq['nombre']) ?>
                    <?php endif; ?>
                </li>
                <?php endforeach; ?>
            </ul>
        </section>
        <?php endif; ?>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Torneos</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Torneo</th><th>Posición</th><th>PJ</th><th>G</th><th>Pts</th></tr>
                    </thead>
                    <tbody>
                        <?php $mostrados = 0; ?>
                        <?php foreach ($torneos as $t): ?>
                        <?php if ($t['estado_codigo'] !== 'ACEPTADA' || $t['estado_torneo'] === 'BORRADOR') { continue; } ?>
                        <?php $mostrados++; ?>
                        <tr>
                            <td><a class="enlace" href="index.php?ruta=torneo&amp;id=<?= (int) $t['id_torneo'] ?>"><?= e($t['torneo']) ?></a></td>
                            <td><?= $t['jugados'] === null ? '—' : (int) $t['posicion'] . '°' ?></td>
                            <td><?= (int) $t['jugados'] ?></td>
                            <td><?= (int) $t['ganados'] ?></td>
                            <td><?= (int) $t['puntos'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if ($mostrados === 0): ?>
                        <tr><td colspan="5" class="celda-vacia">Sin torneos.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
        <?php endif; ?>

<?php
require __DIR__ . '/parciales/pie.php';
