<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Vista: listado público de torneos ($torneos, $busqueda, $modulo)
$titulo = 'Torneos';
$activo = 'torneos';
require __DIR__ . '/parciales/cabecera.php';
?>
        <header class="encabezado">
            <h1>Torneos</h1>
            <p>Torneos publicados, con búsqueda por nombre y filtro por tipo de competencia.</p>
        </header>

        <section class="seccion">
            <form class="formulario" id="form-busqueda" action="index.php" method="GET">
                <input type="hidden" name="ruta" value="torneos">
                <label>Buscar torneo
                    <input type="text" name="busqueda" maxlength="100" placeholder="Ej: Copa Invierno" value="<?= e($busqueda) ?>">
                </label>
                <label>Tipo de competencia (módulo)
                    <select name="modulo">
                        <option value="Todos" <?= $modulo === 'Todos' ? 'selected' : '' ?>>Todos</option>
                        <option value="Liga" <?= $modulo === 'Liga' ? 'selected' : '' ?>>Liga (todos contra todos)</option>
                        <option value="Eliminación directa" <?= $modulo === 'Eliminación directa' ? 'selected' : '' ?>>Eliminación directa (llaves)</option>
                        <option value="Sistema suizo" <?= $modulo === 'Sistema suizo' ? 'selected' : '' ?>>Sistema suizo (por puntaje)</option>
                    </select>
                </label>
                <button type="submit" class="boton">Buscar</button>
            </form>
        </section>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Torneos publicados (<span id="cantidad-torneos"><?= count($torneos) ?></span>)</h2>
            </div>

            <p class="texto-vacio<?= count($torneos) === 0 ? '' : ' oculto' ?>" id="sin-torneos">No se encontraron torneos con esos filtros.</p>

            <div class="lista-torneos" id="lista-torneos">
                <?php foreach ($torneos as $torneo): ?>
                    <?php require __DIR__ . '/parciales/tarjeta-torneo.php'; ?>
                <?php endforeach; ?>
            </div>
        </section>

<?php
$scripts = ['js/torneos.js'];
require __DIR__ . '/parciales/pie.php';
