<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Vista: cambio de contraseña ($usuario, $obligatorio, $error, $tokenCsrf)
$titulo = 'Cambiar contraseña';
$activo = 'clave';
require __DIR__ . '/parciales/cabecera.php';
?>
        <header class="encabezado">
            <h1>Cambiar contraseña</h1>
            <p>Cuenta: <?= htmlspecialchars($usuario['correo']) ?></p>
        </header>

        <?php if ($obligatorio): ?>
            <div class="aviso-rol">
                La contraseña es provisional o está vencida. Para continuar es necesario cambiarla.
            </div>
        <?php endif; ?>

        <?php if ($error !== ''): ?>
            <div class="aviso-rol aviso-error">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <section class="seccion">
            <form class="formulario" id="form-clave" action="index.php?ruta=clave" method="POST" novalidate>
                <input type="hidden" name="tokenCsrf" value="<?= htmlspecialchars($tokenCsrf) ?>">
                <label>Contraseña actual
                    <input type="password" name="actual" maxlength="72" autocomplete="current-password" required>
                </label>
                <span class="mensaje-error" id="error-actual"></span>
                <label>Contraseña nueva
                    <input type="password" name="nueva" maxlength="72" autocomplete="new-password" required>
                </label>
                <span class="mensaje-error" id="error-nueva"></span>
                <p class="ayuda-campo">
                    Mínimo 8 caracteres, con una mayúscula, una minúscula, un número y un símbolo.
                    No se puede repetir ninguna de las últimas 3 contraseñas.
                </p>
                <label>Repetir la contraseña nueva
                    <input type="password" name="repetida" maxlength="72" autocomplete="new-password" required>
                </label>
                <span class="mensaje-error" id="error-repetida"></span>
                <button type="submit" class="boton">Cambiar contraseña</button>
            </form>
        </section>

<?php
$scripts = ['js/validaciones.js'];
require __DIR__ . '/parciales/pie.php';
