<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Vista: detalle público de un torneo ($torneo, $rondas, $posiciones)
$titulo = $torneo['nombre'];
$activo = 'torneos';
require __DIR__ . '/parciales/cabecera.php';
?>
        <img src="<?= e(imagen_de_torneo($torneo)) ?>" alt="Imagen del torneo <?= e($torneo['nombre']) ?>" class="portada-detalle">

        <header class="encabezado">
            <h1><?= e($torneo['nombre']) ?></h1>
            <span class="etiqueta <?= clase_de_modulo($torneo['modulo']) ?>"><?= e($torneo['modulo']) ?></span>
            <p>
                <?= e($torneo['disciplina']) ?> · <?= e($torneo['estado']) ?> ·
                <?= fecha_corta($torneo['fecha_inicio']) ?> - <?= fecha_corta($torneo['fecha_fin']) ?> ·
                <?= (int) $torneo['inscriptos'] ?> inscriptos · Organiza: <?= e($torneo['organizador']) ?>
            </p>
        </header>

        <?php if (!empty($torneo['reglas'])): ?>
            <div class="aviso-rol">Reglas: <?= e($torneo['reglas']) ?></div>
        <?php endif; ?>

        <?php if ($torneo['estado_codigo'] === 'ABIERTO'): ?>
            <div class="aviso-rol">Inscripciones abiertas: se piden desde el panel del participante.</div>
        <?php endif; ?>

        <?php if ($torneo['modulo_codigo'] !== 'ELIMINATORIA'): ?>
        <section class="seccion" id="posiciones" data-torneo="<?= (int) $torneo['id'] ?>"
                 data-actualizar="<?= $torneo['estado_codigo'] === 'EN CURSO' ? '1' : '0' ?>">
            <div class="titulo-seccion">
                <h2>Tabla de posiciones</h2>
            </div>
            <?php require __DIR__ . '/parciales/posiciones.php'; ?>
        </section>
        <?php endif; ?>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2><?= $torneo['modulo_codigo'] === 'ELIMINATORIA' ? 'Llaves' : 'Calendario y resultados' ?></h2>
            </div>
            <?php require __DIR__ . '/parciales/rondas.php'; ?>
        </section>

<?php
$scripts = ['js/torneos.js'];
require __DIR__ . '/parciales/pie.php';
