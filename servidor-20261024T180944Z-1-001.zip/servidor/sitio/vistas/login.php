<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Vista: inicio de sesión ($error, $tokenCsrf)
$titulo = 'Iniciar sesión';
$activo = 'login';
require __DIR__ . '/parciales/cabecera.php';
?>
        <header class="encabezado">
            <h1>Iniciar sesión</h1>
            <p>Ingreso al panel según el rol del usuario.</p>
        </header>

        <?php if ($error !== ''): ?>
            <div class="aviso-rol aviso-error">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <section class="seccion">
            <form class="formulario" id="form-ingreso" action="index.php?ruta=login" method="POST" novalidate>
                <input type="hidden" name="ruta" value="login">
                <input type="hidden" name="tokenCsrf" value="<?= htmlspecialchars($tokenCsrf) ?>">
                <label>Correo electrónico
                    <input type="email" name="correo" maxlength="120" placeholder="nombre@correo.com" required>
                </label>
                <span class="mensaje-error" id="error-correo"></span>
                <label>Contraseña
                    <input type="password" name="contrasena" maxlength="72" placeholder="••••••••" required>
                </label>
                <span class="mensaje-error" id="error-contrasena"></span>
                <button type="submit" class="boton">Ingresar</button>
                <p class="ayuda-campo"><a href="index.php?ruta=solicitud">No tengo una cuenta</a></p>
            </form>
        </section>

<?php
$scripts = ['js/validaciones.js'];
require __DIR__ . '/parciales/pie.php';
