<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Vista: panel del administrador ($usuario, $solicitudes, $resueltas, $enCurso, $cerrados, $reaperturas, $usuarios, $roles, $reporte, $auditoria, $tokenCsrf, $aviso)
$titulo = 'Panel de administración';
$activo = 'admin';
require __DIR__ . '/parciales/cabecera.php';
?>
        <header class="encabezado">
            <h1>Panel de administración</h1>
            <p>Solicitudes de cuenta, torneos en curso y cerrados, usuarios, reporte general y registro de auditoría.</p>
        </header>

        <div class="aviso-rol">
            Sesión iniciada como: <strong><?= e($usuario['nombre']) ?></strong>
            (<?= e($usuario['rol']) ?>)
        </div>

        <?php if (!empty($aviso)): ?>
            <div class="aviso-rol" id="aviso"><?= e($aviso) ?></div>
        <?php endif; ?>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Acciones</h2>
            </div>
            <div class="panel">
                <a href="index.php?ruta=organizador">
                    <span class="icono">✎</span>
                    <strong>Torneos</strong>
                    <span>Alta, configuración, rondas y resultados de todos los torneos</span>
                </a>
                <a href="index.php?ruta=participantes">
                    <span class="icono">☻</span>
                    <strong>Participantes y equipos</strong>
                    <span>Alta, modificación, baja e integrantes</span>
                </a>
                <a href="#solicitudes">
                    <span class="icono">✉</span>
                    <strong>Solicitudes de cuenta (<?= count($solicitudes) ?>)</strong>
                    <span>Aprobar con el rol pedido u otro, o rechazar</span>
                </a>
                <a href="#auditoria">
                    <span class="icono">☰</span>
                    <strong>Auditoría</strong>
                    <span>Últimas acciones registradas</span>
                </a>
            </div>
        </section>

        <section class="seccion" id="reporte">
            <div class="titulo-seccion">
                <h2>Reporte general</h2>
            </div>
            <div class="estadisticas">
                <div class="estadistica">
                    <span class="icono">☻</span>
                    <div><strong><?= (int) $reporte['usuarios'] ?></strong><span>Usuarios activos</span></div>
                </div>
                <div class="estadistica">
                    <span class="icono">⚔︎</span>
                    <div><strong><?= (int) $reporte['jugados'] ?></strong><span>Partidos jugados</span></div>
                </div>
                <div class="estadistica">
                    <span class="icono">◔</span>
                    <div><strong><?= (int) $reporte['sin_validar'] ?></strong><span>Resultados sin validar</span></div>
                </div>
            </div>
            <div class="fila-campos">
                <?php foreach (['por_estado' => 'Torneos por estado', 'por_modulo' => 'Torneos por módulo'] as $clave => $encabezado): ?>
                <div class="contiene-tabla">
                    <table>
                        <thead>
                            <tr><th><?= $encabezado ?></th><th>Cantidad</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($reporte[$clave] as $fila): ?>
                            <tr><td><?= e($fila['nombre']) ?></td><td><?= (int) $fila['cantidad'] ?></td></tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="seccion" id="solicitudes">
            <div class="titulo-seccion">
                <h2>Solicitudes de cuenta pendientes (<?= count($solicitudes) ?>)</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Solicitante</th><th>Correo</th><th>Motivo</th><th>Fecha</th><th>Aprobar con el rol</th><th>Rechazar</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($solicitudes as $s): ?>
                        <tr>
                            <td><?= e($s['nombre']) ?></td>
                            <td><?= e($s['correo']) ?></td>
                            <td><?= e($s['motivo'] ?? '') ?></td>
                            <td><?= fecha_corta(substr($s['fecha'], 0, 10)) ?></td>
                            <td>
                                <form class="form-linea" action="index.php?ruta=admin/aprobar" method="POST">
                                    <input type="hidden" name="tokenCsrf" value="<?= e($tokenCsrf) ?>">
                                    <input type="hidden" name="solicitud" value="<?= (int) $s['id'] ?>">
                                    <select class="campo" name="rol" aria-label="Rol para <?= e($s['nombre']) ?>">
                                        <?php foreach ($roles as $rol): ?>
                                        <option value="<?= e($rol) ?>" <?= $s['rol_tentativo'] === $rol ? 'selected' : '' ?>><?= e($rol) ?><?= $s['rol_tentativo'] === $rol ? ' (pedido)' : '' ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" class="boton-borde">Aprobar</button>
                                </form>
                            </td>
                            <td>
                                <form class="form-baja" action="index.php?ruta=admin/rechazar" method="POST"
                                      data-confirmar="¿Rechazar la solicitud de <?= e($s['nombre']) ?>?" data-boton="Rechazar">
                                    <input type="hidden" name="tokenCsrf" value="<?= e($tokenCsrf) ?>">
                                    <input type="hidden" name="solicitud" value="<?= (int) $s['id'] ?>">
                                    <button type="submit" class="boton-borde">Rechazar</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($solicitudes) === 0): ?>
                        <tr><td colspan="6" class="celda-vacia">Sin solicitudes pendientes.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if (count($resueltas) > 0): ?>
            <h3>Últimas resueltas</h3>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Solicitante</th><th>Correo</th><th>Rol pedido</th><th>Estado</th><th>Resuelta por</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($resueltas as $s): ?>
                        <tr>
                            <td><?= e($s['nombre']) ?></td>
                            <td><?= e($s['correo']) ?></td>
                            <td><?= e($s['rol_tentativo']) ?></td>
                            <td><?= e($s['estado']) ?></td>
                            <td><?= e($s['resuelta_por'] ?? '') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </section>

        <?php if (isset($enCurso)): ?>
        <section class="seccion" id="en-curso">
            <div class="titulo-seccion">
                <h2>Torneos en curso (<?= count($enCurso) ?>)</h2>
            </div>
            <p class="ayuda-campo">Al cerrar un torneo deja de admitir cambios y ningún organizador lo administra hasta que se reabre.</p>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Torneo</th><th>Módulo</th><th>Organizador</th><th>Cerrar</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($enCurso as $t): ?>
                        <tr>
                            <td><?= e($t['nombre']) ?></td>
                            <td><?= e($t['modulo']) ?></td>
                            <td><?= e($t['organizador']) ?></td>
                            <td>
                                <form class="form-baja" action="index.php?ruta=admin/cerrar" method="POST"
                                      data-confirmar="¿Cerrar el torneo <?= e($t['nombre']) ?>? Deja de admitir cambios y ningún organizador lo administra."
                                      data-aviso="Sus organizadores no pueden deshacer esta acción: el torneo vuelve a su estado solo al reabrirlo desde este panel."
                                      data-boton="Cerrar torneo">
                                    <input type="hidden" name="tokenCsrf" value="<?= e($tokenCsrf) ?>">
                                    <input type="hidden" name="torneo" value="<?= (int) $t['id'] ?>">
                                    <button type="submit" class="boton-borde">Cerrar</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($enCurso) === 0): ?>
                        <tr><td colspan="4" class="celda-vacia">Sin torneos en curso.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
        <?php endif; ?>

        <?php if (isset($cerrados)): ?>
        <section class="seccion" id="cerrados">
            <div class="titulo-seccion">
                <h2>Torneos cerrados (<?= count($cerrados) ?>)</h2>
            </div>
            <p class="ayuda-campo">Un torneo cerrado no admite cambios. Al reabrirlo vuelve al estado que tenía y sus organizadores lo administran de nuevo. Los organizadores del torneo piden la reapertura desde su panel.</p>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Torneo</th><th>Módulo</th><th>Organizador</th><th>Pedido de reapertura</th><th>Acción</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cerrados as $t): ?>
                        <?php $pedido = $reaperturas[$t['id']] ?? null; ?>
                        <tr>
                            <td><?= e($t['nombre']) ?></td>
                            <td><?= e($t['modulo']) ?></td>
                            <td><?= e($t['organizador']) ?></td>
                            <td class="celda-texto">
                                <?php if ($pedido !== null): ?>
                                    <?= e($pedido['solicitante']) ?>, <?= fecha_corta($pedido['fecha']) ?>: <?= e($pedido['motivo']) ?>
                                <?php else: ?>
                                    Sin pedido
                                <?php endif; ?>
                            </td>
                            <td>
                                <form class="form-baja" action="index.php?ruta=admin/reabrir" method="POST"
                                      data-confirmar="¿Reabrir el torneo <?= e($t['nombre']) ?>? Vuelve al estado que tenía al cerrarse." data-boton="Reabrir">
                                    <input type="hidden" name="tokenCsrf" value="<?= e($tokenCsrf) ?>">
                                    <input type="hidden" name="torneo" value="<?= (int) $t['id'] ?>">
                                    <button type="submit" class="boton-borde">Reabrir</button>
                                </form>
                                <?php if ($pedido !== null): ?>
                                <form class="form-baja" action="index.php?ruta=admin/rechazar-reapertura" method="POST"
                                      data-confirmar="¿Rechazar el pedido de reapertura? El torneo sigue cerrado." data-boton="Rechazar">
                                    <input type="hidden" name="tokenCsrf" value="<?= e($tokenCsrf) ?>">
                                    <input type="hidden" name="torneo" value="<?= (int) $t['id'] ?>">
                                    <button type="submit" class="boton-borde">Rechazar</button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($cerrados) === 0): ?>
                        <tr><td colspan="5" class="celda-vacia">Sin torneos cerrados.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
        <?php endif; ?>

        <section class="seccion" id="usuarios">
            <div class="titulo-seccion">
                <h2>Usuarios del sistema (<?= count($usuarios) ?>)</h2>
                <a href="#nuevo-usuario">+ Nuevo usuario</a>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Usuario</th><th>Correo</th><th>Rol y estado</th><th>Baja</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usuarios as $u): ?>
                        <tr>
                            <td><?= e($u->getNombre()) ?></td>
                            <td><?= e($u->getCorreo()) ?></td>
                            <td>
                                <form class="form-linea" action="index.php?ruta=admin/modificar" method="POST">
                                    <input type="hidden" name="tokenCsrf" value="<?= e($tokenCsrf) ?>">
                                    <input type="hidden" name="id" value="<?= e($u->getId()) ?>">
                                    <select class="campo" name="rol" aria-label="Rol de <?= e($u->getNombre()) ?>">
                                        <?php foreach ($roles as $rol): ?>
                                        <option value="<?= e($rol) ?>" <?= $u->getRol() === $rol ? 'selected' : '' ?>><?= e($rol) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <select class="campo" name="estado" aria-label="Estado de <?= e($u->getNombre()) ?>">
                                        <?php foreach (['Activo', 'Inactivo'] as $estadoCuenta): ?>
                                        <option value="<?= $estadoCuenta ?>" <?= $u->getEstado() === $estadoCuenta ? 'selected' : '' ?>><?= $estadoCuenta ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" class="boton-borde">Guardar</button>
                                </form>
                            </td>
                            <td>
                                <form class="form-baja" action="index.php?ruta=admin/eliminar" method="POST"
                                      data-confirmar="¿Dar de baja a <?= e($u->getNombre()) ?>?" data-boton="Dar de baja">
                                    <input type="hidden" name="tokenCsrf" value="<?= e($tokenCsrf) ?>">
                                    <input type="hidden" name="id" value="<?= e($u->getId()) ?>">
                                    <button type="submit" class="boton-borde">Dar de baja</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="seccion" id="nuevo-usuario">
            <div class="titulo-seccion">
                <h2>Nuevo usuario</h2>
            </div>
            <form class="formulario" id="form-usuario" action="index.php?ruta=admin/crear" method="POST" novalidate>
                <input type="hidden" name="tokenCsrf" value="<?= e($tokenCsrf) ?>">
                <label>Nombre y apellido
                    <input type="text" name="nombre" maxlength="60" placeholder="Ej: Camila Pérez" required>
                </label>
                <span class="mensaje-error" id="error-nombre"></span>
                <label>Correo electrónico
                    <input type="email" name="correo" maxlength="120" placeholder="nombre@correo.com" required>
                </label>
                <span class="mensaje-error" id="error-correo"></span>
                <label>Contraseña provisional
                    <input type="password" name="contrasena" maxlength="72" placeholder="••••••••" required>
                </label>
                <span class="mensaje-error" id="error-contrasena"></span>
                <p class="ayuda-campo">
                    Mínimo 8 caracteres, con una mayúscula, una minúscula, un número y un símbolo.
                    El sistema pide cambiarla en el primer ingreso.
                </p>
                <label>Rol
                    <select name="rol">
                        <option value="Participante">Participante</option>
                        <option value="Organizador de torneo">Organizador de torneo</option>
                        <option value="Administrador general">Administrador general</option>
                    </select>
                </label>
                <button type="submit" class="boton">Crear usuario</button>
            </form>
        </section>

        <section class="seccion" id="auditoria">
            <div class="titulo-seccion">
                <h2>Registro de auditoría</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Fecha y hora</th><th>Usuario</th><th>Acción</th><th>Tabla</th><th>IP</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($auditoria as $a): ?>
                        <tr>
                            <td><?= e($a['fecha_hora']) ?></td>
                            <td><?= e($a['usuario']) ?></td>
                            <td><?= e($a['accion']) ?></td>
                            <td><?= e($a['tabla']) ?></td>
                            <td><?= e($a['ip']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

<?php
$scripts = ['js/validaciones.js'];
require __DIR__ . '/parciales/pie.php';
