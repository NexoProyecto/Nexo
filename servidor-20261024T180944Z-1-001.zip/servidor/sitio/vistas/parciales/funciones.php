<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Funciones de presentación comunes a las vistas
require_once __DIR__ . '/../../modelos/GestorTorneos.php';

/** Escape HTML de todo dato que se muestra */
function e($texto): string
{
    return htmlspecialchars((string) ($texto ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Fecha AAAA-MM-DD o fecha y hora, como DD/MM/AAAA; sin fecha, una raya */
function fecha_corta(?string $fecha): string
{
    return $fecha ? date('d/m/Y', strtotime($fecha)) : '—';
}

function hora_corta(?string $fechaHora): string
{
    return $fechaHora ? date('H:i', strtotime($fechaHora)) : '—';
}

/** Portada del torneo: la del juego si el nombre lo dice, si no la del tipo de torneo */
function imagen_de_torneo(array $torneo): string
{
    return GestorTorneos::imagenDeTorneo($torneo['nombre'], $torneo['disciplina']);
}

function clase_de_modulo(string $modulo): string
{
    return match ($modulo) {
        'Liga'                => 'etiqueta-liga',
        'Eliminación directa' => 'etiqueta-eliminacion',
        default               => 'etiqueta-suizo',
    };
}

/** Nombre de la ronda de una llave según cuántos partidos tiene */
function nombre_de_llave(int $partidos, int $numero): string
{
    return match ($partidos) {
        1       => 'Final',
        2       => 'Semifinales',
        4       => 'Cuartos de final',
        8       => 'Octavos de final',
        default => 'Ronda ' . $numero,
    };
}
