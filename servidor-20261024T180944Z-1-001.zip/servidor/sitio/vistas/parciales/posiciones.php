<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Parcial: tabla de posiciones. Recibe $posiciones
?>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>#</th><th>Participante</th><th>PJ</th><th>G</th><th>E</th><th>P</th><th>Pts</th></tr>
                    </thead>
                    <tbody id="cuerpo-posiciones">
                        <?php foreach ($posiciones as $lugar => $pos): ?>
                        <tr>
                            <td><?= $lugar + 1 ?></td>
                            <td>
                                <?php if ((int) $pos['perfil_publico'] === 1): ?>
                                    <a class="enlace" href="index.php?ruta=perfil&amp;id=<?= (int) $pos['id_participante'] ?>"><?= e($pos['participante']) ?></a>
                                <?php else: ?>
                                    <?= e($pos['participante']) ?>
                                <?php endif; ?>
                            </td>
                            <td><?= (int) $pos['jugados'] ?></td>
                            <td><?= (int) $pos['ganados'] ?></td>
                            <td><?= (int) $pos['empatados'] ?></td>
                            <td><?= (int) $pos['perdidos'] ?></td>
                            <td><strong><?= (int) $pos['puntos'] ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($posiciones) === 0): ?>
                        <tr><td colspan="7" class="celda-vacia">La tabla se arma al iniciar el torneo.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
