<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Parcial: tarjeta de un torneo. Recibe $torneo
?>
                <article class="torneo">
                    <img src="<?= e(imagen_de_torneo($torneo)) ?>" alt="Imagen del torneo <?= e($torneo['nombre']) ?>" class="portada-img" loading="lazy">
                    <div class="datos">
                        <span class="etiqueta <?= clase_de_modulo($torneo['modulo']) ?>"><?= e($torneo['modulo']) ?></span>
                        <h3><?= e($torneo['nombre']) ?></h3>
                        <div class="dato">▦ <?= fecha_corta($torneo['fecha_inicio']) ?> - <?= fecha_corta($torneo['fecha_fin']) ?></div>
                        <div class="dato">☻ <?= (int) $torneo['inscriptos'] ?> inscriptos · <?= e($torneo['disciplina']) ?></div>
                        <div class="dato">Estado: <?= e($torneo['estado']) ?></div>
                        <a href="index.php?ruta=torneo&amp;id=<?= (int) $torneo['id'] ?>" class="boton-borde">Ver torneo</a>
                    </div>
                </article>
