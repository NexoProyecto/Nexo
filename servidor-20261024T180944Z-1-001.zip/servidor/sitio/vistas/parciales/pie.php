<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Parcial: pie de página y cierre del documento. Recibe $scripts (opcional)
?>
        <footer class="pie">
            CupCore · Gestión de torneos deportivos, mentales y electrónicos · Grupo Nexo · 3°MK · 2026
        </footer>
    </main>
    <?php foreach ($scripts ?? [] as $script): ?>
    <script src="<?= e($script) ?>"></script>
    <?php endforeach; ?>
</body>
</html>
