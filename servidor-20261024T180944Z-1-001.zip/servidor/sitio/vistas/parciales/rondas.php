<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Parcial: rondas con sus partidos y resultados oficiales. Recibe $rondas y $torneo
$esLlave = $torneo['modulo_codigo'] === 'ELIMINATORIA';
?>
            <div class="<?= $esLlave ? 'llaves' : 'rondas' ?>">
                <?php foreach ($rondas as $ronda): ?>
                <div class="ronda">
                    <h3>
                        <?= $esLlave ? e(nombre_de_llave(count($ronda['partidos']), (int) $ronda['numero'])) : 'Ronda ' . (int) $ronda['numero'] ?>
                        <span class="estado estado-<?= e(strtolower(str_replace(' ', '-', $ronda['estado_codigo']))) ?>"><?= e($ronda['estado']) ?></span>
                    </h3>
                    <p class="dato">▦ <?= fecha_corta($ronda['fecha']) ?></p>
                    <ul class="partidos">
                        <?php foreach ($ronda['partidos'] as $partido): ?>
                        <?php $oficial = (int) ($partido['validado'] ?? 0) === 1; ?>
                        <li>
                            <span class="<?= $oficial && $partido['ganador'] === 'LOCAL' ? 'ganador' : '' ?>"><?= e($partido['local']) ?></span>
                            <strong class="marcador"><?= $oficial ? (int) $partido['puntos_local'] . ' - ' . (int) $partido['puntos_visitante'] : hora_corta($partido['fecha_hora']) ?></strong>
                            <span class="<?= $oficial && $partido['ganador'] === 'VISITANTE' ? 'ganador' : '' ?>"><?= e($partido['visitante']) ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endforeach; ?>
            </div>
            <?php if (count($rondas) === 0): ?>
                <p class="texto-vacio">Los enfrentamientos se generan al iniciar el torneo.</p>
            <?php endif; ?>
