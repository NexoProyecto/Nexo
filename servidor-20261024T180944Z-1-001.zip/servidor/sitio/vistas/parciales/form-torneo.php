<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Parcial: campos del formulario de torneo. Recibe $tipos y, al modificar, $torneo
$actual = $torneo ?? null;
?>
                <label>Nombre del torneo
                    <input type="text" name="nombre" minlength="3" maxlength="100" placeholder="Ej: Copa Invierno" value="<?= e($actual['nombre'] ?? '') ?>" required>
                </label>
                <span class="mensaje-error" id="error-nombre"></span>
                <div class="fila-campos">
                    <label>Tipo de torneo
                        <select name="tipo">
                            <?php foreach ($tipos as $tipo): ?>
                            <option value="<?= (int) $tipo['id'] ?>" <?= (int) ($actual['id_tipo'] ?? 0) === (int) $tipo['id'] ? 'selected' : '' ?>><?= e($tipo['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <label>Módulo de competencia
                        <select name="modulo">
                            <option value="LIGA" <?= ($actual['modulo_codigo'] ?? '') === 'LIGA' ? 'selected' : '' ?>>Liga (todos contra todos)</option>
                            <option value="ELIMINATORIA" <?= ($actual['modulo_codigo'] ?? '') === 'ELIMINATORIA' ? 'selected' : '' ?>>Eliminación directa (llaves)</option>
                            <option value="SUIZO" <?= ($actual['modulo_codigo'] ?? '') === 'SUIZO' ? 'selected' : '' ?>>Sistema suizo (por puntaje)</option>
                        </select>
                    </label>
                </div>
                <div class="fila-campos">
                    <label>Fecha de inicio
                        <input type="date" name="inicio" value="<?= e($actual['fecha_inicio'] ?? '') ?>" required>
                    </label>
                    <label>Fecha de fin (opcional)
                        <input type="date" name="fin" value="<?= e($actual['fecha_fin'] ?? '') ?>">
                    </label>
                </div>
                <span class="mensaje-error" id="error-inicio"></span>
                <span class="mensaje-error" id="error-fin"></span>
                <label>Reglas del torneo (opcional)
                    <input type="text" name="reglas" maxlength="500" placeholder="Ej: partidos de dos tiempos de 20 minutos" value="<?= e($actual['reglas'] ?? '') ?>">
                </label>
                <span class="mensaje-error" id="error-reglas"></span>
