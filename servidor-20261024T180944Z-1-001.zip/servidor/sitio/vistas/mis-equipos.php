<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Vista: mis equipos ($misEquipos, $equipos, $torneos, $solicitudes, $tokenCsrf, $aviso)
$titulo = 'Mis equipos';
$activo = 'mis-equipos';
require __DIR__ . '/parciales/cabecera.php';

$token  = '<input type="hidden" name="tokenCsrf" value="' . e($tokenCsrf) . '">';
$propios = array_map(fn ($eq) => (int) $eq['id'], $misEquipos);
$otros   = array_filter($equipos, fn ($eq) => !in_array((int) $eq['id'], $propios, true));

$abiertos = 0;
foreach ($torneos as $lista) {
    $abiertos += count($lista);
}

$TIPOS   = ['INTEGRAR' => 'Integrar', 'INSCRIBIR' => 'Inscribir'];
$ESTADOS = ['PENDIENTE' => 'Pendiente', 'APROBADA' => 'Aprobada', 'RECHAZADA' => 'Rechazada'];
?>
        <header class="encabezado">
            <h1>Mis equipos</h1>
            <p>Equipos que integra, pedidos para sumarse a uno y para inscribirlo en un torneo.</p>
        </header>

        <?php if (!empty($aviso)): ?>
            <div class="aviso-rol" id="aviso"><?= e($aviso) ?></div>
        <?php endif; ?>

        <section class="seccion" id="equipos">
            <div class="titulo-seccion">
                <h2>Equipos que integro (<?= count($misEquipos) ?>)</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Equipo</th><th>Integrantes</th><th>Torneos del equipo</th><th>Desde</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($misEquipos as $eq): ?>
                        <tr>
                            <td>
                                <?php if ((int) $eq['perfil_publico'] === 1): ?>
                                    <a class="enlace" href="index.php?ruta=perfil&amp;tipo=equipo&amp;id=<?= (int) $eq['id'] ?>"><?= e($eq['nombre']) ?></a>
                                <?php else: ?>
                                    <?= e($eq['nombre']) ?>
                                <?php endif; ?>
                            </td>
                            <td><?= e($eq['integrantes']) ?></td>
                            <td>
                                <?php $lista = $eq['torneos'] === null ? [] : explode(', ', $eq['torneos']); ?>
                                <?= count($lista) === 0 ? 'Sin torneos' : e(implode(', ', array_slice($lista, 0, 2))) ?>
                                <?= count($lista) > 2 ? ' y ' . (count($lista) - 2) . ' más' : '' ?>
                            </td>
                            <td><?= fecha_corta($eq['fecha_ingreso']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($misEquipos) === 0): ?>
                        <tr><td colspan="4" class="celda-vacia">Todavía no integra ningún equipo.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="seccion" id="integrar">
            <div class="titulo-seccion">
                <h2>Pedir integrar un equipo</h2>
            </div>
            <form class="formulario" action="index.php?ruta=mis-equipos/integrar" method="POST">
                <?= $token ?>
                <label>Equipo existente
                    <select name="equipo">
                        <option value="">Ninguno: es un equipo nuevo</option>
                        <?php foreach ($otros as $eq): ?>
                        <option value="<?= (int) $eq['id'] ?>"><?= e($eq['nombre']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Nombre del equipo nuevo
                    <input type="text" name="nombre" minlength="2" maxlength="80" placeholder="Ej: Los Coyotes">
                </label>
                <button type="submit" class="boton">Enviar solicitud</button>
                <p class="ayuda-campo">Un organizador valida el nombre y confirma el ingreso. Con un equipo de la lista elegido, el nombre no se usa.</p>
            </form>
        </section>

        <section class="seccion" id="inscribir">
            <div class="titulo-seccion">
                <h2>Pedir la inscripción de mi equipo</h2>
            </div>
            <?php if ($abiertos === 0): ?>
                <p class="texto-vacio"><?= count($misEquipos) === 0
                    ? 'La inscripción de un equipo la pide uno de sus integrantes.'
                    : 'No hay torneos con inscripciones abiertas para sus equipos.' ?></p>
            <?php else: ?>
            <form class="formulario" action="index.php?ruta=mis-equipos/inscribir" method="POST">
                <?= $token ?>
                <label>Equipo y torneo con inscripciones abiertas
                    <select name="pedido" required>
                        <?php foreach ($misEquipos as $eq): ?>
                            <?php if (count($torneos[(int) $eq['id']]) > 0): ?>
                            <optgroup label="<?= e($eq['nombre']) ?>">
                                <?php foreach ($torneos[(int) $eq['id']] as $t): ?>
                                <option value="<?= (int) $eq['id'] ?>-<?= (int) $t['id'] ?>"><?= e($t['nombre']) ?> · inicia el <?= fecha_corta($t['fecha_inicio']) ?></option>
                                <?php endforeach; ?>
                            </optgroup>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                </label>
                <button type="submit" class="boton">Pedir inscripción</button>
                <p class="ayuda-campo">Cualquier integrante puede pedirla. Si otro integrante ya la pidió, el organizador resuelve los dos pedidos juntos.</p>
            </form>
            <?php endif; ?>
        </section>

        <section class="seccion" id="solicitudes">
            <div class="titulo-seccion">
                <h2>Mis solicitudes</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Fecha</th><th>Pedido</th><th>Equipo</th><th>Torneo</th><th>Estado</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($solicitudes as $s): ?>
                        <tr>
                            <td><?= fecha_corta($s['fecha']) ?></td>
                            <td><?= $TIPOS[$s['tipo']] ?></td>
                            <td><?= e($s['equipo'] ?? ($s['nombre_propuesto'] . ' (nuevo)')) ?></td>
                            <td><?= e($s['torneo'] ?? '—') ?></td>
                            <td><?= $ESTADOS[$s['estado']] ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($solicitudes) === 0): ?>
                        <tr><td colspan="5" class="celda-vacia">Sin solicitudes.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

<?php
require __DIR__ . '/parciales/pie.php';
