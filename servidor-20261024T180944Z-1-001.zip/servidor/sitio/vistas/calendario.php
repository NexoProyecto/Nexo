<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Vista: calendario ($proximos, $resultados)
$titulo = 'Calendario';
$activo = 'calendario';
require __DIR__ . '/parciales/cabecera.php';
?>
        <header class="encabezado">
            <h1>Calendario</h1>
            <p>Próximos partidos y resultados oficiales de todos los torneos.</p>
        </header>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Próximos partidos</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Fecha</th><th>Hora</th><th>Torneo</th><th>Enfrentamiento</th><th>Ronda</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($proximos as $p): ?>
                        <tr>
                            <td><?= fecha_corta($p['fecha']) ?></td>
                            <td><?= e(substr((string) $p['hora'], 0, 5)) ?></td>
                            <td><a class="enlace" href="index.php?ruta=torneo&amp;id=<?= (int) $p['id_torneo'] ?>"><?= e($p['torneo']) ?></a></td>
                            <td><?= e($p['local']) ?> vs <?= e($p['visitante']) ?></td>
                            <td><?= e($p['ronda']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($proximos) === 0): ?>
                        <tr><td colspan="5" class="celda-vacia">No hay partidos próximos.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="seccion">
            <div class="titulo-seccion">
                <h2>Últimos resultados</h2>
            </div>
            <div class="contiene-tabla">
                <table>
                    <thead>
                        <tr><th>Fecha</th><th>Torneo</th><th>Enfrentamiento</th><th>Resultado</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($resultados as $r): ?>
                        <tr>
                            <td><?= fecha_corta($r['fecha']) ?></td>
                            <td><a class="enlace" href="index.php?ruta=torneo&amp;id=<?= (int) $r['id_torneo'] ?>"><?= e($r['torneo']) ?></a></td>
                            <td><?= e($r['local']) ?> vs <?= e($r['visitante']) ?></td>
                            <td><strong><?= (int) $r['puntos_local'] ?> - <?= (int) $r['puntos_visitante'] ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (count($resultados) === 0): ?>
                        <tr><td colspan="4" class="celda-vacia">Sin resultados cargados.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

<?php
require __DIR__ . '/parciales/pie.php';
