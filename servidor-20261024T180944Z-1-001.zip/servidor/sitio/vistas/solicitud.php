<?php
if (!defined('CUPCORE')) { http_response_code(404); exit; }
// Vista: solicitud de cuenta ($enviada, $mensaje, $error, $errores, $valores, $roles, $tokenCsrf)
$titulo = 'Solicitar una cuenta';
$activo = 'login';
require __DIR__ . '/parciales/cabecera.php';
?>
        <header class="encabezado">
            <h1>Solicitar una cuenta</h1>
            <p>Un administrador revisa la solicitud y decide el rol de la cuenta.</p>
        </header>

        <?php if ($enviada): ?>
            <div class="aviso-rol" id="aviso"><?= e($mensaje) ?></div>
            <section class="seccion">
                <a class="boton" href="index.php?ruta=login">Volver al ingreso</a>
            </section>
        <?php else: ?>

        <?php if ($error !== ''): ?>
            <div class="aviso-rol aviso-error" id="aviso"><?= e($error) ?></div>
        <?php endif; ?>

        <section class="seccion">
            <form class="formulario" id="form-solicitud" action="index.php?ruta=solicitud" method="POST" novalidate>
                <input type="hidden" name="tokenCsrf" value="<?= e($tokenCsrf) ?>">
                <label>Nombre
                    <input type="text" name="nombre" maxlength="50" value="<?= e($valores['nombre']) ?>" autocomplete="given-name" required>
                </label>
                <span class="mensaje-error" id="error-nombre"><?= e($errores['nombre'] ?? '') ?></span>
                <label>Apellido
                    <input type="text" name="apellido" maxlength="50" value="<?= e($valores['apellido']) ?>" autocomplete="family-name" required>
                </label>
                <span class="mensaje-error" id="error-apellido"><?= e($errores['apellido'] ?? '') ?></span>
                <label>Correo electrónico
                    <input type="email" name="correo" maxlength="120" value="<?= e($valores['correo']) ?>" placeholder="nombre@correo.com" autocomplete="email" required>
                </label>
                <span class="mensaje-error" id="error-correo"><?= e($errores['correo'] ?? '') ?></span>
                <label>Contraseña
                    <input type="password" name="contrasena" maxlength="72" autocomplete="new-password" required>
                </label>
                <span class="mensaje-error" id="error-contrasena"><?= e($errores['contrasena'] ?? '') ?></span>
                <label>Repetir la contraseña
                    <input type="password" name="repetida" maxlength="72" autocomplete="new-password" required>
                </label>
                <span class="mensaje-error" id="error-repetida"><?= e($errores['repetida'] ?? '') ?></span>
                <p class="ayuda-campo">Mínimo 8 caracteres, con una mayúscula, una minúscula, un número y un símbolo.</p>
                <label>Rol solicitado
                    <select name="rol">
                        <?php foreach ($roles as $rol): ?>
                        <option value="<?= e($rol) ?>" <?= $valores['rol'] === $rol ? 'selected' : '' ?>><?= e($rol) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <span class="mensaje-error" id="error-rol"><?= e($errores['rol'] ?? '') ?></span>
                <label>Motivo (opcional)
                    <textarea name="motivo" maxlength="300" rows="3" placeholder="Ej: organizo el torneo de ajedrez del liceo"><?= e($valores['motivo']) ?></textarea>
                </label>
                <span class="mensaje-error" id="error-motivo"><?= e($errores['motivo'] ?? '') ?></span>
                <button type="submit" class="boton">Enviar solicitud</button>
                <p class="ayuda-campo"><a href="index.php?ruta=login">Ya tengo una cuenta</a></p>
            </form>
        </section>

        <?php endif; ?>

<?php
$scripts = ['js/validaciones.js'];
require __DIR__ . '/parciales/pie.php';
