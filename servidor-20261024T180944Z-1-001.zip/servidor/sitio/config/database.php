<?php
/**
 * Conexión a la base CupCore.
 * Cada dato se toma de la variable de entorno del mismo nombre, si existe.
 */
define('DB_HOST',    getenv('DB_HOST') ?: 'localhost');
define('DB_PORT',    getenv('DB_PORT') ?: '3306');
define('DB_NAME',    getenv('DB_NAME') ?: 'CupCore');
define('DB_USER',    getenv('DB_USER') ?: 'cupcoreapp');
define('DB_PASS',    getenv('DB_PASS') ?: 'Cambiar-App-2026');
define('DB_CHARSET', 'utf8mb4');
