<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../modelos/GestorParticipantes.php';
require_once __DIR__ . '/../modelos/GestorInscripciones.php';

/** Panel del participante: sus torneos, sus partidos, inscripción y perfil */
class ParticipanteController extends ControladorBase
{
    public function index(): void
    {
        $this->requiereRol(self::PARTICIPANTE);

        $participante = (new GestorParticipantes())->participanteDeUsuario($this->idUsuario());
        $gestor       = new GestorInscripciones();
        $id           = $participante ? (int) $participante['id'] : 0;

        $this->renderizarVista('participante', [
            'usuario'      => $_SESSION['usuario'],
            'participante' => $participante,
            'torneos'      => $gestor->listarDeParticipante($id),
            'proximos'     => $gestor->partidosDeParticipante($id, false),
            'jugados'      => $gestor->partidosDeParticipante($id, true),
            'disponibles'  => $gestor->torneosDisponibles($id),
            'tokenCsrf'    => SesionSegura::tokenCsrf(),
            'aviso'        => $this->tomarAviso(),
        ]);
    }

    /** Pide la inscripción en un torneo abierto; queda pendiente hasta que el organizador la acepta */
    public function inscribir(): void
    {
        $this->requiereRol(self::PARTICIPANTE);
        $this->exigirFormulario('participante');

        $idTorneo = (new Validador())->entero('torneo', $_POST['torneo'] ?? '');
        if ($idTorneo === null) {
            $this->avisar('Hay que elegir un torneo de la lista.');
            $this->redirigir('participante');
        }

        $inscripto = (new GestorInscripciones())->inscribir($idTorneo, $this->idParticipante());

        if ($inscripto) {
            $this->auditar('ALTA', 'Inscripcion');
        }

        $this->avisar($inscripto
            ? 'Inscripción enviada. Queda pendiente hasta que el organizador la acepte.'
            : 'No se inscribió: el torneo no tiene inscripciones abiertas o la inscripción ya existe.');
        $this->redirigir('participante');
    }

    /** Guarda el alias, la fecha de nacimiento y si el perfil es público */
    public function guardarPerfil(): void
    {
        $this->requiereRol(self::PARTICIPANTE);
        $this->exigirFormulario('participante');

        $validador = new Validador();

        $alias = trim((string) ($_POST['alias'] ?? ''));
        $alias = $alias === '' ? null : $validador->texto('alias', $alias, 2, 40);

        $nacimiento = trim((string) ($_POST['nacimiento'] ?? ''));
        $nacimiento = $nacimiento === '' ? null : $validador->fecha('nacimiento', $nacimiento);

        if ($validador->hayErrores() || ($nacimiento !== null && $nacimiento > date('Y-m-d'))) {
            $this->avisar('No se guardó el perfil: ' . (self::textoDeErrores($validador)
                ?: 'la fecha de nacimiento no puede ser posterior a hoy.'));
            $this->redirigir('participante');
        }

        $gestor       = new GestorParticipantes();
        $participante = $gestor->obtenerParticipante($this->idParticipante());

        $gestor->modificarParticipante(
            (int) $participante['id'], $participante['nombre'], $alias, $nacimiento, isset($_POST['publico'])
        );
        $this->auditar('MODIFICACION', 'Participante');

        $this->avisar('Perfil guardado.');
        $this->redirigir('participante');
    }

    /** Participante de la cuenta; si la cuenta todavía no tiene, lo crea con el nombre del usuario */
    private function idParticipante(): int
    {
        $gestor       = new GestorParticipantes();
        $participante = $gestor->participanteDeUsuario($this->idUsuario());

        if ($participante !== null) {
            return (int) $participante['id'];
        }

        return $gestor->crearParticipante(
            mb_substr($_SESSION['usuario']['nombre'], 0, 80), null, null, false, $this->idUsuario()
        );
    }
}
