<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../modelos/GestorUsuarios.php';
require_once __DIR__ . '/../modelos/GestorAuditoria.php';
require_once __DIR__ . '/../seguridad/Validador.php';
require_once __DIR__ . '/../seguridad/Contrasena.php';
require_once __DIR__ . '/../seguridad/SesionSegura.php';

/** Cambio de contraseña del usuario con sesión iniciada */
class ClaveController extends ControladorBase
{
    public function index(): void
    {
        if (!$this->estaLogueado()) {
            $this->redirigir('login');
        }

        $error = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $error = $this->cambiar();

            if ($error === '') {
                unset($_SESSION['debeCambiarClave']);
                SesionSegura::renovarIdentificador();
                $_SESSION['aviso'] = 'Contraseña actualizada.';
                $this->redirigirSegunRol();
            }
        }

        $this->renderizarVista('clave', [
            'usuario'     => $_SESSION['usuario'],
            'obligatorio' => !empty($_SESSION['debeCambiarClave']),
            'error'       => $error,
            'tokenCsrf'   => SesionSegura::tokenCsrf(),
        ]);
    }

    /** Devuelve el mensaje de error, o cadena vacía si la contraseña se cambió */
    private function cambiar(): string
    {
        if (!SesionSegura::tokenCsrfValido($_POST['tokenCsrf'] ?? null)) {
            return 'La página expiró. Recargar e intentar de nuevo.';
        }

        $gestor  = new GestorUsuarios();
        $usuario = $gestor->buscarPorCorreo($_SESSION['usuario']['correo']);
        $actual  = $_POST['actual'] ?? '';

        // 1. Contraseña actual
        if ($usuario === null || !is_string($actual) || !$usuario->verificarContrasena($actual)) {
            return 'La contraseña actual no es correcta.';
        }

        // 2. Política de contraseñas
        $validador = new Validador();
        $nueva = $validador->clave('nueva', $_POST['nueva'] ?? '');
        if ($nueva === null) {
            return implode(' ', $validador->errores());
        }

        // 3. Repetición
        if ($nueva !== ($_POST['repetida'] ?? '')) {
            return 'Las dos contraseñas no coinciden.';
        }

        // 4. Historial
        if ($gestor->claveYaUsada($usuario->getId(), $nueva)) {
            return 'La contraseña ya fue usada. No se puede repetir ninguna de las últimas '
                . Contrasena::HISTORIAL . '.';
        }

        // 5. Cambio y auditoría
        if (!$gestor->cambiarClave($usuario->getId(), $nueva)) {
            return 'No se pudo cambiar la contraseña.';
        }
        (new GestorAuditoria())->registrar((int) $usuario->getId(), 'MODIFICACION', 'Usuario');

        return '';
    }
}
