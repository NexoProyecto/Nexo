<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/TorneoController.php';
require_once __DIR__ . '/../modelos/GestorTorneos.php';

/** Datos públicos en JSON, para las consultas que hace js/torneos.js sin recargar la página */
class ApiController extends ControladorBase
{
    /** Torneos publicados que cumplen los filtros */
    public function torneos(): void
    {
        [$busqueda, $modulo] = TorneoController::filtros();

        $torneos = [];
        foreach ((new GestorTorneos())->listarTorneos($busqueda, $modulo) as $fila) {
            $torneos[] = [
                'id'           => (int) $fila['id'],
                'nombre'       => $fila['nombre'],
                'fecha_inicio' => $fila['fecha_inicio'],
                'fecha_fin'    => $fila['fecha_fin'],
                'estado'       => $fila['estado'],
                'disciplina'   => $fila['disciplina'],
                'modulo'       => $fila['modulo'],
                'inscriptos'   => (int) $fila['inscriptos'],
                'imagen'       => GestorTorneos::imagenDeTorneo($fila['nombre'], $fila['disciplina']),
            ];
        }

        $this->responderJson(['torneos' => $torneos]);
    }

    /** Tabla de posiciones de un torneo publicado */
    public function posiciones(): void
    {
        $id     = filter_var($_GET['torneo'] ?? '', FILTER_VALIDATE_INT);
        $gestor = new GestorTorneos();
        $torneo = $id ? $gestor->obtener($id) : null;

        if ($torneo === null || $torneo['estado_codigo'] === 'BORRADOR') {
            $this->responderJson(['error' => 'El torneo no existe.'], 404);
        }

        $posiciones = [];
        foreach ($gestor->listarPosiciones($id) as $fila) {
            $posiciones[] = [
                'participante' => $fila['participante'],
                'jugados'      => (int) $fila['jugados'],
                'ganados'      => (int) $fila['ganados'],
                'empatados'    => (int) $fila['empatados'],
                'perdidos'     => (int) $fila['perdidos'],
                'puntos'       => (int) $fila['puntos'],
            ];
        }

        $this->responderJson(['torneo' => $torneo['nombre'], 'posiciones' => $posiciones]);
    }
}
