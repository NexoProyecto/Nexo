<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/OrganizadorController.php';
require_once __DIR__ . '/../modelos/GestorTorneos.php';
require_once __DIR__ . '/../modelos/GestorInscripciones.php';
require_once __DIR__ . '/../modelos/GestorParticipantes.php';
require_once __DIR__ . '/../modelos/GestorCompetencia.php';
require_once __DIR__ . '/../modelos/GestorOrganizadores.php';
require_once __DIR__ . '/../modelos/GestorSolicitudesEquipo.php';

/**
 * Gestión de un torneo: datos, inscripciones, rondas y resultados.
 * El organizador gestiona los torneos que creó y aquellos en los que fue aceptado; el
 * administrador, todos. Un torneo cerrado no lo gestiona ningún organizador.
 */
class GestionController extends ControladorBase
{
    public function index(): void
    {
        $torneo = $this->torneoPermitido($_GET['id'] ?? '');
        $id     = (int) $torneo['id'];

        $gestorTorneos = new GestorTorneos();

        $this->renderizarVista('gestion', [
            'torneo'        => $torneo,
            'tipos'         => $gestorTorneos->listarTipos(),
            'inscripciones' => (new GestorInscripciones())->listarDeTorneo($id),
            'participantes' => (new GestorParticipantes())->listarParticipantes(),
            'rondas'        => (new GestorCompetencia())->rondas($id),
            'posiciones'    => $gestorTorneos->listarPosiciones($id),
            'organizadores' => (new GestorOrganizadores())->listarDeTorneo($id),
            'esAdministrador' => $this->esAdministrador(),
            'pedidosEquipos' => (new GestorSolicitudesEquipo())->equiposPendientesDeTorneo($id),
            'tokenCsrf'     => SesionSegura::tokenCsrf(),
            'aviso'         => $this->tomarAviso(),
        ]);
    }

    /** Cambia los datos de un torneo en borrador o con inscripciones abiertas */
    public function modificar(): void
    {
        $torneo = $this->torneoDelFormulario();
        $gestor = new GestorTorneos();

        if (!in_array($torneo['estado_codigo'], ['BORRADOR', 'ABIERTO'], true)) {
            $this->volver($torneo, 'Los datos se cambian antes de iniciar el torneo.');
        }

        $datos = OrganizadorController::datosDeTorneo($gestor, $errores);
        if ($datos === null) {
            $this->volver($torneo, 'No se pudo guardar: ' . $errores);
        }

        $gestor->modificar((int) $torneo['id'], ...$datos);
        $this->auditar('MODIFICACION', 'Torneo');

        $this->volver($torneo, 'Datos del torneo guardados.');
    }

    /** Publica el torneo: pasa a figurar en la consulta pública y abre las inscripciones */
    public function publicar(): void
    {
        $torneo = $this->torneoDelFormulario();

        if ((new GestorTorneos())->cambiarEstado((int) $torneo['id'], 'ABIERTO')) {
            $this->auditar('MODIFICACION', 'Torneo');
            $this->volver($torneo, 'Torneo publicado. Las inscripciones están abiertas.');
        }

        $this->volver($torneo, 'Solo se publica un torneo en borrador.');
    }

    public function cancelar(): void
    {
        $torneo = $this->torneoDelFormulario();

        if ((new GestorTorneos())->cambiarEstado((int) $torneo['id'], 'CANCELADO')) {
            $this->auditar('MODIFICACION', 'Torneo');
            $this->volver($torneo, 'Torneo cancelado.');
        }

        $this->volver($torneo, 'Un torneo finalizado o cancelado no cambia de estado.');
    }

    /**
     * Cierra el torneo: deja de admitir cambios y sus organizadores dejan de administrarlo.
     * Lo reabre el administrador, por su cuenta o a pedido de un organizador del torneo
     */
    public function cerrar(): void
    {
        $torneo = $this->torneoDelFormulario();

        if (!(new GestorTorneos())->cerrar((int) $torneo['id'])) {
            $this->volver($torneo, 'Un borrador no se cierra: se publica o se cancela.');
        }

        $this->auditar('MODIFICACION', 'Torneo');

        if ($this->esAdministrador()) {
            $this->volver($torneo, 'Torneo cerrado.');
        }
        $this->avisar('Torneo cerrado. Para reabrirlo, pedir la reapertura desde este panel; la resuelve el administrador.');
        $this->redirigir('organizador');
    }

    /** Acepta o rechaza el pedido de otro organizador para sumarse al torneo */
    public function resolverOrganizador(): void
    {
        $torneo = $this->torneoDelFormulario();

        $validador = new Validador();
        $usuario = $validador->entero('usuario', $_POST['usuario'] ?? '');
        $estado  = $validador->opcion('estado', $_POST['estado'] ?? '', ['ACEPTADA', 'RECHAZADA']);

        if ($validador->hayErrores()) {
            $this->volver($torneo, 'El pedido no es válido.');
        }

        if ((new GestorOrganizadores())->resolver((int) $torneo['id'], $usuario, $estado, $this->idUsuario())) {
            $this->auditar('MODIFICACION', 'Organiza');
            $this->volver($torneo, $estado === 'ACEPTADA' ? 'Organizador aceptado.' : 'Pedido rechazado.');
        }

        $this->volver($torneo, 'El pedido no existe o ya está resuelto.');
    }

    /** Inscribe a un participante existente; la inscripción queda aceptada */
    public function inscribir(): void
    {
        $torneo = $this->torneoDelFormulario();

        $idParticipante = (new Validador())->entero('participante', $_POST['participante'] ?? '');
        if ($idParticipante === null) {
            $this->volver($torneo, 'Hay que elegir un participante de la lista.');
        }

        if ((new GestorInscripciones())->inscribir((int) $torneo['id'], $idParticipante, 'ACEPTADA')) {
            $this->auditar('ALTA', 'Inscripcion');
            $this->volver($torneo, 'Participante inscripto.');
        }

        $this->volver($torneo, 'No se inscribió: el participante ya figura en el torneo '
            . 'o las inscripciones no están abiertas.');
    }

    /** Acepta o rechaza una inscripción pendiente */
    public function resolverInscripcion(): void
    {
        $torneo = $this->torneoDelFormulario();

        $validador = new Validador();
        $id     = $validador->entero('inscripcion', $_POST['inscripcion'] ?? '');
        $estado = $validador->opcion('estado', $_POST['estado'] ?? '', ['ACEPTADA', 'RECHAZADA']);

        if ($validador->hayErrores()) {
            $this->volver($torneo, 'La inscripción no es válida.');
        }

        if ((new GestorInscripciones())->resolver($id, (int) $torneo['id'], $estado)) {
            $this->auditar('MODIFICACION', 'Inscripcion');
            $this->volver($torneo, $estado === 'ACEPTADA' ? 'Inscripción aceptada.' : 'Inscripción rechazada.');
        }

        $this->volver($torneo, 'Las inscripciones se resuelven mientras están abiertas.');
    }

    /** Cierra las inscripciones y genera las rondas según el módulo del torneo */
    public function iniciar(): void
    {
        $torneo = $this->torneoDelFormulario();

        try {
            (new GestorCompetencia())->iniciar((int) $torneo['id']);
        } catch (DomainException $e) {
            $this->volver($torneo, $e->getMessage());
        }

        $this->auditar('ALTA', 'Ronda');
        $this->volver($torneo, 'Torneo iniciado. Los enfrentamientos están generados.');
    }

    /** Carga o corrige el marcador de un partido */
    public function cargarResultado(): void
    {
        $torneo = $this->torneoDelFormulario();

        $validador = new Validador();
        $partido   = $validador->entero('partido', $_POST['partido'] ?? '');
        $local     = $validador->entero('local', $_POST['local'] ?? '', 0, 999);
        $visitante = $validador->entero('visitante', $_POST['visitante'] ?? '', 0, 999);

        if ($validador->hayErrores()) {
            $this->volver($torneo, 'El marcador lleva dos números enteros entre 0 y 999.');
        }

        $gestor = new GestorCompetencia();
        $this->exigirPartidoDelTorneo($gestor, $partido, $torneo);

        try {
            $gestor->cargarResultado($partido, $local, $visitante, $this->esAdministrador());
        } catch (DomainException $e) {
            $this->volver($torneo, $e->getMessage());
        }

        $this->auditar('MODIFICACION', 'Resultado');
        $this->volver($torneo, 'Resultado guardado. Falta validarlo para que sea oficial.');
    }

    public function validarResultado(): void
    {
        $torneo  = $this->torneoDelFormulario();
        $partido = (new Validador())->entero('partido', $_POST['partido'] ?? '');

        if ($partido === null) {
            $this->volver($torneo, 'El partido no es válido.');
        }

        $gestor = new GestorCompetencia();
        $this->exigirPartidoDelTorneo($gestor, $partido, $torneo);

        try {
            $gestor->validarResultado($partido);
        } catch (DomainException $e) {
            $this->volver($torneo, $e->getMessage());
        }

        $this->auditar('MODIFICACION', 'Resultado');
        $this->volver($torneo, 'Resultado validado.');
    }

    public function cerrarRonda(): void
    {
        $torneo = $this->torneoDelFormulario();

        try {
            $mensaje = (new GestorCompetencia())->cerrarRonda((int) $torneo['id']);
        } catch (DomainException $e) {
            $this->volver($torneo, $e->getMessage());
        }

        $this->auditar('MODIFICACION', 'Ronda');
        $this->volver($torneo, $mensaje);
    }

    /** Torneo de un formulario: exige POST, token y permiso sobre el torneo */
    private function torneoDelFormulario(): array
    {
        $this->requiereAlguno([self::ORGANIZADOR, self::ADMINISTRADOR]);
        $this->exigirFormulario('organizador');

        return $this->torneoPermitido($_POST['torneo'] ?? '');
    }

    /** Devuelve el torneo si existe y quien pide lo puede gestionar; si no, vuelve al panel */
    private function torneoPermitido($id): array
    {
        $this->requiereAlguno([self::ORGANIZADOR, self::ADMINISTRADOR]);

        $id     = filter_var($id, FILTER_VALIDATE_INT);
        $torneo = $id ? (new GestorTorneos())->obtener($id) : null;

        if ($torneo === null || !$this->puedeGestionar($torneo)) {
            $this->avisar('El torneo no existe o está a cargo de otro organizador.');
            $this->redirigir('organizador');
        }

        if ($torneo['estado_codigo'] === 'CERRADO' && !$this->esAdministrador()) {
            $this->avisar('El torneo está cerrado: la reapertura se pide desde el panel'
                . ' del organizador y la resuelve el administrador.');
            $this->redirigir('organizador');
        }

        return $torneo;
    }

    /** El administrador gestiona todos los torneos; el organizador, los que creó o en los que fue aceptado */
    private function puedeGestionar(array $torneo): bool
    {
        $organizadores = new GestorOrganizadores();

        return $this->esAdministrador()
            || $organizadores->esOrganizador((int) $torneo['id'], $this->idUsuario());
    }

    /** El partido tiene que ser del torneo sobre el que se comprobó el permiso */
    private function exigirPartidoDelTorneo(GestorCompetencia $gestor, int $partido, array $torneo): void
    {
        if ($gestor->torneoDePartido($partido) !== (int) $torneo['id']) {
            $this->volver($torneo, 'El partido no pertenece a este torneo.');
        }
    }

    private function volver(array $torneo, string $mensaje): void
    {
        $this->avisar($mensaje);
        $this->redirigir('gestion&id=' . (int) $torneo['id']);
    }
}
