<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../modelos/GestorParticipantes.php';
require_once __DIR__ . '/../modelos/GestorInscripciones.php';

/** Perfil público de un participante o de un equipo; responde solo si el perfil está habilitado */
class PerfilController extends ControladorBase
{
    public function index(): void
    {
        $id     = filter_var($_GET['id'] ?? '', FILTER_VALIDATE_INT);
        $tipo   = $_GET['tipo'] ?? 'participante';
        $gestor = new GestorParticipantes();

        if ($id && $tipo === 'equipo') {
            $equipo = $gestor->obtenerEquipo($id);
            if ($equipo !== null && (int) $equipo['perfil_publico'] === 1) {
                $this->renderizarVista('perfil', [
                    'equipo'      => $equipo,
                    'integrantes' => $gestor->listarIntegrantes($id),
                ]);
                return;
            }
        } elseif ($id) {
            $participante = $gestor->obtenerParticipante($id);
            if ($participante !== null && (int) $participante['perfil_publico'] === 1) {
                $this->renderizarVista('perfil', [
                    'participante' => $participante,
                    'equipos'      => $gestor->equiposDeParticipante($id),
                    'torneos'      => (new GestorInscripciones())->listarDeParticipante($id),
                ]);
                return;
            }
        }

        $this->redirigir('torneos');
    }
}
