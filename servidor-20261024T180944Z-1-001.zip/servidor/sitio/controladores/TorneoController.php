<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../modelos/GestorTorneos.php';
require_once __DIR__ . '/../modelos/GestorCompetencia.php';

/** Consulta pública de torneos: listado con búsqueda y detalle */
class TorneoController extends ControladorBase
{
    public const MODULOS = ['Todos', 'Liga', 'Eliminación directa', 'Sistema suizo'];

    public function index(): void
    {
        [$busqueda, $modulo] = self::filtros();

        $this->renderizarVista('torneos', [
            'torneos'  => (new GestorTorneos())->listarTorneos($busqueda, $modulo),
            'busqueda' => $busqueda,
            'modulo'   => $modulo,
        ]);
    }

    /** Detalle de un torneo publicado: rondas, resultados oficiales y posiciones o llaves */
    public function detalle(): void
    {
        $id     = filter_var($_GET['id'] ?? '', FILTER_VALIDATE_INT);
        $torneo = $id ? (new GestorTorneos())->obtener($id) : null;

        if ($torneo === null || $torneo['estado_codigo'] === 'BORRADOR') {
            $this->redirigir('torneos');
        }

        $this->renderizarVista('torneo', [
            'torneo'     => $torneo,
            'rondas'     => (new GestorCompetencia())->rondas($id),
            'posiciones' => (new GestorTorneos())->listarPosiciones($id),
        ]);
    }

    /** Filtros del listado, tomados de la dirección y acotados */
    public static function filtros(): array
    {
        $busqueda = $_GET['busqueda'] ?? '';
        $busqueda = is_string($busqueda) ? mb_substr(trim($busqueda), 0, 100) : '';

        $modulo = $_GET['modulo'] ?? 'Todos';
        if (!is_string($modulo) || !in_array($modulo, self::MODULOS, true)) {
            $modulo = 'Todos';
        }

        return [$busqueda, $modulo];
    }
}
