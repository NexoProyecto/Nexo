<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../modelos/GestorParticipantes.php';
require_once __DIR__ . '/../modelos/GestorInscripciones.php';
require_once __DIR__ . '/../modelos/GestorSolicitudesEquipo.php';

/** Mis equipos: los equipos del participante y sus pedidos para integrar un equipo o inscribirlo */
class MisEquiposController extends ControladorBase
{
    private const MENSAJES = [
        GestorSolicitudesEquipo::ENVIADA        => 'Solicitud enviada. Queda pendiente hasta que un organizador la resuelva.',
        GestorSolicitudesEquipo::YA_INTEGRA     => 'Ya integra ese equipo.',
        GestorSolicitudesEquipo::NO_INTEGRA     => 'Solo un integrante del equipo puede pedir su inscripción.',
        GestorSolicitudesEquipo::REPETIDA       => 'Ya hay una solicitud igual pendiente.',
        GestorSolicitudesEquipo::DEMASIADAS     => 'Hay ' . GestorSolicitudesEquipo::MAXIMO_PENDIENTES
                                                   . ' solicitudes pendientes: se envían más cuando se resuelvan.',
        GestorSolicitudesEquipo::SIN_EQUIPO     => 'El equipo no existe.',
        GestorSolicitudesEquipo::TORNEO_CERRADO => 'El torneo no tiene inscripciones abiertas.',
        GestorSolicitudesEquipo::YA_INSCRIPTO   => 'El equipo ya figura en ese torneo.',
    ];

    public function index(): void
    {
        $this->requiereRol(self::PARTICIPANTE);

        $participantes = new GestorParticipantes();
        $idParticipante = $this->idParticipante();
        $misEquipos    = $participantes->misEquipos($idParticipante);

        // Torneos abiertos para cada equipo: los que no tienen ya a su representante
        $inscripciones = new GestorInscripciones();
        $torneos = [];
        foreach ($misEquipos as $equipo) {
            $representante = $participantes->representante((int) $equipo['id']);
            $torneos[(int) $equipo['id']] = $inscripciones->torneosDisponibles($representante);
        }

        $this->renderizarVista('mis-equipos', [
            'misEquipos'  => $misEquipos,
            'equipos'     => $participantes->listarEquipos(),
            'torneos'     => $torneos,
            'solicitudes' => (new GestorSolicitudesEquipo())->deParticipante($idParticipante),
            'tokenCsrf'   => SesionSegura::tokenCsrf(),
            'aviso'       => $this->tomarAviso(),
        ]);
    }

    /** Pedido para integrar un equipo de la lista o uno nuevo con el nombre escrito */
    public function integrar(): void
    {
        $this->requiereRol(self::PARTICIPANTE);
        $this->exigirFormulario('mis-equipos');

        $validador = new Validador();
        $equipo = trim((string) ($_POST['equipo'] ?? ''));
        $nombre = trim((string) ($_POST['nombre'] ?? ''));

        $idEquipo = $equipo === '' ? null : $validador->entero('equipo', $equipo);
        $nombre   = $idEquipo !== null || $nombre === '' ? null : $validador->texto('nombre', $nombre, 2, 80);

        if ($validador->hayErrores() || ($idEquipo === null && $nombre === null)) {
            $this->avisar('Hay que elegir un equipo de la lista o escribir el nombre del equipo nuevo (2 a 80 caracteres).');
            $this->redirigir('mis-equipos');
        }

        $resultado = (new GestorSolicitudesEquipo())->solicitarIntegrar($this->idParticipante(), $idEquipo, $nombre);
        $this->registrar($resultado);
    }

    /** Pedido para inscribir a uno de sus equipos en un torneo con inscripciones abiertas */
    public function inscribir(): void
    {
        $this->requiereRol(self::PARTICIPANTE);
        $this->exigirFormulario('mis-equipos');

        // El formulario manda "equipo-torneo" en un solo campo
        $partes = explode('-', (string) ($_POST['pedido'] ?? ''));
        $validador = new Validador();
        $idEquipo = $validador->entero('equipo', $partes[0] ?? '');
        $idTorneo = $validador->entero('torneo', $partes[1] ?? '');

        if ($validador->hayErrores()) {
            $this->avisar('Hay que elegir un equipo y un torneo de la lista.');
            $this->redirigir('mis-equipos');
        }

        $resultado = (new GestorSolicitudesEquipo())->solicitarInscribir($this->idParticipante(), $idEquipo, $idTorneo);
        $this->registrar($resultado);
    }

    private function registrar(string $resultado): void
    {
        if ($resultado === GestorSolicitudesEquipo::ENVIADA) {
            $this->auditar('ALTA', 'SolicitudEquipo');
        }

        $this->avisar(self::MENSAJES[$resultado]);
        $this->redirigir('mis-equipos');
    }

    /** Participante de la cuenta; si la cuenta todavía no tiene, lo crea con el nombre del usuario */
    private function idParticipante(): int
    {
        $gestor       = new GestorParticipantes();
        $participante = $gestor->participanteDeUsuario($this->idUsuario());

        if ($participante !== null) {
            return (int) $participante['id'];
        }

        return $gestor->crearParticipante(
            mb_substr($_SESSION['usuario']['nombre'], 0, 80), null, null, false, $this->idUsuario()
        );
    }
}
