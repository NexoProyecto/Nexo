<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../seguridad/SesionSegura.php';
require_once __DIR__ . '/../modelos/GestorAuditoria.php';

/** Cierre de sesión */
class SalirController extends ControladorBase
{
    public function index(): void
    {
        if ($this->estaLogueado()) {
            (new GestorAuditoria())->registrar((int) $_SESSION['usuario']['id'], 'LOGOUT', 'Usuario');
        }

        SesionSegura::cerrar();

        $this->redirigir('inicio');
    }
}