<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../seguridad/ControlAcceso.php';
require_once __DIR__ . '/../seguridad/SesionSegura.php';
require_once __DIR__ . '/../modelos/GestorAuditoria.php';

/** Inicio de sesión */
class LoginController extends ControladorBase
{
    public function index(): void
    {
        // Sesión ya iniciada
        if ($this->estaLogueado()) {
            $this->redirigirSegunRol();
        }

        // Aviso de sesión cerrada
        $error = $_SESSION['aviso'] ?? '';
        unset($_SESSION['aviso']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!SesionSegura::tokenCsrfValido($_POST['tokenCsrf'] ?? null)) {
                $error = 'La página expiró. Recargar e intentar de nuevo.';
            } else {
                $control = new ControlAcceso();
                $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

                $resultado = $control->ingresar(
                    $_POST['correo'] ?? '',
                    $_POST['contrasena'] ?? '',
                    $ip
                );

                if ($resultado['ok']) {
                    $usuario = $resultado['usuario'];

                    SesionSegura::marcarIngreso();

                    $_SESSION['usuario'] = [
                        'id'     => $usuario->getId(),
                        'nombre' => $usuario->getNombre(),
                        'correo' => $usuario->getCorreo(),
                        'rol'    => $usuario->getRol(),
                    ];

                    (new GestorAuditoria())->registrar((int) $usuario->getId(), 'LOGIN', 'Usuario');

                    // Contraseña provisional o vencida
                    if ($usuario->debeCambiarClave()) {
                        $_SESSION['debeCambiarClave'] = true;
                        $this->redirigir('clave');
                    }

                    $this->redirigirSegunRol();
                }

                $error = $resultado['mensaje'];
            }
        }

        $this->renderizarVista('login', [
            'error'     => $error,
            'tokenCsrf' => SesionSegura::tokenCsrf(),
        ]);
    }
}
