<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../seguridad/Contrasena.php';
require_once __DIR__ . '/../seguridad/SesionSegura.php';
require_once __DIR__ . '/../seguridad/Validador.php';
require_once __DIR__ . '/../seguridad/RegistroSeguridad.php';
require_once __DIR__ . '/../modelos/GestorSolicitudes.php';

/** Solicitud de cuenta desde la pantalla de ingreso */
class SolicitudController extends ControladorBase
{
    /** Respuesta única: no revela si el correo ya tiene cuenta o una solicitud pendiente */
    private const MENSAJE_ENVIADA = 'Solicitud enviada. Un administrador la revisa; una vez aprobada, '
        . 'el ingreso es con el correo y la contraseña de esta solicitud.';

    private const MENSAJE_LIMITE = 'Se alcanzó el límite de solicitudes desde esta conexión. Reintentar en una hora.';

    public function index(): void
    {
        if ($this->estaLogueado()) {
            $this->redirigirSegunRol();
        }

        $errores = [];
        $valores = ['nombre' => '', 'apellido' => '', 'correo' => '', 'rol' => 'Participante', 'motivo' => ''];
        $enviada = false;
        $error   = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            [$enviada, $error, $errores, $valores] = $this->procesar($valores);
        }

        $this->renderizarVista('solicitud', [
            'enviada'   => $enviada,
            'mensaje'   => $enviada ? self::MENSAJE_ENVIADA : '',
            'error'     => $error,
            'errores'   => $errores,
            'valores'   => $valores,
            'roles'     => GestorSolicitudes::ROLES_SOLICITABLES,
            'tokenCsrf' => SesionSegura::tokenCsrf(),
        ]);
    }

    /** Devuelve [enviada, error general, errores por campo, valores para volver a mostrar] */
    private function procesar(array $valores): array
    {
        if (!SesionSegura::tokenCsrfValido($_POST['tokenCsrf'] ?? null)) {
            return [false, 'La página expiró. Recargar e intentar de nuevo.', [], $valores];
        }

        // Límite por IP: sin registro de accesos no se puede contar y la solicitud se rechaza
        $registro = new RegistroSeguridad();
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        if (!$registro->disponible()) {
            return [false, 'La solicitud no está disponible. Avisar al administrador.', [], $valores];
        }
        if ($registro->solicitudesRecientes($ip) >= RegistroSeguridad::SOLICITUDES_POR_HORA) {
            return [false, self::MENSAJE_LIMITE, [], $valores];
        }

        $validador = new Validador();
        $nombre    = $validador->texto('nombre', $_POST['nombre'] ?? '', 2, 50);
        $apellido  = $validador->texto('apellido', $_POST['apellido'] ?? '', 2, 50);
        $correo    = $validador->email('correo', $_POST['correo'] ?? '');
        $clave     = $validador->clave('contrasena', $_POST['contrasena'] ?? '');
        $rol       = $validador->opcion('rol', $_POST['rol'] ?? '', GestorSolicitudes::ROLES_SOLICITABLES);

        $motivo = trim((string) ($_POST['motivo'] ?? ''));
        $motivo = $motivo === '' ? null : $validador->texto('motivo', $motivo, 1, 300);

        $errores = $validador->errores();
        if ($clave !== null && !hash_equals($clave, (string) ($_POST['repetida'] ?? ''))) {
            $errores['repetida'] = 'Las dos contraseñas no coinciden.';
        }

        // Se vuelven a mostrar los datos escritos, nunca la contraseña
        foreach (['nombre', 'apellido', 'correo', 'rol', 'motivo'] as $campo) {
            $valores[$campo] = is_string($_POST[$campo] ?? null) ? mb_substr($_POST[$campo], 0, 300) : '';
        }

        if ($errores) {
            return [false, 'Revisar los campos marcados.', $errores, $valores];
        }

        // El hash se calcula siempre: la respuesta tarda lo mismo con un correo ya registrado
        $hash = Contrasena::generarHash($clave);
        $solicitudes = new GestorSolicitudes();
        $solicitudes->registrar($nombre, $apellido, $correo, $hash, $rol, $motivo);
        $registro->solicitudCuenta($correo, $ip);

        return [true, '', [], $valores];
    }
}
