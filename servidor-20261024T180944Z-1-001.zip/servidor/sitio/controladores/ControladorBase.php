<?php
require_once __DIR__ . '/../seguridad/SesionSegura.php';
require_once __DIR__ . '/../seguridad/Validador.php';
require_once __DIR__ . '/../modelos/GestorAuditoria.php';

/** Clase base de los controladores: vistas, redirección, control de acceso por rol y auditoría */
abstract class ControladorBase
{
    protected const ADMINISTRADOR = 'Administrador general';
    protected const ORGANIZADOR   = 'Organizador de torneo';
    protected const PARTICIPANTE  = 'Participante';

    protected function renderizarVista(string $vista, array $datos = []): void
    {
        extract($datos);
        require __DIR__ . '/../vistas/' . $vista . '.php';
    }

    protected function redirigir(string $ruta): void
    {
        header('Location: index.php?ruta=' . $ruta);
        exit;
    }

    protected function estaLogueado(): bool
    {
        return isset($_SESSION['usuario']);
    }

    protected function requiereRol(string $rol): void
    {
        $this->requiereAlguno([$rol]);
    }

    /** Sin sesión o con otro rol, va al ingreso */
    protected function requiereAlguno(array $roles): void
    {
        if (!isset($_SESSION['usuario']) || !in_array($_SESSION['usuario']['rol'], $roles, true)) {
            $this->redirigir('login');
        }
    }

    protected function esAdministrador(): bool
    {
        return ($_SESSION['usuario']['rol'] ?? '') === self::ADMINISTRADOR;
    }

    protected function idUsuario(): int
    {
        return (int) $_SESSION['usuario']['id'];
    }

    /**
     * Toda acción que modifica datos llega por POST y con el token del formulario.
     * Si falta alguna de las dos cosas, vuelve a $ruta con un aviso.
     */
    protected function exigirFormulario(string $ruta): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST'
            || !SesionSegura::tokenCsrfValido($_POST['tokenCsrf'] ?? null)) {
            $this->avisar('La página expiró. Recargar e intentar de nuevo.');
            $this->redirigir($ruta);
        }
    }

    /** Mensaje que se muestra una vez en la pantalla siguiente */
    protected function avisar(string $mensaje): void
    {
        $_SESSION['aviso'] = $mensaje;
    }

    protected function tomarAviso(): string
    {
        $aviso = $_SESSION['aviso'] ?? '';
        unset($_SESSION['aviso']);

        return $aviso;
    }

    /** Errores de un formulario en una sola frase, cada uno con el nombre de su campo */
    protected static function textoDeErrores(Validador $validador): string
    {
        $partes = [];
        foreach ($validador->errores() as $campo => $mensaje) {
            $partes[] = ucfirst($campo) . ': ' . $mensaje;
        }

        return implode(' ', $partes);
    }

    protected function auditar(string $accion, string $tabla): void
    {
        (new GestorAuditoria())->registrar($this->idUsuario(), $accion, $tabla);
    }

    /** Respuesta JSON de las rutas api/ */
    protected function responderJson(array $datos, int $codigo = 200): void
    {
        http_response_code($codigo);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode($datos, JSON_UNESCAPED_UNICODE);
        exit;
    }

    protected function redirigirSegunRol(): void
    {
        switch ($_SESSION['usuario']['rol']) {
            case self::ADMINISTRADOR:
                $this->redirigir('admin');
            case self::ORGANIZADOR:
                $this->redirigir('organizador');
            default:
                $this->redirigir('participante');
        }
    }
}
