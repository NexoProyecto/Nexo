<?php
require_once __DIR__ . '/ControladorBase.php';
require_once __DIR__ . '/../modelos/GestorTorneos.php';

/** Portada */
class InicioController extends ControladorBase
{
    public function index(): void
    {
        $gestor    = new GestorTorneos();
        $destacado = $gestor->torneoDestacado();

        $this->renderizarVista('inicio', [
            'torneos'    => $gestor->listarTorneosPortada(3),
            'destacado'  => $destacado,
            'posiciones' => $destacado ? $gestor->listarPosiciones((int) $destacado['id']) : [],
            'stats'      => $gestor->estadisticas(),
        ]);
    }
}
