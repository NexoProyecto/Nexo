<?php
/** Verificación del ingreso */

require_once __DIR__ . '/Validador.php';
require_once __DIR__ . '/Contrasena.php';
require_once __DIR__ . '/RegistroSeguridad.php';
require_once __DIR__ . '/../modelos/GestorUsuarios.php';

class ControlAcceso
{
    const MENSAJE_ERROR = 'Correo o contraseña incorrectos.';

    const MENSAJE_SIN_REGISTRO = 'El ingreso no está disponible. Avisar al administrador.';

    /** Hash sin contraseña conocida: iguala el tiempo de respuesta de una cuenta inexistente */
    const HASH_SIN_CUENTA = '$2y$12$6bHubbL/rXceliutQeWieee.uoTXDp4/wH7YLc18pdAiEim6hHLj.';

    const MENSAJE_BLOQUEO = 'La cuenta está bloqueada temporalmente por intentos fallidos. Reintentar en 15 minutos.';

    private GestorUsuarios $gestor;
    private RegistroSeguridad $registro;

    public function __construct(?GestorUsuarios $gestor = null, ?RegistroSeguridad $registro = null)
    {
        $this->gestor   = $gestor   ?? new GestorUsuarios();
        $this->registro = $registro ?? new RegistroSeguridad();
    }

    /** Devuelve ['ok' => bool, 'mensaje' => string, 'usuario' => Usuario|null] */
    public function ingresar($correo, $contrasena, string $ip): array
    {
        // 1. Validación
        $validador = new Validador();
        $correoValido = $validador->email('correo', $correo);
        if ($correoValido === null || !is_string($contrasena) || $contrasena === ''
            || strlen($contrasena) > Validador::CLAVE_BYTES_MAXIMO) {
            return $this->fallo(is_string($correo) ? $correo : 'desconocido', $ip);
        }

        // 2. Límite de intentos: sin registro de accesos no se puede contar
        if (!$this->registro->disponible()) {
            return ['ok' => false, 'mensaje' => self::MENSAJE_SIN_REGISTRO, 'usuario' => null];
        }
        if ($this->registro->estaBloqueado($correoValido)) {
            $this->registro->cuentaBloqueada($correoValido, $ip);
            return ['ok' => false, 'mensaje' => self::MENSAJE_BLOQUEO, 'usuario' => null];
        }

        // 3. Búsqueda del usuario
        $usuario = $this->gestor->buscarPorCorreo($correoValido);
        if ($usuario === null) {
            Contrasena::verificar($contrasena, self::HASH_SIN_CUENTA);
            return $this->fallo($correoValido, $ip);
        }

        // 4. Estado de la cuenta
        if ($usuario->getEstado() !== 'Activo') {
            Contrasena::verificar($contrasena, self::HASH_SIN_CUENTA);
            return $this->fallo($correoValido, $ip);
        }

        // 5. Contraseña
        if (!$usuario->verificarContrasena($contrasena)) {
            return $this->fallo($correoValido, $ip);
        }

        $this->registro->ingresoCorrecto($correoValido, $ip);
        return ['ok' => true, 'mensaje' => '', 'usuario' => $usuario];
    }

    private function fallo(string $usuario, string $ip): array
    {
        $this->registro->intentoFallido($usuario, $ip);
        return ['ok' => false, 'mensaje' => self::MENSAJE_ERROR, 'usuario' => null];
    }
}
